<?php
declare(strict_types=1);
require_once __DIR__ . '/includes/bootstrap.php';

// Sudah login -> langsung ke beranda
if (is_logged_in()) {
    redirect('index.php');
}

$error = '';
$email = '';
$next  = safe_redirect_target(isset($_GET['next']) ? (string) $_GET['next'] : (string) ($_POST['next'] ?? ''));

if (is_post()) {
    csrf_require();

    $email    = mb_strtolower(post_str('email', 150));
    $password = (string) ($_POST['password'] ?? '');   // tidak di-trim: spasi bisa bagian dari password
    $genericError = 'Login gagal. Periksa kembali email dan password Anda, atau coba beberapa saat lagi.';

    if ($email === '' || $password === '' || !filter_var($email, FILTER_VALIDATE_EMAIL) || strlen($password) > 200) {
        $error = $genericError;
    } elseif (auth_attempt($email, $password)) {
        redirect($next ?? 'index.php');
    } else {
        $error = $genericError;
    }
}

$appName  = (string) app_config('app_name');
$showHint = (bool) app_config('show_demo_hint', false) && app_config('app_env') === 'development';
$flashes  = flash_get();
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Masuk — <?= e($appName) ?></title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="<?= e(url('assets/css/style.css')) ?>">
    <link rel="stylesheet" href="<?= e(url('assets/css/auth.css')) ?>">
</head>
<body class="auth-body">
<div class="auth-layout">

    <aside class="auth-brand" aria-hidden="false">
        <div class="brand-mark">
            <svg viewBox="0 0 32 32" width="34" height="34" fill="none" aria-hidden="true">
                <rect x="2" y="2" width="28" height="28" rx="8" fill="#3A86FF"/>
                <path d="M9 21l5-6 4 3 5-7" stroke="#fff" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"/>
                <circle cx="23" cy="11" r="2.4" fill="#D71920"/>
            </svg>
            <span><?= e($appName) ?></span>
        </div>

        <div class="brand-copy">
            <h1>Satu sumber data untuk seluruh tenaga kerja Anda.</h1>
            <p>Kelola data tenaga kerja, vendor, dan mandays secara terpusat, validasi hasil import Excel, lalu pantau tren lewat dashboard dan laporan.</p>
            <ul class="brand-points">
                <li>Import Excel dengan validasi otomatis</li>
                <li>Dashboard dan analytics berbasis database</li>
                <li>Laporan bulanan siap ekspor</li>
            </ul>
        </div>

        <div class="brand-foot">Proyek portofolio · Data demo bersifat fiktif</div>
    </aside>

    <main class="auth-panel">
        <div class="auth-card">
            <div class="auth-card-head">
                <h2>Masuk ke akun Anda</h2>
                <p>Gunakan email dan password yang terdaftar.</p>
            </div>

            <?php foreach ($flashes as $f): ?>
                <div class="alert alert-<?= e($f['type']) ?>" role="status"><?= e($f['message']) ?></div>
            <?php endforeach; ?>

            <?php if ($error !== ''): ?>
                <div class="alert alert-danger" role="alert"><?= e($error) ?></div>
            <?php endif; ?>

            <form method="post" action="<?= e(url('login.php')) ?>" novalidate id="loginForm" autocomplete="on">
                <?= csrf_field() ?>
                <?php if ($next !== null): ?>
                    <input type="hidden" name="next" value="<?= e($next) ?>">
                <?php endif; ?>

                <div class="field">
                    <label for="email">Email</label>
                    <input type="email" id="email" name="email" value="<?= e($email) ?>"
                           placeholder="nama@perusahaan.com" autocomplete="username" required autofocus maxlength="150">
                </div>

                <div class="field">
                    <label for="password">Password</label>
                    <div class="input-group">
                        <input type="password" id="password" name="password"
                               placeholder="Masukkan password" autocomplete="current-password" required maxlength="200">
                        <button type="button" class="input-toggle" id="togglePassword" aria-label="Tampilkan password" aria-pressed="false">Tampilkan</button>
                    </div>
                </div>

                <button type="submit" class="btn btn-primary btn-block" id="loginSubmit">Masuk</button>
            </form>

            <?php if ($showHint): ?>
                <div class="demo-hint">
                    <strong>Akun demo (khusus development)</strong>
                    <table>
                        <tr><td>Admin</td><td>admin@example.com</td><td>Admin@Demo2026</td></tr>
                        <tr><td>HC Staff</td><td>hcstaff@example.com</td><td>Staff@Demo2026</td></tr>
                        <tr><td>Viewer</td><td>viewer@example.com</td><td>Viewer@Demo2026</td></tr>
                    </table>
                </div>
            <?php endif; ?>
        </div>
    </main>
</div>
<script src="<?= e(url('assets/js/auth.js')) ?>"></script>
</body>
</html>
