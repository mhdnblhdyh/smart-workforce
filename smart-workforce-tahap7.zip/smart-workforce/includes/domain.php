<?php
/**
 * Fungsi domain yang dipakai lintas modul (pengaturan, kontrak vendor, periode, format angka).
 */
declare(strict_types=1);

const MONTH_NAMES_ID = [1 => 'Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni', 'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember'];
const MONTH_SHORT_ID = [1 => 'Jan', 'Feb', 'Mar', 'Apr', 'Mei', 'Jun', 'Jul', 'Agu', 'Sep', 'Okt', 'Nov', 'Des'];

/** Ambil nilai pengaturan dari tabel settings (dengan nilai bawaan). */
function setting_get(string $key, string $default = ''): string
{
    static $cache = null;
    if ($cache === null) {
        $cache = [];
        foreach (db_fetch_all('SELECT setting_key, setting_value FROM settings') as $row) {
            $cache[$row['setting_key']] = (string) $row['setting_value'];
        }
    }
    return $cache[$key] ?? $default;
}

/** Label bulan 'YYYY-MM-DD' / 'YYYY-MM' -> 'September 2026'. */
function month_label(string $date, bool $short = false): string
{
    $ts = strtotime(substr($date, 0, 7) . '-01');
    if (!$ts) {
        return '-';
    }
    $names = $short ? MONTH_SHORT_ID : MONTH_NAMES_ID;
    return $names[(int) date('n', $ts)] . ' ' . date('Y', $ts);
}

/**
 * Status kontrak vendor relatif terhadap hari ini.
 * Mengembalikan ['state' => none|ok|warning|expired, 'days_left' => ?int].
 */
function vendor_contract_state(?string $contractEnd, ?string $today = null): array
{
    if ($contractEnd === null || $contractEnd === '') {
        return ['state' => 'none', 'days_left' => null];
    }
    $today ??= date('Y-m-d');
    $days   = (int) floor((strtotime($contractEnd) - strtotime($today)) / 86400);
    $warn   = (int) setting_get('contract_warning_days', '60');

    if ($days < 0) {
        return ['state' => 'expired', 'days_left' => $days];
    }
    return ['state' => $days <= $warn ? 'warning' : 'ok', 'days_left' => $days];
}

/**
 * Vendor AKTIF yang kontraknya sudah berakhir atau segera berakhir (untuk notifikasi topbar).
 */
function contract_alerts(): array
{
    $warn = (int) setting_get('contract_warning_days', '60');
    $rows = db_fetch_all(
        "SELECT id, code, name, contract_end FROM vendors
         WHERE status = 'active' AND contract_end IS NOT NULL
           AND contract_end <= DATE_ADD(CURDATE(), INTERVAL ? DAY)
         ORDER BY contract_end ASC LIMIT 10",
        'i',
        [$warn]
    );
    foreach ($rows as &$r) {
        $r += vendor_contract_state($r['contract_end']);
    }
    return $rows;
}

/** Status generik untuk master data (departemen, vendor). */
const ACTIVE_STATUSES = ['active' => 'Aktif', 'inactive' => 'Nonaktif'];

/** Tanggal 'YYYY-MM-DD' -> '05 Jan 2026' (atau '-' jika kosong). */
function fmt_date(?string $d): string
{
    return $d ? date('d M Y', strtotime($d)) : '-';
}
