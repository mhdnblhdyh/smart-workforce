<?php
/**
 * Helper validasi input sisi server.
 */
declare(strict_types=1);

/** Tanggal 'YYYY-MM-DD' yang benar-benar ada di kalender (1990–2100). Mengembalikan string ternormalisasi atau null. */
function val_date(?string $s): ?string
{
    if ($s === null || !preg_match('/^(\d{4})-(\d{2})-(\d{2})$/', $s, $m)) {
        return null;
    }
    [$y, $mo, $d] = [(int) $m[1], (int) $m[2], (int) $m[3]];
    if ($y < 1990 || $y > 2100 || !checkdate($mo, $d, $y)) {
        return null;
    }
    return $s;
}

function val_len(string $s, int $min, int $max): bool
{
    $n = mb_strlen($s);
    return $n >= $min && $n <= $max;
}

/** Nilai tidak kosong -> string; kosong -> null. */
function null_if_empty(string $s): ?string
{
    return $s === '' ? null : $s;
}

/**
 * Cek keunikan nilai. $table/$column HANYA boleh konstanta dari kode (bukan input pengguna).
 */
function is_unique_value(string $table, string $column, string $value, ?int $exceptId = null): bool
{
    $allowed = ['employees' => ['employee_code'], 'departments' => ['code'], 'vendors' => ['code'], 'users' => ['email']];
    if (!isset($allowed[$table]) || !in_array($column, $allowed[$table], true)) {
        throw new InvalidArgumentException('Kolom unik tidak diizinkan.');
    }
    $sql    = "SELECT COUNT(*) FROM `{$table}` WHERE `{$column}` = ?";
    $types  = 's';
    $params = [$value];
    if ($exceptId !== null) {
        $sql .= ' AND id <> ?';
        $types .= 'i';
        $params[] = $exceptId;
    }
    return (int) db_value($sql, $types, $params) === 0;
}

/** Ringkas daftar kolom yang berubah antara data lama dan baru (untuk audit log, tanpa nilai). */
function changed_fields(array $old, array $new): array
{
    $changed = [];
    foreach ($new as $k => $v) {
        if (array_key_exists($k, $old) && (string) $old[$k] !== (string) $v) {
            $changed[] = $k;
        }
    }
    return $changed;
}

/**
 * Angka desimal non-negatif ('21', '21,5', '21.25'; maksimal 2 desimal) <= $max.
 * Mengembalikan string ternormalisasi ('21.50') atau null jika tidak valid.
 */
function val_decimal(string $s, float $max): ?string
{
    if (!preg_match('/^\d{1,3}([.,]\d{1,2})?$/', $s)) {
        return null;
    }
    $n = (float) str_replace(',', '.', $s);
    return ($n >= 0 && $n <= $max) ? number_format($n, 2, '.', '') : null;
}
