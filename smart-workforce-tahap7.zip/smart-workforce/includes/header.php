<?php
/**
 * Pembuka layout aplikasi: <head>, sidebar, topbar, dan pembuka <main>.
 *
 * Pemakaian di halaman (setelah require_permission):
 *   $page = [
 *     'title'      => 'Dashboard',                 // judul tab & halaman
 *     'active'     => 'dashboard',                 // key menu sidebar yang aktif
 *     'breadcrumb' => ['Overview', 'Dashboard'],   // label terakhir = halaman saat ini
 *     'css'        => ['dashboard.css'],           // CSS tambahan di assets/css/
 *     'js'         => ['dashboard.js'],            // JS tambahan di assets/js/ (dimuat setelah app.js)
 *     'chart'      => true,                        // muat Chart.js
 *   ];
 *   require BASE_PATH . '/includes/header.php';
 *   ... konten ...
 *   require BASE_PATH . '/includes/footer.php';
 */
declare(strict_types=1);

$user = current_user();
if ($user === null) {
    redirect('login.php');
}
$page    = $page ?? [];
$appName = (string) app_config('app_name');
$title   = (string) ($page['title'] ?? 'Halaman');
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="robots" content="noindex, nofollow">
    <title><?= e($title) ?> — <?= e($appName) ?></title>
    <script>
        // Terapkan status sidebar sebelum render agar tidak berkedip.
        try { if (localStorage.getItem('swa.sidebar') === 'collapsed' && window.innerWidth > 1024) document.documentElement.classList.add('sidebar-collapsed'); } catch (e) {}
    </script>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="<?= e(url('assets/css/style.css')) ?>">
    <link rel="stylesheet" href="<?= e(url('assets/css/components.css')) ?>">
    <?php foreach (($page['css'] ?? []) as $css): ?>
        <link rel="stylesheet" href="<?= e(url('assets/css/' . $css)) ?>">
    <?php endforeach; ?>
</head>
<body class="app-body">
<div class="app-shell">
    <?php require BASE_PATH . '/includes/sidebar.php'; ?>
    <div class="sidebar-overlay" id="sidebarOverlay" hidden></div>

    <div class="app-main">
        <?php require BASE_PATH . '/includes/navbar.php'; ?>
        <main class="app-content" id="content">
