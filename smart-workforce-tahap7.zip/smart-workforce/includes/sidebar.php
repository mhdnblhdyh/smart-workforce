<?php
/** Sidebar. Membutuhkan $user dan (opsional) $page['active'] dari header.php. */
declare(strict_types=1);

$activeKey = (string) ($page['active'] ?? '');
$navGroups = nav_for_user($user);
?>
<aside class="sidebar" id="sidebar" aria-label="Navigasi utama">
    <div class="sidebar-head">
        <a class="brand" href="<?= e(url('index.php')) ?>" title="<?= e((string) app_config('app_name')) ?>">
            <svg viewBox="0 0 32 32" width="32" height="32" fill="none" aria-hidden="true">
                <rect x="2" y="2" width="28" height="28" rx="8" fill="#3A86FF"/>
                <path d="M9 21l5-6 4 3 5-7" stroke="#fff" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"/>
                <circle cx="23" cy="11" r="2.4" fill="#D71920"/>
            </svg>
            <span class="brand-text nav-text">Smart Workforce<small>Analytics</small></span>
        </a>
        <button type="button" class="icon-btn sidebar-close" id="sidebarClose" aria-label="Tutup menu"><?= icon('x') ?></button>
    </div>

    <nav class="sidebar-nav">
        <?php foreach ($navGroups as $group => $items): ?>
            <div class="nav-group">
                <p class="nav-group-title nav-text"><?= e($group) ?></p>
                <ul>
                <?php foreach ($items as $item):
                    $ready  = $item['stage'] <= NAV_READY_STAGE;
                    $active = $ready && $item['key'] === $activeKey;
                ?>
                    <li>
                    <?php if ($ready): ?>
                        <a class="nav-link<?= $active ? ' is-active' : '' ?>" href="<?= e(url($item['path'])) ?>"
                           title="<?= e($item['label']) ?>"<?= $active ? ' aria-current="page"' : '' ?>>
                            <?= icon($item['icon']) ?><span class="nav-text"><?= e($item['label']) ?></span>
                        </a>
                    <?php else: ?>
                        <span class="nav-link is-disabled" aria-disabled="true" title="<?= e($item['label']) ?> — tersedia di Tahap <?= (int) $item['stage'] ?>">
                            <?= icon($item['icon']) ?><span class="nav-text"><?= e($item['label']) ?></span>
                            <span class="nav-soon nav-text">Segera</span>
                        </span>
                    <?php endif; ?>
                    </li>
                <?php endforeach; ?>
                </ul>
            </div>
        <?php endforeach; ?>
    </nav>

    <div class="sidebar-foot">
        <button type="button" class="nav-link nav-collapse" id="sidebarCollapse" aria-label="Ciutkan sidebar" title="Ciutkan sidebar">
            <?= icon('panel-left-close') ?><span class="nav-text">Ciutkan menu</span>
        </button>
    </div>
</aside>
