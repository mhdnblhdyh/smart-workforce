<?php
/**
 * Komponen UI reusable (menghasilkan HTML). Semua teks dinamis di-escape.
 */
declare(strict_types=1);

/** Kartu KPI kerangka; nilainya diisi dashboard.js lewat atribut data-kpi="<key>". */
function ui_kpi_card(string $key, string $label, string $icon, string $hint = ''): string
{
    return '<article class="kpi-card" data-kpi="' . e($key) . '">'
        . '<div class="kpi-top"><span class="kpi-label">' . e($label) . '</span>'
        . '<span class="kpi-icon">' . icon($icon) . '</span></div>'
        . '<div class="kpi-value"><span class="skeleton skeleton-text" data-role="value">&nbsp;</span></div>'
        . '<div class="kpi-foot" data-role="foot">' . ($hint !== '' ? e($hint) : '&nbsp;') . '</div>'
        . '</article>';
}

/** Empty state informatif. $actionHtml harus HTML yang sudah aman (mis. dari ui_button). */
function ui_empty_state(string $icon, string $title, string $text = '', string $actionHtml = ''): string
{
    return '<div class="empty-state">'
        . '<span class="empty-icon">' . icon($icon) . '</span>'
        . '<h3>' . e($title) . '</h3>'
        . ($text !== '' ? '<p>' . e($text) . '</p>' : '')
        . $actionHtml
        . '</div>';
}

/** Badge status. $variant: success|warning|danger|info|neutral */
function ui_badge(string $text, string $variant = 'neutral'): string
{
    $variant = in_array($variant, ['success', 'warning', 'danger', 'info', 'neutral'], true) ? $variant : 'neutral';
    return '<span class="pill pill-' . $variant . '">' . e($text) . '</span>';
}

/** Header kolom yang bisa diurutkan. $req = hasil list_request(). */
function ui_sort_th(string $label, string $key, array $req, string $path, string $class = ''): string
{
    $active = $req['sort'] === $key;
    $nextDir = ($active && $req['dir'] === 'asc') ? 'desc' : 'asc';
    $href = list_url($path, ['sort' => $key, 'dir' => $nextDir, 'page' => null]);
    $cls = 'sortable' . ($active ? ' is-sorted sort-' . $req['dir'] : '') . ($class !== '' ? ' ' . $class : '');
    $aria = $active ? ($req['dir'] === 'asc' ? 'ascending' : 'descending') : 'none';
    return '<th class="' . e($cls) . '" aria-sort="' . $aria . '"><a href="' . e($href) . '">' . e($label) . '<span class="sort-ind" aria-hidden="true"></span></a></th>';
}

/** Pagination server-side. Mempertahankan seluruh filter di query string. */
function ui_pagination(int $total, int $page, int $per, string $path): string
{
    $pages = max(1, (int) ceil($total / $per));
    $from  = $total === 0 ? 0 : ($page - 1) * $per + 1;
    $to    = min($total, $page * $per);
    $html  = '<div class="pagination"><span class="pagination-info">Menampilkan '
        . e(number_format($from, 0, ',', '.')) . '–' . e(number_format($to, 0, ',', '.'))
        . ' dari ' . e(number_format($total, 0, ',', '.')) . ' data</span>';

    if ($pages > 1) {
        $link = function (int $p, string $label, bool $disabled = false, bool $current = false, string $aria = '') use ($path): string {
            if ($disabled) {
                return '<span class="page-link is-disabled" aria-hidden="true">' . $label . '</span>';
            }
            return '<a class="page-link' . ($current ? ' is-current' : '') . '" href="' . e(list_url($path, ['page' => $p > 1 ? $p : null])) . '"'
                . ($current ? ' aria-current="page"' : '') . ($aria !== '' ? ' aria-label="' . e($aria) . '"' : '') . '>' . $label . '</a>';
        };
        $html .= '<nav class="page-links" aria-label="Halaman">';
        $html .= $link($page - 1, icon('chevron-left'), $page <= 1, false, 'Halaman sebelumnya');
        $window = array_unique(array_filter(array_merge([1, $pages], range(max(1, $page - 1), min($pages, $page + 1))), fn ($p) => $p >= 1 && $p <= $pages));
        sort($window);
        $prev = 0;
        foreach ($window as $p) {
            if ($p - $prev > 1) {
                $html .= '<span class="page-gap">…</span>';
            }
            $html .= $link($p, (string) $p, false, $p === $page);
            $prev = $p;
        }
        $html .= $link($page + 1, icon('chevron-right'), $page >= $pages, false, 'Halaman berikutnya');
        $html .= '</nav>';
    }
    return $html . '</div>';
}

/** Tombol ikon kecil untuk aksi baris. */
function ui_row_action(string $action, string $label, string $icon, string $extraClass = ''): string
{
    return '<button type="button" class="row-btn' . ($extraClass !== '' ? ' ' . e($extraClass) : '') . '" data-action="' . e($action)
        . '" title="' . e($label) . '" aria-label="' . e($label) . '">' . icon($icon) . '</button>';
}

/** Dialog konfirmasi hapus generik (isi diisi oleh crud.js). */
function ui_confirm_dialog(string $actionUrl, string $returnQs): string
{
    return '<dialog class="modal modal-sm" id="confirmDialog" aria-labelledby="confirmTitle">'
        . '<form method="post" action="' . e($actionUrl) . '">' . csrf_field()
        . '<input type="hidden" name="id" value=""><input type="hidden" name="return_qs" value="' . e(safe_return_qs($returnQs)) . '">'
        . '<div class="modal-body confirm-body"><span class="confirm-icon">' . icon('triangle-alert') . '</span>'
        . '<h3 id="confirmTitle">Hapus data ini?</h3><p id="confirmText"></p></div>'
        . '<div class="modal-foot"><button type="button" class="btn btn-outline" data-close>Batal</button>'
        . '<button type="submit" class="btn btn-danger">Ya, hapus</button></div></form></dialog>';
}

/** Dialog detail generik (isi diisi oleh crud.js dari record.details). */
function ui_detail_dialog(): string
{
    return '<dialog class="modal" id="detailDialog" aria-labelledby="detailTitle">'
        . '<div class="modal-head"><h3 id="detailTitle">Detail</h3><button type="button" class="icon-btn" data-close aria-label="Tutup">' . icon('x') . '</button></div>'
        . '<div class="modal-body"><dl class="detail-list" id="detailBody"></dl></div>'
        . '<div class="modal-foot"><button type="button" class="btn btn-outline" data-close>Tutup</button></div></dialog>';
}

/** Navigasi tab antar halaman satu modul. $tabs = [[key, label, path], ...] */
function ui_tabs(array $tabs, string $active): string
{
    $html = '<nav class="tabs" aria-label="Bagian modul">';
    foreach ($tabs as [$key, $label, $path]) {
        $html .= '<a class="tab' . ($key === $active ? ' is-active' : '') . '" href="' . e(url($path)) . '"' . ($key === $active ? ' aria-current="page"' : '') . '>' . e($label) . '</a>';
    }
    return $html . '</nav>';
}

/** Kartu ringkasan kecil (server-side). */
function ui_mini_stat(string $label, string $value, string $sub = ''): string
{
    return '<div class="mini-stat"><span class="mini-label">' . e($label) . '</span><strong>' . e($value) . '</strong>'
        . ($sub !== '' ? '<small>' . e($sub) . '</small>' : '') . '</div>';
}

/** Indikator langkah. $steps = [label, ...]; $current = indeks 1-based langkah aktif. */
function ui_stepper(array $steps, int $current): string
{
    $html = '<ol class="stepper" aria-label="Langkah impor">';
    foreach ($steps as $i => $label) {
        $n = $i + 1;
        $cls = $n < $current ? 'is-done' : ($n === $current ? 'is-current' : '');
        $html .= '<li class="step ' . $cls . '"' . ($n === $current ? ' aria-current="step"' : '') . '><span class="step-no">' . ($n < $current ? icon('circle-check') : $n) . '</span><span class="step-label">' . e($label) . '</span></li>';
    }
    return $html . '</ol>';
}
