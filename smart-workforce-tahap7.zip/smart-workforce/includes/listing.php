<?php
/**
 * Helper daftar data: parameter sort/pagination yang aman, URL, state form (PRG), dan ekspor CSV.
 */
declare(strict_types=1);

const PER_PAGE_OPTIONS = [10, 25, 50, 100];

/**
 * Baca sort/dir/page/per dari query string. Kolom sort hanya diterima jika ada di whitelist $sortMap
 * (kunci => ekspresi SQL), sehingga tidak ada input pengguna yang masuk ke ORDER BY.
 */
function list_request(array $sortMap, string $defaultSort, string $defaultDir = 'asc'): array
{
    $sort = (isset($_GET['sort']) && is_string($_GET['sort']) && isset($sortMap[$_GET['sort']])) ? $_GET['sort'] : $defaultSort;
    $dir  = (isset($_GET['dir']) && is_string($_GET['dir'])) ? ($_GET['dir'] === 'desc' ? 'desc' : 'asc') : $defaultDir;
    $per  = (isset($_GET['per']) && is_string($_GET['per']) && in_array((int) $_GET['per'], PER_PAGE_OPTIONS, true)) ? (int) $_GET['per'] : PER_PAGE_OPTIONS[0];
    $page = (isset($_GET['page']) && is_string($_GET['page'])) ? max(1, (int) $_GET['page']) : 1;

    return ['sort' => $sort, 'dir' => $dir, 'per' => $per, 'page' => $page, 'order_sql' => $sortMap[$sort] . ($dir === 'desc' ? ' DESC' : ' ASC')];
}

/** Jika halaman diminta melebihi jumlah halaman, mundurkan ke halaman terakhir. */
function list_clamp_page(int $total, int $page, int $per): int
{
    return max(1, min($page, (int) max(1, ceil($total / $per))));
}

/** Escape karakter wildcard LIKE (\ % _) pada input pencarian. */
function like_escape(string $s): string
{
    return str_replace(['\\', '%', '_'], ['\\\\', '\\%', '\\_'], $s);
}

/** Query string saat ini (hanya nilai string), digabung dengan $merge; nilai null/'' dihapus. */
function list_query(array $merge = []): string
{
    $q = [];
    foreach ($_GET as $k => $v) {
        if (is_string($v) && $v !== '') {
            $q[$k] = $v;
        }
    }
    foreach ($merge as $k => $v) {
        if ($v === null || $v === '') {
            unset($q[$k]);
        } else {
            $q[$k] = (string) $v;
        }
    }
    return http_build_query($q);
}

function list_url(string $path, array $merge = []): string
{
    $qs = list_query($merge);
    return url($path) . ($qs !== '' ? '?' . $qs : '');
}

/** Query string aman untuk kembali ke daftar setelah simpan/hapus (tanpa karakter berbahaya). */
function safe_return_qs($raw): string
{
    if (!is_string($raw) || strlen($raw) > 500 || !preg_match('/^[A-Za-z0-9_=&%.+\-]*$/', $raw)) {
        return '';
    }
    return $raw;
}

function redirect_to_list(string $path, $returnQs = ''): void
{
    $qs = safe_return_qs($returnQs);
    redirect($path . ($qs !== '' ? '?' . $qs : ''));
}

/* ---------- State form (dipakai ulang setelah validasi gagal) ---------- */
function form_state_set(string $module, array $state): void
{
    $_SESSION['form_state'][$module] = $state;
}

function form_state_pull(string $module): ?array
{
    $state = $_SESSION['form_state'][$module] ?? null;
    unset($_SESSION['form_state'][$module]);
    return $state;
}

/** Ambil hanya kunci yang dikenal dari $_POST sebagai string (untuk mengisi ulang form). */
function post_old_input(array $keys): array
{
    $old = [];
    foreach ($keys as $k) {
        $old[$k] = (isset($_POST[$k]) && is_string($_POST[$k])) ? mb_substr($_POST[$k], 0, 2100) : '';
    }
    return $old;
}

/** Tangkap duplicate-key (errno 1062) dari mysqli_sql_exception. */
function is_duplicate_error(Throwable $e): bool
{
    return $e instanceof mysqli_sql_exception && (int) $e->getCode() === 1062;
}

/** Tangkap pelanggaran foreign key (errno 1451/1452). */
function is_fk_error(Throwable $e): bool
{
    return $e instanceof mysqli_sql_exception && in_array((int) $e->getCode(), [1451, 1452], true);
}

/* ---------- CSV ---------- */
/** Netralkan sel yang diawali karakter formula agar tidak dieksekusi spreadsheet (CSV injection). */
function csv_safe($value): string
{
    $s = (string) $value;
    return ($s !== '' && in_array($s[0], ['=', '+', '-', '@', "\t", "\r"], true)) ? "'" . $s : $s;
}

/**
 * Kirim CSV (UTF-8 BOM, pemisah titik koma agar terbuka benar di Excel regional Indonesia) lalu exit.
 * $rows boleh berupa generator agar hemat memori.
 */
function csv_download(string $filename, array $header, iterable $rows): void
{
    $filename = preg_replace('/[^A-Za-z0-9._-]/', '_', $filename);
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename="' . $filename . '"');
    header('Cache-Control: no-store');
    $out = fopen('php://output', 'w');
    fwrite($out, "\xEF\xBB\xBF");
    fputcsv($out, array_map('csv_safe', $header), ';');
    foreach ($rows as $row) {
        fputcsv($out, array_map('csv_safe', $row), ';');
    }
    fclose($out);
    exit;
}
