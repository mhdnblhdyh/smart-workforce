<?php
/**
 * Definisi menu sidebar. Item hanya tampil jika pengguna punya izin;
 * grup tanpa item yang boleh diakses disembunyikan sepenuhnya.
 * 'stage' => tahap pembangunan modul. Selama modul belum ada, item tampil nonaktif ("Segera"),
 * bukan tautan palsu.
 */
declare(strict_types=1);

const NAV_READY_STAGE = 7;   // tahap yang sudah selesai dibangun

function nav_definition(): array
{
    return [
        'Overview' => [
            ['key' => 'dashboard',   'label' => 'Dashboard',          'icon' => 'layout-dashboard', 'path' => 'index.php',               'perm' => 'dashboard.view',   'stage' => 2],
        ],
        'Workforce Management' => [
            ['key' => 'employees',   'label' => 'Data Tenaga Kerja',  'icon' => 'users',            'path' => 'modules/employees/index.php',   'perm' => 'employees.view',   'stage' => 3],
            ['key' => 'departments', 'label' => 'Departemen',         'icon' => 'building-2',       'path' => 'modules/departments/index.php', 'perm' => 'departments.view', 'stage' => 3],
            ['key' => 'vendors',     'label' => 'Vendor',             'icon' => 'handshake',        'path' => 'modules/vendors/index.php',     'perm' => 'vendors.view',     'stage' => 3],
            ['key' => 'mandays',     'label' => 'Mandays & Kehadiran', 'icon' => 'calendar-check', 'path' => 'modules/mandays/index.php',     'perm' => 'mandays.view',     'stage' => 4],
        ],
        'Data Intelligence' => [
            ['key' => 'import',      'label' => 'Import Excel',       'icon' => 'file-spreadsheet', 'path' => 'modules/imports/index.php',      'perm' => 'import.run',       'stage' => 5],
            ['key' => 'dataquality', 'label' => 'Data Quality',       'icon' => 'shield-check',     'path' => 'modules/data-quality/index.php', 'perm' => 'dataquality.view', 'stage' => 5],
            ['key' => 'analytics',   'label' => 'Analytics',          'icon' => 'chart-column',     'path' => 'modules/analytics/index.php',    'perm' => 'analytics.view',   'stage' => 4],
        ],
        'Reporting' => [
            ['key' => 'reports',     'label' => 'Report Center',      'icon' => 'file-text',        'path' => 'modules/reports/index.php',      'perm' => 'reports.view',     'stage' => 6],
            ['key' => 'imphistory',  'label' => 'Riwayat Import',     'icon' => 'history',          'path' => 'modules/imports/history.php',    'perm' => 'import.history',   'stage' => 5],
        ],
        'Administration' => [
            ['key' => 'users',       'label' => 'User Management',    'icon' => 'user-cog',         'path' => 'modules/users/index.php',        'perm' => 'users.manage',     'stage' => 6],
            ['key' => 'auditlogs',   'label' => 'Activity Logs',      'icon' => 'scroll-text',      'path' => 'modules/audit-logs/index.php',   'perm' => 'audit.view',       'stage' => 6],
            ['key' => 'settings',    'label' => 'Pengaturan',         'icon' => 'settings',         'path' => 'modules/settings/index.php',     'perm' => 'settings.manage',  'stage' => 7],
        ],
    ];
}

/** Menu yang sudah difilter berdasarkan izin pengguna aktif. */
function nav_for_user(array $user): array
{
    $result = [];
    foreach (nav_definition() as $group => $items) {
        $visible = array_values(array_filter($items, fn ($i) => user_can($i['perm'], $user)));
        if ($visible) {
            $result[$group] = $visible;
        }
    }
    return $result;
}
