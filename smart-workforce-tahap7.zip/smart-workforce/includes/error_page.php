<?php
/** Template halaman error. Variabel: $code, $title, $message (diset oleh render_error_page). */
$home = url('index.php');
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?= e($code) ?> — <?= e($title) ?></title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="<?= e(url('assets/css/style.css')) ?>">
</head>
<body class="error-body">
    <main class="error-card">
        <div class="error-code"><?= e($code) ?></div>
        <h1><?= e($title) ?></h1>
        <p><?= e($message) ?></p>
        <a class="btn btn-primary" href="<?= e($home) ?>">Kembali ke beranda</a>
    </main>
</body>
</html>
