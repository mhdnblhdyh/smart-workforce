<?php
/** Topbar: tombol menu, breadcrumb, notifikasi kontrak vendor, profil pengguna. */
declare(strict_types=1);

$crumbs = $page['breadcrumb'] ?? [(string) ($page['title'] ?? '')];
$alerts = user_can('vendors.view', $user) ? contract_alerts() : [];
?>
<header class="topbar">
    <button type="button" class="icon-btn" id="sidebarToggle" aria-label="Buka/tutup menu" aria-controls="sidebar"><?= icon('menu') ?></button>

    <nav class="breadcrumb" aria-label="Breadcrumb">
        <ol>
        <?php foreach ($crumbs as $i => $label): $last = ($i === count($crumbs) - 1); ?>
            <li<?= $last ? ' aria-current="page"' : '' ?>><?= e($label) ?></li>
        <?php endforeach; ?>
        </ol>
    </nav>

    <div class="topbar-actions">
        <?php if (user_can('vendors.view', $user)): ?>
        <div class="dropdown">
            <button type="button" class="icon-btn" data-dropdown aria-expanded="false" aria-label="Notifikasi (<?= count($alerts) ?>)">
                <?= icon('bell') ?>
                <?php if ($alerts): ?><span class="dot-badge"><?= count($alerts) ?></span><?php endif; ?>
            </button>
            <div class="dropdown-menu dropdown-notif" hidden>
                <div class="dropdown-title">Notifikasi</div>
                <?php if (!$alerts): ?>
                    <p class="dropdown-empty">Tidak ada kontrak vendor yang perlu perhatian.</p>
                <?php else: ?>
                    <ul class="notif-list">
                    <?php foreach ($alerts as $a): ?>
                        <li>
                            <span class="notif-icon <?= $a['state'] === 'expired' ? 'is-danger' : 'is-warning' ?>"><?= icon('triangle-alert') ?></span>
                            <div>
                                <strong><?= e($a['name']) ?></strong>
                                <small>
                                    <?php if ($a['state'] === 'expired'): ?>
                                        Kontrak berakhir <?= e(abs((int) $a['days_left'])) ?> hari lalu (<?= e(date('d M Y', strtotime($a['contract_end']))) ?>), status vendor masih aktif.
                                    <?php else: ?>
                                        Kontrak berakhir <?= e(date('d M Y', strtotime($a['contract_end']))) ?> (<?= e((int) $a['days_left']) ?> hari lagi).
                                    <?php endif; ?>
                                </small>
                            </div>
                        </li>
                    <?php endforeach; ?>
                    </ul>
                <?php endif; ?>
            </div>
        </div>
        <?php endif; ?>

        <div class="dropdown">
            <button type="button" class="user-btn" data-dropdown aria-expanded="false" aria-label="Menu pengguna">
                <span class="avatar"><?= e(initials($user['name'])) ?></span>
                <span class="user-meta">
                    <strong><?= e($user['name']) ?></strong>
                    <small><?= e(role_label($user['role'])) ?></small>
                </span>
                <?= icon('chevron-down', 'user-caret') ?>
            </button>
            <div class="dropdown-menu dropdown-user" hidden>
                <div class="dropdown-profile">
                    <strong><?= e($user['name']) ?></strong>
                    <small><?= e($user['email']) ?></small>
                    <span class="badge badge-<?= e($user['role']) ?>"><?= e(role_label($user['role'])) ?></span>
                </div>
                <a class="dropdown-item" href="<?= e(url('change-password.php')) ?>"><?= icon('lock') ?>Ganti password</a>
                <form method="post" action="<?= e(url('logout.php')) ?>">
                    <?= csrf_field() ?>
                    <button type="submit" class="dropdown-item"><?= icon('log-out') ?>Keluar</button>
                </form>
            </div>
        </div>
    </div>
</header>
