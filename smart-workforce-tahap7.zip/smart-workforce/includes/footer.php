<?php
/** Penutup layout: footer, toast container, flash message, dan skrip. */
declare(strict_types=1);

$flashes = flash_get();
?>
        </main>
        <footer class="app-footer">
            <span>© <?= e(date('Y')) ?> <?= e((string) app_config('app_name')) ?></span>
            <span>Data demo bersifat fiktif</span>
        </footer>
    </div>
</div>

<div class="toast-region" id="toastRegion" aria-live="polite" aria-atomic="false"></div>
<?php /* Flash message ditampilkan sebagai toast. JSON_HEX_* mencegah penutupan tag script dari data. */ ?>
<script type="application/json" id="flashData"><?= json_encode($flashes, JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_UNESCAPED_UNICODE) ?></script>

<?php if (!empty($page['chart'])): ?>
<script src="<?= e(url('assets/js/vendor/chart.umd.js')) ?>"></script>
<?php endif; ?>
<script>window.SWA_CSRF = <?= json_encode(csrf_token()) ?>;</script>
<script src="<?= e(url('assets/js/app.js')) ?>"></script>
<?php foreach (($page['js'] ?? []) as $js): ?>
<script src="<?= e(url('assets/js/' . $js)) ?>"></script>
<?php endforeach; ?>
</body>
</html>
