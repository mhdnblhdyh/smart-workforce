<?php
/**
 * Audit log. Aplikasi HANYA melakukan INSERT ke tabel audit_logs (tidak ada fitur edit/hapus).
 * JANGAN menyertakan password, token, atau data sensitif pada $description.
 */
declare(strict_types=1);

function audit_log(string $action, ?string $entityType = null, ?int $entityId = null, ?string $description = null, ?int $userId = null): void
{
    try {
        $userId ??= isset($_SESSION['user_id']) ? (int) $_SESSION['user_id'] : null;
        db_run(
            'INSERT INTO audit_logs (user_id, action, entity_type, entity_id, description, ip_address, user_agent)
             VALUES (?, ?, ?, ?, ?, ?, ?)',
            'ississs',
            [
                $userId,
                mb_substr($action, 0, 50),
                $entityType,
                $entityId,
                $description !== null ? mb_substr($description, 0, 500) : null,
                client_ip(),
                user_agent(),
            ]
        );
    } catch (Throwable $e) {
        // Kegagalan pencatatan log tidak boleh menggagalkan aksi utama.
        error_log('[AUDIT] Gagal mencatat log: ' . $e->getMessage());
    }
}
