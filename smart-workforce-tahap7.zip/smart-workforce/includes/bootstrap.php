<?php
/**
 * Bootstrap — WAJIB di-require paling awal oleh setiap halaman/endpoint.
 * Tugas: konfigurasi error, timezone, session aman, header keamanan, memuat helper.
 */
declare(strict_types=1);

define('BASE_PATH', dirname(__DIR__));

require_once BASE_PATH . '/config/config.php';
require_once BASE_PATH . '/config/db.php';
require_once BASE_PATH . '/includes/functions.php';
require_once BASE_PATH . '/includes/csrf.php';
require_once BASE_PATH . '/includes/audit.php';
require_once BASE_PATH . '/includes/password.php';
require_once BASE_PATH . '/includes/auth.php';
require_once BASE_PATH . '/includes/domain.php';
require_once BASE_PATH . '/includes/navigation.php';
require_once BASE_PATH . '/includes/listing.php';
require_once BASE_PATH . '/includes/validation.php';
require_once BASE_PATH . '/includes/stats.php';
require_once BASE_PATH . '/includes/components.php';

date_default_timezone_set((string) app_config('timezone', 'Asia/Jakarta'));

// ---- Konfigurasi error: detail hanya tampil saat development ----
$isDev = app_config('app_env') === 'development';
error_reporting(E_ALL);
ini_set('display_errors', $isDev ? '1' : '0');
ini_set('log_errors', '1');

// Exception yang tidak tertangani -> log + halaman 500 generik (tanpa detail DB).
set_exception_handler(function (Throwable $e): void {
    error_log('[APP] ' . get_class($e) . ': ' . $e->getMessage() . ' @ ' . $e->getFile() . ':' . $e->getLine());
    if (!headers_sent()) {
        http_response_code(500);
    }
    if (app_config('app_env') === 'development') {
        echo '<pre style="padding:16px;font:13px monospace;white-space:pre-wrap">'
            . e(get_class($e) . ': ' . $e->getMessage() . "\n" . $e->getTraceAsString()) . '</pre>';
        exit;
    }
    render_error_page(500);
});

// ---- Header keamanan dasar ----
if (!headers_sent()) {
    header('X-Frame-Options: DENY');
    header('X-Content-Type-Options: nosniff');
    header('Referrer-Policy: strict-origin-when-cross-origin');
    header('Permissions-Policy: camera=(), microphone=(), geolocation=()');
}

// ---- Session aman ----
if (session_status() === PHP_SESSION_NONE) {
    $https = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off')
          || (($_SERVER['SERVER_PORT'] ?? '') === '443');

    session_name((string) app_config('session.name', 'SWA_SESSION'));
    session_set_cookie_params([
        'lifetime' => 0,           // cookie hilang saat browser ditutup
        'path'     => '/',
        'secure'   => $https,
        'httponly' => true,        // tidak dapat dibaca JavaScript
        'samesite' => 'Lax',
    ]);
    ini_set('session.use_strict_mode', '1');
    ini_set('session.use_only_cookies', '1');
    session_start();
}
