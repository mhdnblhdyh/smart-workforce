<?php
/**
 * Autentikasi & otorisasi (RBAC).
 * Seluruh pemeriksaan dilakukan di SERVER pada setiap request — menyembunyikan tombol di frontend
 * hanya kosmetik dan TIDAK dianggap sebagai pengamanan.
 */
declare(strict_types=1);

/**
 * Matriks izin per role. Ubah di sini jika kebijakan akses berubah.
 * Admin memakai wildcard '*'.
 */
const ROLE_PERMISSIONS = [
    'admin' => ['*'],
    'hc_staff' => [
        'dashboard.view',
        'employees.view', 'employees.manage',
        'departments.view', 'departments.manage',
        'vendors.view', 'vendors.manage',
        'mandays.view', 'mandays.manage',
        'import.run', 'import.history',
        'dataquality.view',
        'analytics.view',
        'reports.view', 'reports.export',
    ],
    'viewer' => [
        'dashboard.view',
        'employees.view', 'departments.view', 'vendors.view', 'mandays.view',
        'dataquality.view',
        'analytics.view',
        'reports.view',
    ],
];

/** Daftar seluruh izin yang dikenal (dipakai untuk menampilkan matriks akses). */
const ALL_PERMISSIONS = [
    'dashboard.view'     => 'Melihat dashboard',
    'employees.view'     => 'Melihat data tenaga kerja',
    'employees.manage'   => 'Tambah/ubah/hapus tenaga kerja',
    'departments.view'   => 'Melihat departemen',
    'departments.manage' => 'Kelola departemen',
    'vendors.view'       => 'Melihat vendor',
    'vendors.manage'     => 'Kelola vendor',
    'mandays.view'       => 'Melihat mandays',
    'mandays.manage'     => 'Kelola mandays',
    'import.run'         => 'Import Excel',
    'import.history'     => 'Riwayat import',
    'dataquality.view'   => 'Melihat data quality',
    'analytics.view'     => 'Melihat analytics',
    'reports.view'       => 'Melihat laporan',
    'reports.export'     => 'Export laporan',
    'users.manage'       => 'Kelola pengguna',
    'audit.view'         => 'Melihat audit log',
    'settings.manage'    => 'Pengaturan sistem',
];

/**
 * Pengguna yang sedang login (dimuat ulang dari DB sekali per request,
 * sehingga perubahan role/status langsung berlaku). Null jika belum login.
 */
function current_user(): ?array
{
    static $loaded = false;
    static $user = null;

    if ($loaded) {
        return $user;
    }
    $loaded = true;

    if (empty($_SESSION['user_id'])) {
        return null;
    }

    // Timeout karena tidak aktif
    $idle = (int) app_config('session.idle_timeout', 1800);
    if (isset($_SESSION['last_activity']) && (time() - (int) $_SESSION['last_activity']) > $idle) {
        auth_clear_session();
        session_start();
        flash_set('warning', 'Sesi Anda berakhir karena tidak ada aktivitas. Silakan masuk kembali.');
        return null;
    }

    // SELECT * agar tetap berjalan sebelum migrasi Tahap 6 diterapkan (kolom baru dianggap kosong).
    $row = db_fetch_one('SELECT * FROM users WHERE id = ? LIMIT 1', 'i', [(int) $_SESSION['user_id']]);
    if ($row !== null) {
        unset($row['password_hash']);   // hash tidak pernah dibawa-bawa di luar proses login
    }

    if ($row === null || $row['status'] !== 'active') {
        auth_clear_session();
        session_start();
        return null;
    }

    // Password diubah/direset setelah sesi ini dibuat -> sesi lama dicabut.
    if (!empty($row['password_changed_at']) && strtotime((string) $row['password_changed_at']) > (int) ($_SESSION['login_at'] ?? 0)) {
        auth_clear_session();
        session_start();
        flash_set('warning', 'Password akun Anda telah diubah. Silakan masuk kembali.');
        return null;
    }

    $_SESSION['last_activity'] = time();
    $user = $row;
    return $user;
}

function is_logged_in(): bool
{
    return current_user() !== null;
}

/** Hancurkan sesi sepenuhnya (data + cookie). Panggil session_start() lagi jika butuh flash. */
function auth_clear_session(): void
{
    $_SESSION = [];
    if (ini_get('session.use_cookies')) {
        $p = session_get_cookie_params();
        setcookie(session_name(), '', [
            'expires'  => time() - 42000,
            'path'     => $p['path'],
            'domain'   => $p['domain'],
            'secure'   => $p['secure'],
            'httponly' => $p['httponly'],
            'samesite' => $p['samesite'] ?? 'Lax',
        ]);
    }
    session_destroy();
}

/**
 * Halaman internal: wajib login, jika tidak -> redirect ke login (menyimpan tujuan semula).
 * Pengguna yang wajib mengganti password hanya boleh membuka halaman ganti password (atau keluar).
 */
function require_login(bool $json = false, bool $allowPasswordChange = false): array
{
    $user = current_user();
    if ($user === null) {
        if ($json) {
            json_response(['success' => false, 'message' => 'Sesi berakhir. Silakan login kembali.'], 401);
        }
        $target = $_SERVER['REQUEST_URI'] ?? '';
        $query  = safe_redirect_target($target) !== null ? '?next=' . rawurlencode($target) : '';
        redirect('login.php' . $query);
    }
    if (!empty($user['must_change_password']) && !$allowPasswordChange) {
        if ($json) {
            json_response(['success' => false, 'code' => 'password_change_required', 'message' => 'Anda harus mengganti password terlebih dahulu.'], 403);
        }
        redirect('change-password.php');
    }
    return $user;
}

function user_can(string $permission, ?array $user = null): bool
{
    $user ??= current_user();
    if ($user === null) {
        return false;
    }
    $granted = ROLE_PERMISSIONS[$user['role']] ?? [];
    return in_array('*', $granted, true) || in_array($permission, $granted, true);
}

/** Wajib login DAN memiliki izin tertentu. Mengembalikan data user. */
function require_permission(string $permission, bool $json = false): array
{
    $user = require_login($json);
    if (!user_can($permission, $user)) {
        audit_log('access_denied', null, null, 'Izin ditolak: ' . $permission . ' @ ' . ($_SERVER['REQUEST_URI'] ?? ''));
        if ($json) {
            json_response(['success' => false, 'message' => 'Anda tidak memiliki izin untuk aksi ini.'], 403);
        }
        render_error_page(403);
    }
    return $user;
}

/** Wajib salah satu role tertentu. */
function require_role(array $roles, bool $json = false): array
{
    $user = require_login($json);
    if (!in_array($user['role'], $roles, true)) {
        audit_log('access_denied', null, null, 'Role ditolak @ ' . ($_SERVER['REQUEST_URI'] ?? ''));
        if ($json) {
            json_response(['success' => false, 'message' => 'Anda tidak memiliki izin untuk aksi ini.'], 403);
        }
        render_error_page(403);
    }
    return $user;
}

/**
 * Proses login. Mengembalikan true jika berhasil.
 * Semua kegagalan memakai pesan yang sama di UI (tidak membocorkan apakah email terdaftar/terkunci/nonaktif).
 */
function auth_attempt(string $email, string $password): bool
{
    $max     = (int) app_config('security.max_login_attempts', 5);
    $lockMin = (int) app_config('security.lockout_minutes', 15);

    $user = db_fetch_one(
        'SELECT id, password_hash, status, failed_login_attempts, locked_until FROM users WHERE email = ? LIMIT 1',
        's',
        [$email]
    );

    // Selalu jalankan password_verify agar waktu respons relatif sama.
    $hash  = $user['password_hash'] ?? DUMMY_PASSWORD_HASH;
    $valid = password_verify($password, $hash);

    if ($user === null) {
        audit_log('login_failed', 'user', null, 'Login gagal: email tidak dikenal (' . mb_substr($email, 0, 100) . ')', null);
        return false;
    }

    $uid    = (int) $user['id'];
    $locked = $user['locked_until'] !== null && strtotime($user['locked_until']) > time();

    if ($locked) {
        audit_log('login_failed', 'user', $uid, 'Login ditolak: akun terkunci sementara', $uid);
        return false;
    }

    if (!$valid || $user['status'] !== 'active') {
        if (!$valid) {
            $attempts = (int) $user['failed_login_attempts'] + 1;
            if ($attempts >= $max) {
                db_run(
                    'UPDATE users SET failed_login_attempts = 0, locked_until = DATE_ADD(NOW(), INTERVAL ? MINUTE) WHERE id = ?',
                    'ii',
                    [$lockMin, $uid]
                );
                audit_log('account_locked', 'user', $uid, "Akun dikunci {$lockMin} menit setelah {$max} kegagalan login", $uid);
            } else {
                db_run('UPDATE users SET failed_login_attempts = ? WHERE id = ?', 'ii', [$attempts, $uid]);
            }
        }
        audit_log('login_failed', 'user', $uid, $valid ? 'Login ditolak: akun nonaktif' : 'Login gagal: password salah', $uid);
        return false;
    }

    // Upgrade hash otomatis bila algoritma default PHP berubah.
    if (password_needs_rehash($hash, PASSWORD_DEFAULT)) {
        db_run('UPDATE users SET password_hash = ? WHERE id = ?', 'si', [password_hash($password, PASSWORD_DEFAULT), $uid]);
    }

    // Berhasil: cegah session fixation.
    session_regenerate_id(true);
    $_SESSION['user_id']       = $uid;
    $_SESSION['last_activity'] = time();
    $_SESSION['login_at']      = time();
    unset($_SESSION['csrf_token']); // token baru untuk sesi baru

    db_run('UPDATE users SET failed_login_attempts = 0, locked_until = NULL, last_login_at = NOW() WHERE id = ?', 'i', [$uid]);
    audit_log('login_success', 'user', $uid, 'Login berhasil', $uid);
    return true;
}
