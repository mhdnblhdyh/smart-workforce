<?php
/**
 * Kebijakan password, pembuat password sementara, dan helper kolom keamanan akun.
 */
declare(strict_types=1);

const PASSWORD_MIN_LENGTH = 10;

/** Apakah migrasi Tahap 6 (kolom must_change_password & password_changed_at) sudah diterapkan? */
function users_has_security_columns(): bool
{
    static $has = null;
    if ($has === null) {
        $has = db_fetch_one("SHOW COLUMNS FROM users LIKE 'must_change_password'") !== null
            && db_fetch_one("SHOW COLUMNS FROM users LIKE 'password_changed_at'") !== null;
    }
    return $has;
}

/**
 * Periksa kekuatan password. @return string[] daftar pesan kesalahan (kosong = lolos)
 */
function password_policy_errors(string $pw, string $email = '', string $name = ''): array
{
    $e = [];
    if (mb_strlen($pw) < PASSWORD_MIN_LENGTH) {
        $e[] = 'Minimal ' . PASSWORD_MIN_LENGTH . ' karakter.';
    }
    if (strlen($pw) > 200) {
        $e[] = 'Maksimal 200 karakter.';
    }
    if (!preg_match('/\p{L}/u', $pw) || !preg_match('/\d/', $pw)) {
        $e[] = 'Harus mengandung huruf dan angka.';
    }
    $lower = mb_strtolower($pw);
    $local = mb_strtolower(explode('@', $email)[0] ?? '');
    if (mb_strlen($local) >= 4 && str_contains($lower, $local)) {
        $e[] = 'Tidak boleh mengandung bagian nama email Anda.';
    }
    foreach (['password', 'katasandi', '12345678', 'qwerty', 'admin123', 'abcdefgh'] as $weak) {
        if (str_contains($lower, $weak)) {
            $e[] = 'Terlalu mudah ditebak.';
            break;
        }
    }
    return $e;
}

/** Password sementara acak (14 karakter, tanpa karakter yang mudah tertukar) yang selalu lolos kebijakan. */
function generate_temp_password(int $length = 14): string
{
    $sets = ['ABCDEFGHJKLMNPQRSTUVWXYZ', 'abcdefghijkmnopqrstuvwxyz', '23456789', '!@#$%*?'];
    $all  = implode('', $sets);
    $chars = [];
    foreach ($sets as $set) {
        $chars[] = $set[random_int(0, strlen($set) - 1)];
    }
    while (count($chars) < $length) {
        $chars[] = $all[random_int(0, strlen($all) - 1)];
    }
    for ($i = count($chars) - 1; $i > 0; $i--) {   // Fisher-Yates dengan CSPRNG
        $j = random_int(0, $i);
        [$chars[$i], $chars[$j]] = [$chars[$j], $chars[$i]];
    }
    return implode('', $chars);
}
