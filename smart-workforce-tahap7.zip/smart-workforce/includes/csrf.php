<?php
/**
 * Proteksi CSRF berbasis token sesi.
 * Form:   <?= csrf_field() ?>
 * AJAX:   header 'X-CSRF-Token' berisi csrf_token()
 * Server: csrf_require() di awal setiap aksi POST yang mengubah data.
 */
declare(strict_types=1);

function csrf_token(): string
{
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

function csrf_field(): string
{
    return '<input type="hidden" name="csrf_token" value="' . e(csrf_token()) . '">';
}

function csrf_valid(?string $token): bool
{
    return is_string($token) && $token !== ''
        && isset($_SESSION['csrf_token'])
        && hash_equals($_SESSION['csrf_token'], $token);
}

/** Hentikan request (HTTP 419) jika token form/header tidak valid. */
function csrf_require(bool $json = false): void
{
    $token = $_POST['csrf_token'] ?? ($_SERVER['HTTP_X_CSRF_TOKEN'] ?? null);
    if (csrf_valid(is_string($token) ? $token : null)) {
        return;
    }
    audit_log('csrf_failed', null, null, 'Token CSRF tidak valid pada ' . ($_SERVER['REQUEST_URI'] ?? ''));
    if ($json) {
        json_response(['success' => false, 'message' => 'Token keamanan tidak valid. Muat ulang halaman.'], 419);
    }
    render_error_page(419);
}
