<?php
/**
 * Fungsi bantu umum (escape output, URL, redirect, flash message, JSON, format).
 */
declare(strict_types=1);

/** Escape output HTML. Gunakan untuk SEMUA data dinamis yang dicetak ke HTML. */
function e($value): string
{
    return htmlspecialchars((string) $value, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

/** URL absolut-path aplikasi, mis. url('login.php') -> /smart-workforce/login.php */
function url(string $path = ''): string
{
    $base = rtrim((string) app_config('base_url', ''), '/');
    return $base . '/' . ltrim($path, '/');
}

function redirect(string $path): void
{
    header('Location: ' . url($path));
    exit;
}

/**
 * Cegah open redirect: hanya terima path internal (diawali satu '/', bukan '//' atau skema).
 * Mengembalikan path relatif terhadap base_url, atau null jika tidak aman.
 */
function safe_redirect_target(?string $target): ?string
{
    if ($target === null || $target === '') {
        return null;
    }
    if (preg_match('#^[a-z][a-z0-9+.-]*:#i', $target) || str_starts_with($target, '//') || str_contains($target, '\\')) {
        return null;
    }
    if (preg_match('/[\x00-\x1F\x7F]/', $target)) {
        return null;
    }
    $base = rtrim((string) app_config('base_url', ''), '/');
    if ($base !== '' && str_starts_with($target, $base . '/')) {
        $target = substr($target, strlen($base));
    }
    return str_starts_with($target, '/') ? ltrim($target, '/') : null;
}

// ---------- Flash message (pesan satu kali tampil) ----------
function flash_set(string $type, string $message): void
{
    $_SESSION['flash'][] = ['type' => $type, 'message' => $message];
}

function flash_get(): array
{
    $messages = $_SESSION['flash'] ?? [];
    unset($_SESSION['flash']);
    return $messages;
}

// ---------- Request ----------
function is_post(): bool
{
    return ($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'POST';
}

/** Ambil input POST bertipe string, di-trim. */
function post_str(string $key, int $maxLen = 255): string
{
    $v = $_POST[$key] ?? '';
    return is_string($v) ? mb_substr(trim($v), 0, $maxLen) : '';
}

function client_ip(): string
{
    // Sengaja hanya REMOTE_ADDR: header X-Forwarded-For mudah dipalsukan jika tidak ada reverse proxy tepercaya.
    return substr((string) ($_SERVER['REMOTE_ADDR'] ?? ''), 0, 45);
}

function user_agent(): string
{
    return substr((string) ($_SERVER['HTTP_USER_AGENT'] ?? ''), 0, 255);
}

function json_response(array $data, int $status = 200): void
{
    http_response_code($status);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

// ---------- Label tampilan ----------
function role_label(string $role): string
{
    return ['admin' => 'Admin', 'hc_staff' => 'HC Staff', 'viewer' => 'Viewer'][$role] ?? $role;
}

function initials(string $name): string
{
    $parts = preg_split('/\s+/', trim($name)) ?: [];
    $out = '';
    foreach (array_slice($parts, 0, 2) as $p) {
        $out .= mb_strtoupper(mb_substr($p, 0, 1));
    }
    return $out !== '' ? $out : '?';
}

function format_datetime(?string $value): string
{
    if (!$value) {
        return '-';
    }
    $ts = strtotime($value);
    return $ts ? date('d M Y, H:i', $ts) : '-';
}

// ---------- Halaman error ----------
function render_error_page(int $code): void
{
    $titles = [
        403 => ['Akses ditolak', 'Anda tidak memiliki izin untuk membuka halaman ini.'],
        404 => ['Halaman tidak ditemukan', 'Halaman yang Anda cari tidak ada atau sudah dipindahkan.'],
        419 => ['Sesi formulir kedaluwarsa', 'Token keamanan tidak valid. Muat ulang halaman lalu coba lagi.'],
        500 => ['Terjadi kesalahan', 'Terjadi kesalahan pada server. Silakan coba lagi beberapa saat.'],
    ];
    [$title, $message] = $titles[$code] ?? $titles[500];
    if (!headers_sent()) {
        http_response_code($code);
    }
    require BASE_PATH . '/includes/error_page.php';
    exit;
}

/** Ikon Lucide dari sprite lokal (assets/images/icons.svg). */
function icon(string $name, string $class = ''): string
{
    $name = preg_replace('/[^a-z0-9-]/', '', $name);
    return '<svg class="icon ' . e($class) . '" aria-hidden="true" focusable="false"><use href="'
        . e(url('assets/images/icons.svg')) . '#' . $name . '"></use></svg>';
}

/** Format angka gaya Indonesia (1.234,5). Desimal hanya ditampilkan bila perlu. */
function format_number($n, int $maxDecimals = 1): string
{
    $n = (float) $n;
    $decimals = (abs($n - round($n)) < 0.005) ? 0 : $maxDecimals;
    return number_format($n, $decimals, ',', '.');
}
