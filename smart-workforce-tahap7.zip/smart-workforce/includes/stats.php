<?php
/**
 * Statistik tenaga kerja & mandays lintas filter — dipakai Analytics dan Rekap Mandays.
 * Seluruh angka dihitung di MySQL.
 *
 * DEFINISI (sama dengan Dashboard):
 *  - "Aktif pada bulan M" : start_date <= akhir bulan M DAN (end_date NULL ATAU end_date >= awal bulan M).
 *  - "Mandays"            : SUM(workforce_records.mandays) pada bulan terkait. BUKAN jumlah karyawan.
 *  - "Record lengkap"     : jabatan terisi, TAD punya vendor, magang punya tanggal berakhir, dan ada record mandays di bulan M.
 *  - GRANULARITAS         : bulanan. Rentang periode selalu dalam satuan bulan agar sejenis dengan data mandays.
 *  - Filter "status"      : status tenaga kerja saat ini (kolom employees.status), bukan status historis.
 */
declare(strict_types=1);

const STATS_MAX_MONTHS = 24;
const STATS_DEFAULT_MONTHS = 6;

/** 'YYYY-MM' valid atau null. */
function stats_parse_month($raw): ?string
{
    return (is_string($raw) && preg_match('/^(20\d{2}|2100)-(0[1-9]|1[0-2])$/', $raw)) ? $raw : null;
}

function stats_shift_month(string $ym, int $delta): string
{
    return date('Y-m', strtotime($ym . '-01 ' . sprintf('%+d', $delta) . ' month'));
}

/** Daftar 'YYYY-MM' dari $from s.d. $to (inklusif). */
function stats_months(string $from, string $to): array
{
    $out = [];
    for ($m = $from; $m <= $to && count($out) < 120; $m = stats_shift_month($m, 1)) {
        $out[] = $m;
    }
    return $out;
}

function stats_month_diff(string $from, string $to): int
{
    return ((int) substr($to, 0, 4) - (int) substr($from, 0, 4)) * 12 + ((int) substr($to, 5, 2) - (int) substr($from, 5, 2));
}

/** Bulan yang bisa dipilih pada filter (bulan yang punya data mandays + bulan berjalan), terbaru dulu. */
function stats_available_months(): array
{
    $months = array_column(db_fetch_all("SELECT DISTINCT DATE_FORMAT(period_month, '%Y-%m') AS ym FROM workforce_records ORDER BY ym DESC"), 'ym');
    $now = date('Y-m');
    if (!in_array($now, $months, true)) {
        array_unshift($months, $now);
    }
    return $months;
}

function stats_latest_month(): string
{
    return db_value("SELECT DATE_FORMAT(MAX(period_month), '%Y-%m') FROM workforce_records") ?: date('Y-m');
}

/**
 * Filter dari query string. Rentang dibalik jika terbalik dan dibatasi maksimum 24 bulan; keduanya
 * dilaporkan lewat 'notices'.
 */
function stats_parse_filters(): array
{
    $g = fn (string $k): string => (isset($_GET[$k]) && is_string($_GET[$k])) ? trim($_GET[$k]) : '';
    $notices = [];

    $to   = stats_parse_month($g('to')) ?? stats_latest_month();
    $from = stats_parse_month($g('from')) ?? stats_shift_month($to, -(STATS_DEFAULT_MONTHS - 1));
    if ($from > $to) {
        [$from, $to] = [$to, $from];
        $notices[] = 'Periode awal lebih besar dari periode akhir, rentang dibalik otomatis.';
    }
    if (stats_month_diff($from, $to) + 1 > STATS_MAX_MONTHS) {
        $from = stats_shift_month($to, -(STATS_MAX_MONTHS - 1));
        $notices[] = 'Rentang dibatasi maksimum ' . STATS_MAX_MONTHS . ' bulan; periode awal disesuaikan.';
    }

    return [
        'from'     => $from,
        'to'       => $to,
        'dept'     => ctype_digit($g('dept')) ? (int) $g('dept') : 0,
        'vendor'   => ctype_digit($g('vendor')) ? (int) $g('vendor') : 0,
        'category' => in_array($g('category'), ['employee', 'tad', 'intern'], true) ? $g('category') : '',
        'status'   => in_array($g('status'), ['active', 'inactive', 'completed'], true) ? $g('status') : '',
        'notices'  => $notices,
    ];
}

/** Kondisi tambahan pada alias e (employees). Diawali ' AND ' bila ada. @return array{0:string,1:string,2:array} */
function stats_emp_cond(array $f): array
{
    $w = []; $t = ''; $p = [];
    if (($f['dept'] ?? 0) > 0)      { $w[] = 'e.department_id = ?'; $t .= 'i'; $p[] = $f['dept']; }
    if (($f['vendor'] ?? 0) > 0)    { $w[] = 'e.vendor_id = ?';     $t .= 'i'; $p[] = $f['vendor']; }
    if (($f['category'] ?? '') !== '') { $w[] = 'e.category = ?';   $t .= 's'; $p[] = $f['category']; }
    if (($f['status'] ?? '') !== '')   { $w[] = 'e.status = ?';     $t .= 's'; $p[] = $f['status']; }
    return [$w ? ' AND ' . implode(' AND ', $w) : '', $t, $p];
}

/** Perubahan persen; null jika pembanding 0 (tidak terdefinisi). */
function pct_change(float $cur, float $prev): ?float
{
    return abs($prev) < 1e-9 ? null : ($cur - $prev) / $prev * 100;
}

/**
 * Tren tenaga kerja per bulan: total, per kategori, dan jumlah record lengkap.
 * @return array<string,array{total:int,employee:int,tad:int,intern:int,complete:int}>
 */
function stats_workforce_series(array $months, array $f): array
{
    if (!$months) {
        return [];
    }
    [$cond, $ct, $cp] = stats_emp_cond($f);
    $union = implode(' UNION ALL ', array_fill(0, count($months), 'SELECT CAST(? AS DATE) AS ms'));
    $sql = "SELECT m.ms, COUNT(e.id) AS total,
                   COALESCE(SUM(e.category = 'employee'), 0) AS employee,
                   COALESCE(SUM(e.category = 'tad'), 0) AS tad,
                   COALESCE(SUM(e.category = 'intern'), 0) AS intern,
                   COALESCE(SUM(
                       e.position IS NOT NULL AND e.position <> ''
                       AND (e.category <> 'tad' OR e.vendor_id IS NOT NULL)
                       AND (e.category <> 'intern' OR e.end_date IS NOT NULL)
                       AND EXISTS (SELECT 1 FROM workforce_records r WHERE r.employee_id = e.id AND r.period_month = m.ms)
                   ), 0) AS complete
            FROM ({$union}) m
            LEFT JOIN employees e ON e.start_date <= LAST_DAY(m.ms) AND (e.end_date IS NULL OR e.end_date >= m.ms){$cond}
            GROUP BY m.ms ORDER BY m.ms";
    $params = array_merge(array_map(fn ($m) => $m . '-01', $months), $cp);
    $out = [];
    foreach ($months as $m) {
        $out[$m] = ['total' => 0, 'employee' => 0, 'tad' => 0, 'intern' => 0, 'complete' => 0];
    }
    foreach (db_fetch_all($sql, str_repeat('s', count($months)) . $ct, $params) as $r) {
        $out[substr($r['ms'], 0, 7)] = array_map('intval', array_intersect_key($r, $out[$months[0]]));
    }
    return $out;
}

/**
 * Mandays per bulan pada rentang. Bulan tanpa record bernilai nol dengan records = 0.
 * @return array<string,array{mandays:float,records:int,workers:int,with_attendance:int}>
 */
function stats_mandays_series(array $months, array $f): array
{
    $out = [];
    foreach ($months as $m) {
        $out[$m] = ['mandays' => 0.0, 'records' => 0, 'workers' => 0, 'with_attendance' => 0];
    }
    if (!$months) {
        return $out;
    }
    [$cond, $ct, $cp] = stats_emp_cond($f);
    $rows = db_fetch_all(
        "SELECT DATE_FORMAT(r.period_month, '%Y-%m') AS ym, COALESCE(SUM(r.mandays), 0) AS mandays, COUNT(*) AS records,
                COUNT(DISTINCT r.employee_id) AS workers,
                COALESCE(SUM(r.attended_days IS NOT NULL AND r.scheduled_days IS NOT NULL), 0) AS with_attendance
         FROM workforce_records r JOIN employees e ON e.id = r.employee_id
         WHERE r.period_month BETWEEN ? AND ?{$cond}
         GROUP BY ym",
        'ss' . $ct,
        array_merge([$months[0] . '-01', end($months) . '-01'], $cp)
    );
    foreach ($rows as $r) {
        if (isset($out[$r['ym']])) {
            $out[$r['ym']] = ['mandays' => (float) $r['mandays'], 'records' => (int) $r['records'], 'workers' => (int) $r['workers'], 'with_attendance' => (int) $r['with_attendance']];
        }
    }
    return $out;
}

/** Mandays total pada rentang, dikelompokkan per departemen atau vendor. $by: 'department' | 'vendor'. */
function stats_mandays_by_group(string $from, string $to, array $f, string $by): array
{
    [$cond, $ct, $cp] = stats_emp_cond($f);
    if ($by === 'vendor') {
        $join = 'JOIN vendors g ON g.id = e.vendor_id';
    } elseif ($by === 'department') {
        $join = 'JOIN departments g ON g.id = e.department_id';
    } else {
        throw new InvalidArgumentException('Pengelompokan tidak dikenal.');
    }
    return db_fetch_all(
        "SELECT g.code, g.name, COALESCE(SUM(r.mandays), 0) AS mandays, COUNT(*) AS records, COUNT(DISTINCT r.employee_id) AS workers
         FROM workforce_records r JOIN employees e ON e.id = r.employee_id {$join}
         WHERE r.period_month BETWEEN ? AND ?{$cond}
         GROUP BY g.id, g.code, g.name ORDER BY mandays DESC, g.name ASC",
        'ss' . $ct,
        array_merge([$from . '-01', $to . '-01'], $cp)
    );
}

/** Tenaga kerja aktif pada bulan $ym, per departemen atau vendor. */
function stats_snapshot_by_group(string $ym, array $f, string $by): array
{
    [$cond, $ct, $cp] = stats_emp_cond($f);
    $ms = $ym . '-01';
    if ($by === 'vendor') {
        $table = 'vendors'; $fk = 'vendor_id'; $filter = ($f['vendor'] ?? 0) > 0 ? ' AND g.id = ' . (int) $f['vendor'] : '';
    } elseif ($by === 'department') {
        $table = 'departments'; $fk = 'department_id'; $filter = ($f['dept'] ?? 0) > 0 ? ' AND g.id = ' . (int) $f['dept'] : '';
    } else {
        throw new InvalidArgumentException('Pengelompokan tidak dikenal.');
    }
    return db_fetch_all(
        "SELECT g.code, g.name, COUNT(e.id) AS total
         FROM {$table} g
         LEFT JOIN employees e ON e.{$fk} = g.id AND e.start_date <= LAST_DAY(?) AND (e.end_date IS NULL OR e.end_date >= ?){$cond}
         WHERE (g.status = 'active' OR e.id IS NOT NULL){$filter}
         GROUP BY g.id, g.code, g.name ORDER BY total DESC, g.name ASC",
        'ss' . $ct,
        array_merge([$ms, $ms], $cp)
    );
}

/** Teks perubahan untuk tabel: "+12 (+8,3%)" atau keterangan bila pembanding nol. */
function ui_change(float $cur, float $prev, string $unit = '', int $dec = 1, bool $withPct = true): string
{
    $d = $cur - $prev;
    if (abs($d) < 0.005) {
        return '<span class="change change-flat">Tidak berubah</span>';
    }
    $sign  = $d > 0 ? '+' : '−';
    $class = $d > 0 ? 'change-up' : 'change-down';
    $pct   = pct_change($cur, $prev);
    $txt   = $sign . format_number(abs($d), $dec) . $unit;
    if ($withPct) {
        $txt .= $pct === null ? ' <small>(pembanding 0)</small>' : ' (' . $sign . number_format(abs($pct), 1, ',', '.') . '%)';
    }
    return '<span class="change ' . $class . '">' . $txt . '</span>';
}

/** Versi teks polos untuk ringkasan kalimat. */
function change_phrase(float $cur, float $prev, string $unit = ''): string
{
    $d = $cur - $prev;
    if (abs($d) < 0.005) {
        return 'tidak berubah';
    }
    $pct = pct_change($cur, $prev);
    return ($d > 0 ? 'naik ' : 'turun ') . format_number(abs($d)) . $unit . ($pct === null ? ' (periode sebelumnya bernilai 0)' : ' (' . number_format(abs($pct), 1, ',', '.') . '%)');
}

/** Total mandays pada rentang bulan (seluruh hasil filter): mandays, record, tenaga kerja unik, record dengan kehadiran lengkap. */
function stats_mandays_totals(string $from, string $to, array $f): array
{
    [$cond, $ct, $cp] = stats_emp_cond($f);
    $r = db_fetch_one(
        "SELECT COALESCE(SUM(r.mandays), 0) AS mandays, COUNT(*) AS records, COUNT(DISTINCT r.employee_id) AS workers,
                COALESCE(SUM(r.attended_days IS NOT NULL AND r.scheduled_days IS NOT NULL), 0) AS with_attendance
         FROM workforce_records r JOIN employees e ON e.id = r.employee_id
         WHERE r.period_month BETWEEN ? AND ?{$cond}",
        'ss' . $ct,
        array_merge([$from . '-01', $to . '-01'], $cp)
    );
    return ['mandays' => (float) $r['mandays'], 'records' => (int) $r['records'], 'workers' => (int) $r['workers'], 'with_attendance' => (int) $r['with_attendance']];
}

/** Filter select periode (dari/sampai) + departemen/vendor/kategori(/status) yang dipakai halaman rekap & analytics. */
function stats_filter_options(): array
{
    return [
        'months'      => stats_available_months(),
        'departments' => db_fetch_all('SELECT id, name FROM departments ORDER BY name'),
        'vendors'     => db_fetch_all('SELECT id, name FROM vendors ORDER BY name'),
    ];
}
