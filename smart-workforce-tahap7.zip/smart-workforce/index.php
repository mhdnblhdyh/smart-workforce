<?php
/**
 * Dashboard utama. Halaman hanya merender kerangka + filter;
 * seluruh angka & grafik diambil dari modules/dashboard/data.php (agregasi MySQL).
 */
declare(strict_types=1);
require_once __DIR__ . '/includes/bootstrap.php';
require_once __DIR__ . '/modules/dashboard/queries.php';

$user = require_permission('dashboard.view');

$period      = dash_parse_period($_GET['period'] ?? null);
$deptFilter  = dash_parse_department($_GET['dept'] ?? null);
$periodOpts  = dash_period_options();
if (!in_array($period, $periodOpts, true)) {
    array_unshift($periodOpts, $period);
}
$departments = db_fetch_all("SELECT id, code, name FROM departments ORDER BY name ASC");

$page = [
    'title'      => 'Dashboard',
    'active'     => 'dashboard',
    'breadcrumb' => ['Overview', 'Dashboard'],
    'css'        => ['dashboard.css'],
    'js'         => ['dashboard.js'],
    'chart'      => true,
];
require BASE_PATH . '/includes/header.php';
?>
<section id="dashboard" class="dashboard is-loading" data-endpoint="<?= e(url('modules/dashboard/data.php')) ?>" data-default-period="<?= e(dash_default_period()) ?>">

    <div class="page-header">
        <div>
            <h1>Dashboard</h1>
            <p class="page-sub" id="dashContext">Memuat data…</p>
        </div>

        <form class="filter-bar" id="filterForm" method="get" action="<?= e(url('index.php')) ?>">
            <label class="filter">
                <span>Periode</span>
                <select name="period" id="filterPeriod" class="form-select">
                    <?php foreach ($periodOpts as $ym): ?>
                        <option value="<?= e($ym) ?>"<?= $ym === $period ? ' selected' : '' ?>><?= e(month_label($ym)) ?></option>
                    <?php endforeach; ?>
                </select>
            </label>
            <label class="filter">
                <span>Departemen</span>
                <select name="dept" id="filterDept" class="form-select">
                    <option value="">Semua departemen</option>
                    <?php foreach ($departments as $d): ?>
                        <option value="<?= (int) $d['id'] ?>"<?= $deptFilter === (int) $d['id'] ? ' selected' : '' ?>><?= e($d['name']) ?></option>
                    <?php endforeach; ?>
                </select>
            </label>
            <button type="button" class="btn btn-outline btn-sm" id="filterReset" title="Kembali ke periode terbaru dan semua departemen"><?= icon('rotate-ccw') ?>Reset</button>
            <noscript><button type="submit" class="btn btn-primary btn-sm">Terapkan</button></noscript>
        </form>
    </div>

    <!-- Error state -->
    <div class="state-banner state-error" id="dashError" hidden role="alert">
        <?= icon('circle-alert') ?>
        <div><strong>Data dashboard gagal dimuat.</strong><span id="dashErrorMsg"></span></div>
        <button type="button" class="btn btn-outline btn-sm" id="dashRetry"><?= icon('refresh-cw') ?>Coba lagi</button>
    </div>

    <!-- Database kosong -->
    <div class="card" id="dashEmpty" hidden>
        <?= ui_empty_state('inbox', 'Belum ada data tenaga kerja', 'Database masih kosong. Semua angka bernilai nol sampai data tenaga kerja ditambahkan atau diimpor.') ?>
    </div>

    <!-- KPI -->
    <div class="kpi-grid" id="kpiGrid">
        <?= ui_kpi_card('headcount', 'Tenaga kerja aktif', 'users', 'Semua kategori') ?>
        <?= ui_kpi_card('tad', 'TAD aktif', 'briefcase') ?>
        <?= ui_kpi_card('intern', 'Peserta magang aktif', 'user') ?>
        <?= ui_kpi_card('departments', 'Departemen', 'building-2') ?>
        <?= ui_kpi_card('vendors', 'Vendor aktif', 'handshake') ?>
        <?= ui_kpi_card('mandays', 'Total mandays', 'calendar-check') ?>
        <?= ui_kpi_card('completeness', 'Kelengkapan data', 'shield-check') ?>
    </div>

    <details class="definitions">
        <summary><?= icon('info') ?>Cara perhitungan angka</summary>
        <ul>
            <li><strong>Aktif pada suatu bulan</strong>: tanggal mulai ≤ akhir bulan dan (tanggal berakhir kosong atau ≥ awal bulan). Berbasis tanggal agar periode lalu tetap akurat.</li>
            <li><strong>Mandays</strong>: jumlah hari kerja yang tercatat pada bulan tersebut (satu record = satu tenaga kerja per bulan). Bukan jumlah karyawan.</li>
            <li><strong>Kelengkapan data</strong>: persentase tenaga kerja aktif dengan jabatan terisi, TAD memiliki vendor, peserta magang memiliki tanggal berakhir, dan memiliki record mandays pada bulan tersebut.</li>
            <li><strong>Perbandingan</strong> ditampilkan terhadap bulan sebelumnya; tidak menyiratkan sebab-akibat.</li>
        </ul>
    </details>

    <!-- Grafik baris 1 -->
    <div class="grid grid-2-1">
        <article class="card chart-card">
            <header class="card-head">
                <div><h2>Tren tenaga kerja aktif</h2><p>12 bulan hingga <span data-bind="periodLabel">-</span></p></div>
            </header>
            <div class="chart-box"><canvas id="chartTrend" aria-label="Grafik garis tren tenaga kerja aktif per bulan" role="img"></canvas><div class="chart-empty" hidden><?= icon('inbox') ?><span>Belum ada data untuk ditampilkan</span></div></div>
        </article>
        <article class="card chart-card">
            <header class="card-head">
                <div><h2>Kategori tenaga kerja</h2><p><span data-bind="periodLabel">-</span></p></div>
            </header>
            <div class="chart-box"><canvas id="chartCategory" aria-label="Grafik donat kategori tenaga kerja" role="img"></canvas><div class="chart-empty" hidden><?= icon('inbox') ?><span>Belum ada data untuk ditampilkan</span></div></div>
        </article>
    </div>

    <!-- Grafik baris 2 -->
    <div class="grid grid-2">
        <article class="card chart-card">
            <header class="card-head">
                <div><h2>Tenaga kerja per departemen</h2><p>Aktif pada <span data-bind="periodLabel">-</span></p></div>
            </header>
            <div class="chart-box"><canvas id="chartDept" aria-label="Grafik batang tenaga kerja per departemen" role="img"></canvas><div class="chart-empty" hidden><?= icon('inbox') ?><span>Belum ada data untuk ditampilkan</span></div></div>
        </article>
        <article class="card chart-card">
            <header class="card-head">
                <div><h2>Mandays per departemen</h2><p>Total hari kerja tercatat, <span data-bind="periodLabel">-</span></p></div>
            </header>
            <div class="chart-box"><canvas id="chartMandays" aria-label="Grafik batang total mandays per departemen" role="img"></canvas><div class="chart-empty" hidden><?= icon('inbox') ?><span>Belum ada mandays pada periode ini</span></div></div>
        </article>
    </div>

    <!-- Data quality + vendor -->
    <div class="grid grid-1-2">
        <article class="card" id="qualityCard">
            <header class="card-head">
                <div><h2>Ringkasan data quality</h2><p>Data tidak diubah otomatis</p></div>
            </header>
            <div id="qualityBody"><div class="skeleton skeleton-block"></div></div>
        </article>
        <article class="card" id="vendorCard">
            <header class="card-head">
                <div><h2>Ringkasan per vendor</h2><p>TAD aktif dan mandays pada <span data-bind="periodLabel">-</span></p></div>
            </header>
            <div class="table-scroll" id="vendorBody"><div class="skeleton skeleton-block"></div></div>
        </article>
    </div>
</section>
<?php require BASE_PATH . '/includes/footer.php'; ?>
