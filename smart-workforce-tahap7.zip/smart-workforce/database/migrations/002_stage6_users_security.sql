-- ============================================================
-- Migrasi Tahap 6 — keamanan akun pengguna
-- Jalankan SEKALI pada database smart_workforce yang sudah ada (phpMyAdmin > Import).
-- Instalasi baru yang memakai schema.sql terbaru TIDAK perlu menjalankan file ini.
--
--  must_change_password : 1 = pengguna wajib mengganti password pada login berikutnya
--                         (diset saat akun dibuat / password direset oleh Admin).
--  password_changed_at  : waktu password terakhir diubah; sesi yang dibuat sebelum waktu ini
--                         otomatis dikeluarkan (mencabut sesi lama setelah reset password).
-- ============================================================
USE `smart_workforce`;

ALTER TABLE `users`
  ADD COLUMN `must_change_password` TINYINT(1) NOT NULL DEFAULT 0 AFTER `status`,
  ADD COLUMN `password_changed_at` DATETIME NULL DEFAULT NULL AFTER `last_login_at`;
