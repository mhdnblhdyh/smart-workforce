-- ============================================================
-- OPSIONAL — perkuat audit_logs agar TIDAK DAPAT diubah/dihapus di level database
-- (selain lewat aplikasi, yang memang tidak menyediakan fitur ubah/hapus log).
-- Trigger memblokir UPDATE dan DELETE pada audit_logs untuk semua akun database.
-- Untuk pemeliharaan/retensi log, hapus trigger terlebih dahulu:
--   DROP TRIGGER audit_logs_no_update; DROP TRIGGER audit_logs_no_delete;
-- ============================================================
USE `smart_workforce`;

DELIMITER //
CREATE TRIGGER audit_logs_no_update BEFORE UPDATE ON audit_logs FOR EACH ROW
BEGIN
  SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'audit_logs bersifat append-only';
END//
CREATE TRIGGER audit_logs_no_delete BEFORE DELETE ON audit_logs FOR EACH ROW
BEGIN
  SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'audit_logs bersifat append-only';
END//
DELIMITER ;
