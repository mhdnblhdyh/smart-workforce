-- ============================================================
-- Smart Workforce Analytics — Database Schema (Tahap 1)
-- Engine : InnoDB | Charset : utf8mb4 | MySQL 5.7+ / MariaDB 10.4+
-- Cara pakai: impor file ini lebih dulu, lalu seed.sql
-- PERINGATAN: file ini menghapus database lama bernama smart_workforce.
-- ============================================================

DROP DATABASE IF EXISTS `smart_workforce`;
CREATE DATABASE `smart_workforce`
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;
USE `smart_workforce`;

SET NAMES utf8mb4;

-- ------------------------------------------------------------
-- 1. users — akun aplikasi
-- ------------------------------------------------------------
CREATE TABLE `users` (
  `id`                    INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `name`                  VARCHAR(100) NOT NULL,
  `email`                 VARCHAR(150) NOT NULL,
  `password_hash`         VARCHAR(255) NOT NULL,
  `role`                  ENUM('admin','hc_staff','viewer') NOT NULL DEFAULT 'viewer',
  `status`                ENUM('active','inactive') NOT NULL DEFAULT 'active',
  `must_change_password`  TINYINT(1) NOT NULL DEFAULT 0,
  `failed_login_attempts` TINYINT UNSIGNED NOT NULL DEFAULT 0,
  `locked_until`          DATETIME NULL DEFAULT NULL,
  `last_login_at`         DATETIME NULL DEFAULT NULL,
  `password_changed_at`   DATETIME NULL DEFAULT NULL,
  `created_at`            TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at`            TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_users_email` (`email`),
  KEY `idx_users_role_status` (`role`,`status`)
) ENGINE=InnoDB;

-- ------------------------------------------------------------
-- 2. departments — master departemen
-- ------------------------------------------------------------
CREATE TABLE `departments` (
  `id`          INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `code`        VARCHAR(20)  NOT NULL,
  `name`        VARCHAR(120) NOT NULL,
  `description` TEXT NULL,
  `status`      ENUM('active','inactive') NOT NULL DEFAULT 'active',
  `created_at`  TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at`  TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_departments_code` (`code`),
  KEY `idx_departments_name` (`name`),
  KEY `idx_departments_status` (`status`)
) ENGINE=InnoDB;

-- ------------------------------------------------------------
-- 3. vendors — perusahaan penyedia TAD
-- ------------------------------------------------------------
CREATE TABLE `vendors` (
  `id`             INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `code`           VARCHAR(20)  NOT NULL,
  `name`           VARCHAR(150) NOT NULL,
  `contact_person` VARCHAR(100) NULL,
  `contact_email`  VARCHAR(150) NULL,
  `contract_start` DATE NULL,
  `contract_end`   DATE NULL,
  `status`         ENUM('active','inactive') NOT NULL DEFAULT 'active',
  `notes`          TEXT NULL,
  `created_at`     TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at`     TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_vendors_code` (`code`),
  KEY `idx_vendors_name` (`name`),
  KEY `idx_vendors_status_end` (`status`,`contract_end`),
  CONSTRAINT `chk_vendors_contract` CHECK (`contract_end` IS NULL OR `contract_start` IS NULL OR `contract_end` >= `contract_start`)
) ENGINE=InnoDB;

-- ------------------------------------------------------------
-- 4. import_batches — riwayat proses import Excel/CSV
--    (dibuat sebelum employees/workforce_records agar bisa direferensikan)
-- ------------------------------------------------------------
CREATE TABLE `import_batches` (
  `id`               INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `import_type`      ENUM('employees','workforce_records') NOT NULL,
  `original_name`    VARCHAR(255) NOT NULL,
  `stored_name`      VARCHAR(100) NULL,
  `file_size`        INT UNSIGNED NOT NULL DEFAULT 0,
  `file_hash`        CHAR(64) NULL,
  `column_mapping`   LONGTEXT NULL,
  `duplicate_policy` ENUM('skip','update') NOT NULL DEFAULT 'skip',
  `total_rows`       INT UNSIGNED NOT NULL DEFAULT 0,
  `valid_rows`       INT UNSIGNED NOT NULL DEFAULT 0,
  `duplicate_rows`   INT UNSIGNED NOT NULL DEFAULT 0,
  `invalid_rows`     INT UNSIGNED NOT NULL DEFAULT 0,
  `imported_rows`    INT UNSIGNED NOT NULL DEFAULT 0,
  `status`           ENUM('uploaded','validated','completed','failed','cancelled') NOT NULL DEFAULT 'uploaded',
  `error_message`    VARCHAR(500) NULL,
  `imported_by`      INT UNSIGNED NULL,
  `created_at`       TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `completed_at`     DATETIME NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_batches_status` (`status`),
  KEY `idx_batches_created` (`created_at`),
  KEY `idx_batches_hash` (`file_hash`),
  CONSTRAINT `fk_batches_user` FOREIGN KEY (`imported_by`) REFERENCES `users` (`id`)
    ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB;

-- ------------------------------------------------------------
-- 5. employees — master tenaga kerja
-- ------------------------------------------------------------
CREATE TABLE `employees` (
  `id`            INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `employee_code` VARCHAR(30)  NOT NULL,
  `full_name`     VARCHAR(150) NOT NULL,
  `category`      ENUM('employee','tad','intern') NOT NULL,
  `department_id` INT UNSIGNED NOT NULL,
  `vendor_id`     INT UNSIGNED NULL,
  `position`      VARCHAR(120) NULL,
  `start_date`    DATE NOT NULL,
  `end_date`      DATE NULL,
  `status`        ENUM('active','inactive','completed') NOT NULL DEFAULT 'active',
  `notes`         TEXT NULL,
  `created_by`    INT UNSIGNED NULL,
  `created_at`    TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at`    TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_employees_code` (`employee_code`),
  KEY `idx_employees_name` (`full_name`),
  KEY `idx_employees_category_status` (`category`,`status`),
  KEY `idx_employees_department` (`department_id`),
  KEY `idx_employees_vendor` (`vendor_id`),
  KEY `idx_employees_dates` (`start_date`,`end_date`),
  CONSTRAINT `fk_employees_department` FOREIGN KEY (`department_id`) REFERENCES `departments` (`id`)
    ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `fk_employees_vendor` FOREIGN KEY (`vendor_id`) REFERENCES `vendors` (`id`)
    ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `fk_employees_created_by` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`)
    ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `chk_employees_dates` CHECK (`end_date` IS NULL OR `end_date` >= `start_date`)
) ENGINE=InnoDB;

-- ------------------------------------------------------------
-- 6. workforce_records — mandays & kehadiran
--    GRANULARITAS: 1 record = 1 tenaga kerja x 1 bulan.
--    period_month selalu tanggal 1 (mis. 2026-09-01).
-- ------------------------------------------------------------
CREATE TABLE `workforce_records` (
  `id`              INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `employee_id`     INT UNSIGNED NOT NULL,
  `period_month`    DATE NOT NULL,
  `mandays`         DECIMAL(5,2) NOT NULL,
  `scheduled_days`  DECIMAL(5,2) NULL,
  `attended_days`   DECIMAL(5,2) NULL,
  `notes`           VARCHAR(255) NULL,
  `source`          ENUM('manual','import') NOT NULL DEFAULT 'manual',
  `import_batch_id` INT UNSIGNED NULL,
  `created_by`      INT UNSIGNED NULL,
  `created_at`      TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at`      TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_records_employee_period` (`employee_id`,`period_month`),
  KEY `idx_records_period` (`period_month`),
  KEY `idx_records_batch` (`import_batch_id`),
  CONSTRAINT `fk_records_employee` FOREIGN KEY (`employee_id`) REFERENCES `employees` (`id`)
    ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `fk_records_batch` FOREIGN KEY (`import_batch_id`) REFERENCES `import_batches` (`id`)
    ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `fk_records_created_by` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`)
    ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `chk_records_first_day` CHECK (DAYOFMONTH(`period_month`) = 1),
  CONSTRAINT `chk_records_mandays` CHECK (`mandays` >= 0 AND `mandays` <= 31),
  CONSTRAINT `chk_records_scheduled` CHECK (`scheduled_days` IS NULL OR (`scheduled_days` >= 0 AND `scheduled_days` <= 31)),
  CONSTRAINT `chk_records_attended` CHECK (`attended_days` IS NULL OR (`attended_days` >= 0 AND `attended_days` <= 31))
) ENGINE=InnoDB;

-- ------------------------------------------------------------
-- 7. import_errors — detail kesalahan per baris import
-- ------------------------------------------------------------
CREATE TABLE `import_errors` (
  `id`          BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `batch_id`    INT UNSIGNED NOT NULL,
  `row_number`  INT UNSIGNED NOT NULL,
  `column_name` VARCHAR(100) NULL,
  `error_type`  ENUM('missing_required','invalid_date','invalid_number','department_not_found',
                     'vendor_not_found','invalid_enum','duplicate','other') NOT NULL,
  `severity`    ENUM('error','warning') NOT NULL DEFAULT 'error',
  `message`     VARCHAR(500) NOT NULL,
  `suggestion`  VARCHAR(500) NULL,
  `raw_data`    LONGTEXT NULL,
  `created_at`  TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_errors_batch` (`batch_id`,`row_number`),
  KEY `idx_errors_type` (`error_type`),
  CONSTRAINT `fk_errors_batch` FOREIGN KEY (`batch_id`) REFERENCES `import_batches` (`id`)
    ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB;

-- ------------------------------------------------------------
-- 8. audit_logs — jejak aktivitas (hanya INSERT dari aplikasi)
-- ------------------------------------------------------------
CREATE TABLE `audit_logs` (
  `id`          BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id`     INT UNSIGNED NULL,
  `action`      VARCHAR(50)  NOT NULL,
  `entity_type` VARCHAR(50)  NULL,
  `entity_id`   INT UNSIGNED NULL,
  `description` VARCHAR(500) NULL,
  `ip_address`  VARCHAR(45)  NULL,
  `user_agent`  VARCHAR(255) NULL,
  `created_at`  TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_audit_created` (`created_at`),
  KEY `idx_audit_user` (`user_id`),
  KEY `idx_audit_action` (`action`),
  KEY `idx_audit_entity` (`entity_type`,`entity_id`),
  CONSTRAINT `fk_audit_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
    ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB;

-- ------------------------------------------------------------
-- 9. settings — pengaturan aplikasi (key-value)
-- ------------------------------------------------------------
CREATE TABLE `settings` (
  `setting_key`   VARCHAR(80)  NOT NULL,
  `setting_value` VARCHAR(500) NULL,
  `updated_by`    INT UNSIGNED NULL,
  `updated_at`    TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`setting_key`),
  CONSTRAINT `fk_settings_user` FOREIGN KEY (`updated_by`) REFERENCES `users` (`id`)
    ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB;
