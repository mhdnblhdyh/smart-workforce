# Smart Workforce Analytics

Sistem informasi berbasis web untuk mengelola, memantau, menganalisis, dan melaporkan data tenaga kerja (karyawan, TAD, peserta magang), vendor, dan mandays secara terpusat.

> **Status: Tahap 7 dari 7 (final)** — seluruh modul tersedia: Dashboard, CRUD, Mandays, Analytics, Import, Data Quality, Report Center (Excel/PDF), User Management, Activity Logs, dan Pengaturan.
> Seluruh data pada repositori ini adalah **data sintetis/fiktif**.

## Fitur yang sudah tersedia
- **Tahap 1**: login/logout, session aman, RBAC (Admin, HC Staff, Viewer), CSRF, audit log, skema database + data demo.
- **Tahap 2**: layout (sidebar dapat diciutkan / drawer di layar kecil, topbar, breadcrumb, notifikasi kontrak vendor, toast), komponen UI reusable, dan **Dashboard** (7 KPI, 4 grafik Chart.js, ringkasan data quality, tabel per vendor) dengan filter periode dan departemen. Seluruh angka dihitung lewat query agregasi MySQL (`modules/dashboard/queries.php`) dan dimuat lewat `modules/dashboard/data.php`.
- **Tahap 3**: CRUD **Data Tenaga Kerja**, **Departemen**, dan **Vendor** dengan pencarian, filter, sorting (whitelist kolom), pagination server-side, validasi server, dialog tambah/edit/detail/hapus, pesan toast, audit log, dan ekspor CSV sesuai filter (tenaga kerja & vendor). Vendor memiliki rekap TAD per vendor dan peringatan kontrak.
- **Tahap 4**: **Mandays & Kehadiran** (CRUD record bulanan, filter, rekap per bulan/departemen/vendor, grafik tren, ekspor CSV) dan **Analytics** (filter rentang bulan, departemen, vendor, kategori, status; perbandingan dengan periode sebelumnya yang sejenis; 6 grafik; tabel perbandingan mandays antarperiode; ringkasan perubahan deskriptif).
- **Tahap 5**: **Smart Excel Import** (unggah aman .xlsx/.csv, pratinjau, pemetaan kolom otomatis + manual, validasi, deteksi duplikat, ringkasan, laporan kesalahan CSV, konfirmasi, transaksi + rollback), **Data Quality** (14 pemeriksaan data tersimpan, skor kelengkapan, daftar record bermasalah, ekspor CSV, ringkasan per batch import), dan **Riwayat Import**.
- **Tahap 6**: **Report Center** (6 laporan: tenaga kerja per periode, TAD per vendor, per departemen, mandays, data quality, riwayat import; preview + ekspor **Excel** dan **PDF** dari dataset yang sama), **User Management** (buat akun dengan password sementara sekali-tampil, ubah nama/role, aktif/nonaktif, reset password, buka kunci), dan **Activity Logs** (filter, ekspor CSV, hanya-baca).
- **Tahap 7**: **Pengaturan** (Admin): masa peringatan kontrak vendor, ukuran maksimum file import, dan jumlah baris maksimum import, dengan validasi rentang di server, tanpa perubahan parsial, dan audit log nilai lama → baru; plus panel **Informasi sistem** hanya-baca (versi PHP/DB, batas unggah, folder storage, status pustaka Composer).

## Teknologi
PHP Native (tanpa framework) · MySQL/MariaDB (MySQLi + prepared statements) · HTML5/CSS3/JavaScript vanilla · Chart.js 4.4.7 dan ikon Lucide (disertakan lokal di `assets/`, tanpa CDN) · PhpSpreadsheet · Dompdf · XAMPP · Git/GitHub

## Persyaratan
- XAMPP dengan PHP ≥ 8.0 (ekstensi `mysqli`, `mbstring`) dan MariaDB/MySQL
- Composer (dibutuhkan mulai Tahap 5/6 untuk PhpSpreadsheet & Dompdf; **belum wajib di Tahap 1**)
- Browser modern

## Memasang dependency Composer (wajib untuk Import Excel)
PhpSpreadsheet 5.x membutuhkan **PHP 8.2+** (gunakan XAMPP 8.2 atau lebih baru; cek dengan `C:\xampp\php\php.exe -v`).
1. Pasang Composer untuk Windows dari https://getcomposer.org/download/ dan arahkan ke `C:\xampp\php\php.exe`.
2. Buka `C:\xampp\php\php.ini`, pastikan baris berikut **tidak diawali titik koma**: `extension=zip`, `extension=gd`, `extension=fileinfo`, `extension=mbstring`. Untuk impor file besar atur juga `upload_max_filesize=20M`, `post_max_size=25M`, `memory_limit=512M`. Restart Apache.
3. Di terminal: `cd C:\xampp\htdocs\smart-workforce` lalu `composer install`.
4. Tanpa langkah ini aplikasi tetap berjalan, tetapi halaman Import Excel menampilkan peringatan dan unggahan dinonaktifkan.

## Memperbarui dari Tahap 5/6 (database sudah ada)
Impor **sekali** `database/migrations/002_stage6_users_security.sql` lewat phpMyAdmin (menambah kolom `must_change_password` dan `password_changed_at` pada tabel `users`). Instalasi baru yang memakai `schema.sql` terbaru tidak perlu langkah ini. Sebelum migrasi, aplikasi tetap berjalan; hanya pembuatan akun dan reset password yang dinonaktifkan dengan pesan penjelasan.
**Tahap 7 tidak memerlukan migrasi baru.** Kunci `import_max_rows` yang belum ada di tabel `settings` dibuat otomatis saat pertama kali disimpan; sebelum itu dipakai nilai bawaan 5.000.
Opsional: impor `database/optional_audit_immutable.sql` agar tabel `audit_logs` tidak dapat diubah/dihapus bahkan lewat database (append-only).

## Instalasi di XAMPP
1. Salin folder `smart-workforce` ke `C:\xampp\htdocs\smart-workforce`.
2. Jalankan **Apache** dan **MySQL** di XAMPP Control Panel.
3. Buka `http://localhost/phpmyadmin` → tab **Import** → pilih `database/schema.sql` → **Import**.
   (Membuat database `smart_workforce`. Jika database lama bernama sama ada, akan **dihapus**.)
4. Tab **Import** lagi → pilih `database/seed.sql` → **Import**.
5. (Opsional) Salin `config/config.example.php` menjadi `config/config.local.php` dan sesuaikan.
   Tanpa file ini, aplikasi memakai default XAMPP (`root`, tanpa password, `base_url` = `/smart-workforce`).
6. Buka `http://localhost/smart-workforce/`.

Dependency Composer (PhpSpreadsheet & Dompdf, wajib untuk Import dan Report Center): buka terminal di folder proyek lalu `composer install`.

## Akun demo (khusus lingkungan demo)
| Role | Email | Password |
|------|-------|----------|
| Admin | admin@example.com | Admin@Demo2026 |
| HC Staff | hcstaff@example.com | Staff@Demo2026 |
| Viewer | viewer@example.com | Viewer@Demo2026 |

Jangan dipakai di produksi. Untuk membuat hash password baru: `php tools/hash_password.php "PasswordBaru#123"`.

## Panduan Import Excel (Tahap 5)
1. **Import Excel → pilih jenis data** (Tenaga Kerja atau Mandays), unduh **templat .xlsx** bila perlu, lalu unggah file (.xlsx / .csv, maks. 10 MB dan 5.000 baris data; hanya sheet pertama dibaca).
2. **Pemetaan kolom**: periksa pratinjau, atur *baris judul kolom* bila judul tidak di baris 1, pilih kolom untuk setiap field (terdeteksi otomatis dari judul), lalu pilih kebijakan duplikat: **Lewati** (bawaan, aman) atau **Perbarui** (menimpa data lama; wajib dicentang eksplisit).
3. **Validasi & tinjau**: lihat ringkasan (total / valid / duplikat / tidak valid), filter kesalahan per jenis, dan unduh laporan kesalahan CSV. Pada tahap ini belum ada data yang disimpan.
4. **Konfirmasi**: centang konfirmasi lalu simpan. File dibaca dan divalidasi ulang, disimpan dalam **satu transaksi** (insert massal 250 baris/query); kegagalan apa pun membatalkan seluruh perubahan (rollback). File sementara dihapus setelah selesai; batch yang tidak dikonfirmasi dibatalkan otomatis setelah 24 jam.
- **Kunci duplikat**: Tenaga Kerja = ID Internal; Mandays = ID Internal + Periode. Baris yang berulang di dalam file selalu dilewati (yang pertama dipakai).
- **Aturan data** sama dengan formulir manual (vendor hanya untuk TAD, magang wajib tanggal berakhir, mandays ≤ jumlah hari bulan itu, kehadiran berpasangan, tenaga kerja harus aktif pada bulan tersebut, dst.). Nilai kategori/status boleh berbahasa Indonesia atau Inggris; tanggal `YYYY-MM-DD`, `DD/MM/YYYY`, atau sel tanggal Excel; angka desimal boleh memakai koma.
- **Keamanan unggahan**: ekstensi + MIME + struktur isi diperiksa (tolak makro, ZIP tidak wajar, data biner pada CSV); nama file acak di `storage/imports` (diblokir dari browser); isi file tidak pernah dieksekusi; **rumus tidak dihitung** (hanya nilai tersimpan yang dibaca, rumus tanpa nilai ditolak).

## Report Center, User Management, Activity Logs (Tahap 6)
- **Report Center**: pilih laporan, atur filter, tinjau ringkasan + preview, lalu unduh **Excel (.xlsx)** atau **PDF**. Preview, Excel, dan PDF dibangun dari satu fungsi dataset sehingga memakai filter dan angka yang sama; total/subtotal dihitung di MySQL dari seluruh data (bukan dari baris yang tampil) dan memakai definisi yang sama dengan Dashboard/Analytics. Preview memuat 100 baris; Excel hingga 20.000 baris; PDF hingga 1.500 baris (bila dibatasi, ada catatan dan total tetap utuh). Nama file informatif: `laporan-<jenis>_<periode>_<tanggal-jam>.xlsx|pdf`. Setiap ekspor dicatat di Activity Logs beserta filternya. Ekspor hanya untuk HC Staff dan Admin; Viewer hanya preview.
- **Keamanan ekspor**: sel Excel selalu ditulis sebagai teks/angka eksplisit (tidak pernah rumus; awalan `= + - @` diberi quote prefix) dan seluruh teks di HTML PDF di-escape.
- **User Management (hanya Admin)**: password sementara dibuat acak oleh sistem (14 karakter), ditampilkan **sekali**, tidak pernah disimpan di log/database selain sebagai hash bcrypt, dan pengguna **wajib mengganti** saat login pertama. Reset password mencabut sesi lama pengguna tersebut. Menonaktifkan akun memutus sesinya seketika. Admin tidak dapat mengubah role, menonaktifkan, atau mereset akunnya sendiri; Admin aktif terakhir tidak dapat diturunkan/dinonaktifkan. Kebijakan password: minimal 10 karakter, huruf + angka, tidak memuat nama email.
- **Ganti password sendiri**: menu profil → "Ganti password" (butuh password saat ini; percobaan salah dihitung seperti kegagalan login).
- **Activity Logs (hanya Admin)**: filter pengguna/aksi/entitas/tanggal/kata kunci, ekspor CSV (ekspor itu sendiri tercatat). Tidak ada fitur ubah/hapus log di aplikasi.

## Pengaturan (Tahap 7)
- Menu **Administration → Pengaturan** (hanya Admin; HC Staff/Viewer mendapat 403). Tiga parameter, masing-masing dengan rentang yang divalidasi di server:

| Parameter | Rentang | Bawaan | Dipakai oleh |
|-----------|---------|--------|--------------|
| Masa peringatan kontrak vendor | 1–365 hari | 60 | Vendor, Dashboard, notifikasi |
| Ukuran maksimum file import | 1–50 MB | 10 | Import Excel |
| Jumlah baris maksimum per import | 100–20.000 | 5.000 | Import Excel |

- Semua isian harus valid; bila ada satu yang salah, **tidak ada yang disimpan** dan isian dikembalikan beserta pesan per kolom. Hanya nilai yang berubah yang ditulis, dalam satu transaksi, dan dicatat di Activity Logs (`settings_update`: nilai lama → baru).
- Ukuran file import tetap dibatasi `upload_max_filesize`/`post_max_size` di php.ini; halaman menampilkan peringatan bila nilai yang diatur melebihi batas PHP.
- Hanya pengaturan yang benar-benar dibaca aplikasi yang ditampilkan (tidak ada opsi palsu). Baris `mandays_granularity` di seed tidak dipakai kode dan tidak ditampilkan.

## Aturan bisnis CRUD (Tahap 3)
- **Tenaga kerja**: vendor wajib untuk TAD dan dilarang untuk kategori lain; peserta magang wajib punya tanggal berakhir; status selain Aktif wajib punya tanggal berakhir; status Aktif tidak boleh berakhir di masa lalu; jabatan wajib; ID internal dibuat otomatis (EMP/TAD/INT-0001) bila dikosongkan.
- **Penghapusan**: tenaga kerja yang punya record mandays, departemen/vendor yang masih punya tenaga kerja, **tidak dapat dihapus** (gunakan status Tidak aktif/Selesai atau Nonaktif). Departemen/vendor juga tidak dapat dinonaktifkan selama masih punya tenaga kerja aktif. Aturan dicek di server dan diperkuat foreign key `RESTRICT`.
- **Hak akses**: Viewer hanya melihat; HC Staff dan Admin mengelola dan mengekspor. Setiap endpoint memeriksa izin dan token CSRF.
- **Ekspor CSV**: pemisah titik koma, UTF-8 BOM (terbuka benar di Excel Indonesia), sel berawalan `= + - @` dinetralkan dari CSV injection. Ekspor Excel/PDF tersedia di Report Center (Tahap 6).

## Aturan mandays & analytics (Tahap 4)
- **Granularitas bulanan**: 1 record = 1 tenaga kerja × 1 bulan; kunci unik `(employee_id, period_month)`. Seluruh analisis berbasis bulan agar sejenis dengan data mandays.
- **Validasi record**: periode tidak boleh di masa depan; tenaga kerja harus aktif pada bulan tersebut (menurut tanggal mulai/berakhir); mandays 0 s.d. jumlah hari kalender bulan itu (maks. 2 desimal, koma/titik diterima); hari terjadwal & hari hadir diisi **berpasangan** atau dikosongkan keduanya (tidak pernah diestimasi); hari hadir ≤ hari terjadwal. Saat edit, tenaga kerja dan periode dikunci (diabaikan juga di server).
- **Periode sebelumnya yang sejenis**: rentang bulan dengan panjang sama yang berakhir tepat sebelum periode awal. Indikator titik waktu (jumlah tenaga kerja, kelengkapan data) dibandingkan pada bulan terakhir tiap rentang; indikator akumulasi (mandays, jumlah record) dijumlahkan sepanjang rentang.
- **Persentase perubahan**: tidak dihitung jika pembanding bernilai 0 (ditampilkan "pembanding 0"); perubahan kelengkapan data dinyatakan dalam poin persentase. Ringkasan bersifat deskriptif dan tidak menyiratkan sebab-akibat.
- **Filter status** memakai status tenaga kerja saat ini; jumlah per bulan dihitung dari tanggal mulai/berakhir. Rentang maksimum 24 bulan.

## Definisi perhitungan dashboard
- **Aktif pada bulan M**: `start_date` ≤ akhir bulan M dan (`end_date` kosong atau ≥ awal bulan M). Berbasis tanggal agar periode historis akurat.
- **Mandays**: `SUM(workforce_records.mandays)` pada bulan tersebut. Bukan jumlah karyawan.
- **Kelengkapan data**: tenaga kerja aktif dengan jabatan terisi, TAD punya vendor, peserta magang punya tanggal berakhir, dan punya record mandays pada bulan itu, dibagi seluruh tenaga kerja aktif.
- **Periode bawaan**: bulan terbaru yang memiliki record mandays.
- Perbandingan terhadap bulan sebelumnya hanya menampilkan selisih, tidak menyimpulkan sebab-akibat; persentase tidak dihitung jika bulan sebelumnya bernilai 0.

## Skema database
```mermaid
erDiagram
    users ||--o{ audit_logs : "mencatat"
    users ||--o{ import_batches : "mengimpor"
    departments ||--o{ employees : "memiliki"
    vendors ||--o{ employees : "menyediakan TAD"
    employees ||--o{ workforce_records : "mandays bulanan"
    import_batches ||--o{ workforce_records : "sumber"
    import_batches ||--o{ import_errors : "menghasilkan"
    users ||--o{ settings : "mengubah"
```

**Kebijakan relasi & penghapusan**
- `employees → departments/vendors`: `ON DELETE RESTRICT` (departemen/vendor yang masih dipakai tidak bisa dihapus; nonaktifkan saja).
- `workforce_records → employees`: `RESTRICT` (tenaga kerja yang punya record mandays tidak bisa dihapus; ubah status menjadi *Tidak aktif/Selesai*).
- `import_errors → import_batches`: `CASCADE`. Kolom `created_by`/`imported_by`/`user_id`: `SET NULL` agar riwayat tetap ada.

**Aturan mandays**
- 1 record = 1 tenaga kerja × 1 bulan (`period_month` selalu tanggal 1). Kunci unik: `(employee_id, period_month)`.
- Mandays = jumlah hari kerja yang diakui pada bulan tersebut (0–31); **bukan** jumlah karyawan.
- `scheduled_days` dan `attended_days` boleh kosong (NULL) bila datanya tidak tersedia — tidak diisi dengan angka karangan.

## Keamanan (Tahap 1)
Password `password_hash()`/`password_verify()` · prepared statements · regenerasi session ID saat login · cookie `HttpOnly` + `SameSite=Lax` (+`Secure` di HTTPS) · token CSRF · logout hanya via POST+CSRF · pesan login generik · penguncian akun 15 menit setelah 5 kegagalan · timeout idle 30 menit · pemeriksaan role/izin di server pada setiap request · pencegahan open redirect · `.htaccess` memblokir `config/`, `includes/`, `database/`, `storage/`, `tools/` · detail error hanya tampil saat `app_env = development`.

## Known limitations
- Font Inter dimuat dari Google Fonts; tanpa internet tampilan memakai font sistem.
- Formulir tambah/edit memakai dialog yang membutuhkan JavaScript aktif.
- Ekspor di modul daftar (tenaga kerja, vendor, mandays, Data Quality, Activity Logs) berformat CSV; Excel dan PDF tersedia di Report Center.
- Import membaca file `.xlsx` dan `.csv` saja (file `.xls` lama harus disimpan ulang sebagai `.xlsx`), hanya sheet pertama, jumlah baris dan ukuran file diatur di menu Pengaturan.
- Daftar kesalahan impor disimpan maksimal 10.000 entri per batch. Impor berjalan sinkron (tanpa antrean), sehingga file sangat besar dapat mendekati batas waktu PHP.
- Pelanggaran ENUM/FK/CHECK tidak dapat ada pada data tersimpan (dicegah database); pemeriksaan Data Quality fokus pada kelengkapan, konsistensi, duplikat, dan mandays.
- Penguncian akun berbasis akun, belum berbasis IP; belum ada CAPTCHA/2FA.
- Tabel `audit_logs` hanya di-INSERT oleh aplikasi; pembatasan di level database (trigger/hak akses) belum diterapkan.
- Belum ada "lupa password" mandiri lewat email; reset dilakukan oleh Admin dan password sementara diserahkan secara manual (sengaja tanpa email agar tidak ada kredensial yang dikirim lewat jalur tak aman).
- Sesi memakai file session PHP bawaan; pencabutan sesi bergantung pada pemeriksaan status akun dan `password_changed_at` pada setiap request.
- Pengaturan lewat UI mencakup tiga parameter di atas; konfigurasi lain (kredensial DB, timeout sesi, batas login gagal) tetap di `config/config.local.php` dan hanya dapat dilihat, bukan diubah, dari halaman Pengaturan.
