<?php
declare(strict_types=1);
require_once dirname(__DIR__, 2) . '/includes/bootstrap.php';
require_once __DIR__ . '/repo.php';

$user = require_permission('users.manage');
if (!is_post()) {
    redirect('modules/users/index.php');
}
csrf_require();

$back = 'modules/users/index.php';
$rqs  = $_POST['return_qs'] ?? '';
$id   = (isset($_POST['id']) && ctype_digit((string) $_POST['id'])) ? (int) $_POST['id'] : 0;
$existing = $id > 0 ? user_find($id) : null;
if ($id > 0 && $existing === null) {
    flash_set('danger', 'Pengguna tidak ditemukan.');
    redirect_to_list($back, $rqs);
}
if ($existing === null && !users_has_security_columns()) {
    flash_set('danger', 'Jalankan migrasi database/migrations/002_stage6_users_security.sql sebelum membuat akun baru.');
    redirect_to_list($back, $rqs);
}

[$d, $errors] = user_validate($_POST, $existing, (int) $user['id']);
$fail = function (array $errors) use ($existing, $id, $rqs, $back): void {
    form_state_set('users', ['mode' => $existing ? 'edit' : 'create', 'id' => $id, 'old' => post_old_input(USER_FORM_FIELDS), 'errors' => $errors]);
    flash_set('warning', 'Periksa kembali isian formulir.');
    redirect_to_list($back, $rqs);
};
if ($errors) {
    $fail($errors);
}

try {
    if ($existing) {
        db_run('UPDATE users SET name = ?, role = ? WHERE id = ?', 'ssi', [$d['name'], $d['role'], $id]);
        if ($d['role'] !== $existing['role']) {
            audit_log('role_change', 'user', $id, "Mengubah role {$existing['email']}: {$existing['role']} → {$d['role']}", (int) $user['id']);
        }
        if ($d['name'] !== $existing['name']) {
            audit_log('user_update', 'user', $id, 'Mengubah nama pengguna ' . $existing['email'], (int) $user['id']);
        }
        flash_set('success', 'Data pengguna ' . $d['name'] . ' berhasil diperbarui.');
    } else {
        $temp = generate_temp_password();
        db_run(
            'INSERT INTO users (name, email, password_hash, role, status, must_change_password, password_changed_at) VALUES (?, ?, ?, ?, \'active\', 1, NOW())',
            'ssss',
            [$d['name'], $d['email'], password_hash($temp, PASSWORD_DEFAULT), $d['role']]
        );
        $newId = db_last_id();
        audit_log('user_create', 'user', $newId, "Membuat akun {$d['email']} (role {$d['role']})", (int) $user['id']);
        user_stash_secret('create', $d, $temp);
        flash_set('success', 'Akun ' . $d['name'] . ' berhasil dibuat.');
    }
} catch (Throwable $ex) {
    if (is_duplicate_error($ex)) {
        $fail(['email' => 'Email sudah terdaftar.']);
    }
    throw $ex;
}
redirect_to_list($back, $rqs);
