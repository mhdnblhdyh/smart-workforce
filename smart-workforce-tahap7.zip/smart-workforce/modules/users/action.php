<?php
/** Aksi akun: activate | deactivate | reset (password) | unlock. Hanya Admin; POST + CSRF. */
declare(strict_types=1);
require_once dirname(__DIR__, 2) . '/includes/bootstrap.php';
require_once __DIR__ . '/repo.php';

$user = require_permission('users.manage');
if (!is_post()) {
    redirect('modules/users/index.php');
}
csrf_require();

$back = 'modules/users/index.php';
$rqs  = $_POST['return_qs'] ?? '';
$id   = (isset($_POST['id']) && ctype_digit((string) $_POST['id'])) ? (int) $_POST['id'] : 0;
$do   = post_str('do', 20);
$target = $id > 0 ? user_find($id) : null;
$actor  = (int) $user['id'];

$deny = function (string $msg) use ($back, $rqs, $target, $do, $actor): void {
    audit_log('user_action_denied', 'user', $target ? (int) $target['id'] : null, "Aksi {$do} ditolak: {$msg}", $actor);
    flash_set('danger', $msg);
    redirect_to_list($back, $rqs);
};

if ($target === null || !in_array($do, ['activate', 'deactivate', 'reset', 'unlock'], true)) {
    flash_set('danger', 'Pengguna atau aksi tidak valid.');
    redirect_to_list($back, $rqs);
}
$isSelf = (int) $target['id'] === $actor;

switch ($do) {
    case 'deactivate':
        if ($isSelf) { $deny('Anda tidak dapat menonaktifkan akun Anda sendiri.'); }
        if ($target['role'] === 'admin' && $target['status'] === 'active' && users_active_admin_count() <= 1) { $deny('Tidak dapat menonaktifkan Admin aktif terakhir.'); }
        db_run("UPDATE users SET status = 'inactive' WHERE id = ?", 'i', [$id]);
        audit_log('user_deactivate', 'user', $id, 'Menonaktifkan akun ' . $target['email'], $actor);
        flash_set('success', 'Akun ' . $target['name'] . ' dinonaktifkan dan seluruh sesinya diputus.');
        break;

    case 'activate':
        db_run("UPDATE users SET status = 'active', failed_login_attempts = 0, locked_until = NULL WHERE id = ?", 'i', [$id]);
        audit_log('user_activate', 'user', $id, 'Mengaktifkan akun ' . $target['email'], $actor);
        flash_set('success', 'Akun ' . $target['name'] . ' diaktifkan.');
        break;

    case 'unlock':
        db_run('UPDATE users SET failed_login_attempts = 0, locked_until = NULL WHERE id = ?', 'i', [$id]);
        audit_log('user_unlock', 'user', $id, 'Membuka kunci akun ' . $target['email'], $actor);
        flash_set('success', 'Kunci akun ' . $target['name'] . ' dibuka.');
        break;

    case 'reset':
        if ($isSelf) { $deny('Gunakan halaman "Ganti password" untuk mengubah password Anda sendiri.'); }
        if (!users_has_security_columns()) { $deny('Jalankan migrasi database/migrations/002_stage6_users_security.sql terlebih dahulu.'); }
        $temp = generate_temp_password();
        db_run(
            'UPDATE users SET password_hash = ?, must_change_password = 1, password_changed_at = NOW(), failed_login_attempts = 0, locked_until = NULL WHERE id = ?',
            'si',
            [password_hash($temp, PASSWORD_DEFAULT), $id]
        );
        audit_log('password_reset', 'user', $id, 'Mereset password akun ' . $target['email'] . ' (wajib diganti saat login)', $actor);
        user_stash_secret('reset', $target, $temp);
        flash_set('success', 'Password ' . $target['name'] . ' direset. Sesi lamanya dicabut.');
        break;
}
redirect_to_list($back, $rqs);
