<?php
/**
 * Data & aturan bisnis User Management (hanya Admin: izin users.manage).
 *
 * ATURAN KEAMANAN
 *  - Password disimpan hanya sebagai hash. Password sementara dibuat acak oleh sistem, ditampilkan SEKALI, tidak pernah
 *    disimpan di log/database, dan pengguna WAJIB menggantinya saat login pertama.
 *  - Pengguna tidak dapat mengubah role, menonaktifkan, atau mereset password akunnya sendiri lewat modul ini
 *    (mencegah eskalasi/penguncian diri). Ganti password sendiri lewat halaman "Ganti password".
 *  - Admin aktif terakhir tidak dapat diturunkan role-nya atau dinonaktifkan.
 *  - Role dibaca ulang dari database pada setiap request; menonaktifkan akun langsung memutus sesinya.
 */
declare(strict_types=1);

const USER_ROLES = ['admin' => 'Admin', 'hc_staff' => 'HC Staff', 'viewer' => 'Viewer'];
const USER_STATUS = ['active' => 'Aktif', 'inactive' => 'Nonaktif'];
const USER_SORT = ['name' => 'u.name', 'email' => 'u.email', 'role' => 'u.role', 'status' => 'u.status', 'last_login' => 'u.last_login_at', 'created' => 'u.created_at'];
const USER_FORM_FIELDS = ['name', 'email', 'role'];

function user_filters(): array
{
    $g = fn (string $k): string => (isset($_GET[$k]) && is_string($_GET[$k])) ? trim($_GET[$k]) : '';
    return [
        'q'      => mb_substr($g('q'), 0, 100),
        'role'   => array_key_exists($g('role'), USER_ROLES) ? $g('role') : '',
        'status' => array_key_exists($g('status'), USER_STATUS) ? $g('status') : '',
    ];
}

function user_where(array $f): array
{
    $w = []; $t = ''; $p = [];
    if ($f['q'] !== '') { $like = '%' . like_escape($f['q']) . '%'; $w[] = '(u.name LIKE ? OR u.email LIKE ?)'; $t .= 'ss'; array_push($p, $like, $like); }
    if ($f['role'] !== '')   { $w[] = 'u.role = ?';   $t .= 's'; $p[] = $f['role']; }
    if ($f['status'] !== '') { $w[] = 'u.status = ?'; $t .= 's'; $p[] = $f['status']; }
    return [$w ? 'WHERE ' . implode(' AND ', $w) : '', $t, $p];
}

function user_count(array $f): int
{
    [$where, $t, $p] = user_where($f);
    return (int) db_value("SELECT COUNT(*) FROM users u {$where}", $t, $p);
}

/** Daftar pengguna TANPA password_hash. */
function user_list(array $f, array $req, int $page): array
{
    [$where, $t, $p] = user_where($f);
    $must = users_has_security_columns() ? 'u.must_change_password, u.password_changed_at' : '0 AS must_change_password, NULL AS password_changed_at';
    return db_fetch_all(
        "SELECT u.id, u.name, u.email, u.role, u.status, u.last_login_at, u.created_at, {$must},
                (u.locked_until IS NOT NULL AND u.locked_until > NOW()) AS is_locked
         FROM users u {$where} ORDER BY {$req['order_sql']}, u.id ASC LIMIT ? OFFSET ?",
        $t . 'ii',
        array_merge($p, [$req['per'], ($page - 1) * $req['per']])
    );
}

function user_find(int $id): ?array
{
    $row = db_fetch_one('SELECT * FROM users WHERE id = ?', 'i', [$id]);
    if ($row !== null) {
        unset($row['password_hash']);
    }
    return $row;
}

function users_active_admin_count(): int
{
    return (int) db_value("SELECT COUNT(*) FROM users WHERE role = 'admin' AND status = 'active'");
}

/** Simpan kredensial sementara di sesi untuk ditampilkan SEKALI pada halaman berikutnya. */
function user_stash_secret(string $kind, array $user, string $password): void
{
    $_SESSION['one_time_secret'] = ['kind' => $kind, 'name' => $user['name'], 'email' => $user['email'], 'password' => $password];
}

function user_pull_secret(): ?array
{
    $s = $_SESSION['one_time_secret'] ?? null;
    unset($_SESSION['one_time_secret']);
    return $s;
}

function user_record(array $u, int $actorId): array
{
    return [
        'raw'   => ['id' => (string) $u['id'], 'name' => $u['name'], 'email' => $u['email'], 'role' => $u['role'], 'is_self' => $u['id'] == $actorId ? '1' : '0'],
        'title' => $u['name'], 'name' => $u['name'] . ' (' . $u['email'] . ')',
        'details' => [
            ['Nama', $u['name']], ['Email', $u['email']], ['Role', USER_ROLES[$u['role']] ?? $u['role']],
            ['Status akun', USER_STATUS[$u['status']] ?? $u['status']],
            ['Terkunci sementara', $u['is_locked'] ? 'Ya (terlalu banyak percobaan login)' : 'Tidak'],
            ['Wajib ganti password', $u['must_change_password'] ? 'Ya (belum mengganti password sementara)' : 'Tidak'],
            ['Password terakhir diubah', format_datetime($u['password_changed_at'])],
            ['Login terakhir', format_datetime($u['last_login_at'])], ['Dibuat', format_datetime($u['created_at'])],
        ],
    ];
}

/** @return array{0:array,1:array} [data bersih, errors] */
function user_validate(array $in, ?array $existing, int $actorId): array
{
    $s = fn (string $k, int $max = 255): string => (isset($in[$k]) && is_string($in[$k])) ? mb_substr(trim($in[$k]), 0, $max) : '';
    $e = [];
    $c = ['name' => preg_replace('/\s+/', ' ', $s('name', 100)), 'email' => mb_strtolower($s('email', 150)), 'role' => $s('role', 20)];

    if ($existing !== null && $c['role'] === '') {
        $c['role'] = $existing['role'];              // select role dinonaktifkan di form (akun sendiri): pertahankan role lama
    }
    if (!val_len($c['name'], 2, 100)) {
        $e['name'] = 'Nama wajib diisi (2–100 karakter).';
    }
    if (!array_key_exists($c['role'], USER_ROLES)) {
        $e['role'] = 'Pilih role yang valid.';
    }

    if ($existing === null) {
        if (!filter_var($c['email'], FILTER_VALIDATE_EMAIL) || mb_strlen($c['email']) > 150) {
            $e['email'] = 'Format email tidak valid.';
        } elseif (!is_unique_value('users', 'email', $c['email'])) {
            $e['email'] = 'Email sudah terdaftar.';
        }
    } else {
        $c['email'] = $existing['email'];            // email tidak dapat diubah
        $isSelf = (int) $existing['id'] === $actorId;
        if (!isset($e['role']) && $c['role'] !== $existing['role']) {
            if ($isSelf) {
                $e['role'] = 'Anda tidak dapat mengubah role akun Anda sendiri.';
            } elseif ($existing['role'] === 'admin' && $existing['status'] === 'active' && users_active_admin_count() <= 1) {
                $e['role'] = 'Tidak dapat menurunkan Admin aktif terakhir.';
            }
        }
    }
    return [$c, $e];
}
