<?php
declare(strict_types=1);
require_once dirname(__DIR__, 2) . '/includes/bootstrap.php';
require_once __DIR__ . '/repo.php';

$user = require_permission('users.manage');
$path = 'modules/users/index.php';
$secret = user_pull_secret();
if ($secret) {
    header('Cache-Control: no-store, private');   // halaman memuat kredensial sementara
}

$f      = user_filters();
$req    = list_request(USER_SORT, 'name', 'asc');
$total  = user_count($f);
$pageNo = list_clamp_page($total, $req['page'], $req['per']);
$rows   = user_list($f, $req, $pageNo);
$hasFilter = $f['q'] !== '' || $f['role'] !== '' || $f['status'] !== '';
$migrated  = users_has_security_columns();
$formState = form_state_pull('users');
$returnQs  = safe_return_qs($_SERVER['QUERY_STRING'] ?? '');
$sum = db_fetch_one("SELECT COUNT(*) n, COALESCE(SUM(status='active'),0) act, COALESCE(SUM(role='admin' AND status='active'),0) adm, COALESCE(SUM(locked_until IS NOT NULL AND locked_until > NOW()),0) locked FROM users");

$page = ['title' => 'User Management', 'active' => 'users', 'breadcrumb' => ['Administration', 'User Management'], 'css' => ['crud.css', 'import.css'], 'js' => ['crud.js', 'users.js']];
require BASE_PATH . '/includes/header.php';
$opt = fn ($v, $cur, $label) => '<option value="' . e($v) . '"' . ((string) $v === (string) $cur ? ' selected' : '') . '>' . e($label) . '</option>';
$roleVariant = ['admin' => 'danger', 'hc_staff' => 'info', 'viewer' => 'neutral'];
$act = function (int $id, string $do, string $label, string $icon, string $confirm = '', string $cls = '') use ($returnQs): string {
    return '<form method="post" action="' . e(url('modules/users/action.php')) . '" class="row-form"' . ($confirm !== '' ? ' data-confirm="' . e($confirm) . '"' : '') . '>' . csrf_field()
        . '<input type="hidden" name="id" value="' . $id . '"><input type="hidden" name="do" value="' . e($do) . '"><input type="hidden" name="return_qs" value="' . e($returnQs) . '">'
        . '<button type="submit" class="row-btn ' . e($cls) . '" title="' . e($label) . '" aria-label="' . e($label) . '">' . icon($icon) . '</button></form>';
};
?>
<section class="crud-page">
    <div class="page-header">
        <div><h1>User Management</h1><p class="page-sub">Kelola akun, role, dan status pengguna. Hanya Admin yang dapat mengakses halaman ini.</p></div>
        <div class="page-actions"><button type="button" class="btn btn-primary" data-action="create" <?= $migrated ? '' : 'disabled' ?>><?= icon('plus') ?>Tambah pengguna</button></div>
    </div>

    <?php if (!$migrated): ?>
        <div class="notice notice-warning" role="alert"><?= icon('triangle-alert') ?><div><strong>Migrasi database belum diterapkan.</strong> Impor <code>database/migrations/002_stage6_users_security.sql</code> melalui phpMyAdmin agar pembuatan akun dan reset password (dengan wajib ganti password) dapat dipakai.</div></div>
    <?php endif; ?>

    <div class="mini-stats">
        <?= ui_mini_stat('Total akun', format_number($sum['n'], 0)) ?>
        <?= ui_mini_stat('Akun aktif', format_number($sum['act'], 0)) ?>
        <?= ui_mini_stat('Admin aktif', format_number($sum['adm'], 0), 'minimal 1 harus tersisa') ?>
        <?= ui_mini_stat('Terkunci sementara', format_number($sum['locked'], 0), 'karena gagal login') ?>
    </div>

    <form class="card toolbar" method="get" action="<?= e(url($path)) ?>">
        <input type="hidden" name="sort" value="<?= e($req['sort']) ?>"><input type="hidden" name="dir" value="<?= e($req['dir']) ?>">
        <label class="search-box"><?= icon('search') ?><input type="search" name="q" value="<?= e($f['q']) ?>" placeholder="Cari nama atau email…" maxlength="100" aria-label="Cari"></label>
        <select name="role" class="form-select" data-autosubmit aria-label="Role"><option value="">Semua role</option><?php foreach (USER_ROLES as $k => $l) echo $opt($k, $f['role'], $l); ?></select>
        <select name="status" class="form-select" data-autosubmit aria-label="Status"><option value="">Semua status</option><?php foreach (USER_STATUS as $k => $l) echo $opt($k, $f['status'], $l); ?></select>
        <select name="per" class="form-select form-select-sm" data-autosubmit aria-label="Baris per halaman"><?php foreach (PER_PAGE_OPTIONS as $n) echo $opt($n, $req['per'], $n . ' / halaman'); ?></select>
        <button type="submit" class="btn btn-outline btn-sm"><?= icon('search') ?>Cari</button>
        <?php if ($hasFilter): ?><a class="btn btn-outline btn-sm" href="<?= e(url($path)) ?>"><?= icon('rotate-ccw') ?>Reset</a><?php endif; ?>
    </form>

    <div class="card table-card">
        <?php if ($total === 0): ?>
            <?= ui_empty_state('search', 'Tidak ada pengguna yang cocok', 'Ubah kata kunci atau filter.', '<a class="btn btn-outline btn-sm" href="' . e(url($path)) . '">Reset filter</a>') ?>
        <?php else: ?>
        <div class="table-scroll"><table class="table table-hover">
            <thead><tr><?= ui_sort_th('Pengguna', 'name', $req, $path) ?><?= ui_sort_th('Role', 'role', $req, $path) ?><?= ui_sort_th('Status', 'status', $req, $path) ?><?= ui_sort_th('Login terakhir', 'last_login', $req, $path) ?><?= ui_sort_th('Dibuat', 'created', $req, $path) ?><th class="col-actions"><span class="sr-only">Aksi</span></th></tr></thead>
            <tbody>
            <?php foreach ($rows as $u): $self = (int) $u['id'] === (int) $user['id']; ?>
                <tr data-record="<?= e(json_encode(user_record($u, (int) $user['id']), JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT)) ?>">
                    <td><strong><?= e($u['name']) ?></strong><?= $self ? ' <span class="pill pill-neutral">Anda</span>' : '' ?><span class="cell-sub"><?= e($u['email']) ?></span></td>
                    <td><?= ui_badge(USER_ROLES[$u['role']] ?? $u['role'], $roleVariant[$u['role']] ?? 'neutral') ?></td>
                    <td><?= ui_badge(USER_STATUS[$u['status']] ?? $u['status'], $u['status'] === 'active' ? 'success' : 'neutral') ?>
                        <?= $u['is_locked'] ? ui_badge('Terkunci', 'danger') : '' ?><?= $u['must_change_password'] ? ui_badge('Wajib ganti password', 'warning') : '' ?></td>
                    <td><?= e(format_datetime($u['last_login_at'])) ?></td>
                    <td><?= e(format_datetime($u['created_at'])) ?></td>
                    <td class="col-actions">
                        <?= ui_row_action('detail', 'Lihat detail', 'eye') ?>
                        <?= ui_row_action('edit', 'Edit nama dan role', 'pencil') ?>
                        <?php if ($u['is_locked']): ?><?= $act((int) $u['id'], 'unlock', 'Buka kunci akun', 'lock', 'Buka kunci akun ' . $u['name'] . '?') ?><?php endif; ?>
                        <?php if (!$self && $migrated): ?><?= $act((int) $u['id'], 'reset', 'Reset password', 'refresh-cw', 'Reset password ' . $u['name'] . '? Password sementara baru akan ditampilkan sekali dan sesi lamanya dicabut.') ?><?php endif; ?>
                        <?php if (!$self): ?>
                            <?= $u['status'] === 'active'
                                ? $act((int) $u['id'], 'deactivate', 'Nonaktifkan akun', 'x', 'Nonaktifkan akun ' . $u['name'] . '? Sesinya akan langsung diputus.', 'is-danger')
                                : $act((int) $u['id'], 'activate', 'Aktifkan akun', 'circle-check') ?>
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table></div>
        <?= ui_pagination($total, $pageNo, $req['per'], $path) ?>
        <?php endif; ?>
    </div>
</section>

<?= ui_detail_dialog() ?>

<dialog class="modal" id="formDialog" data-title-create="Tambah pengguna" data-title-edit="Edit pengguna" aria-labelledby="formTitle">
    <form method="post" action="<?= e(url('modules/users/save.php')) ?>" id="entityForm">
        <?= csrf_field() ?><input type="hidden" name="id" value=""><input type="hidden" name="return_qs" value="<?= e($returnQs) ?>">
        <div class="modal-head"><h3 id="formTitle">Tambah pengguna</h3><button type="button" class="icon-btn" data-close aria-label="Tutup"><?= icon('x') ?></button></div>
        <div class="modal-body form-grid">
            <div class="field field-full"><label for="f_name">Nama lengkap <b class="req">*</b></label><input id="f_name" name="name" maxlength="100" required><p class="field-error" data-error-for="name"></p></div>
            <div class="field field-full"><label for="f_email">Email <b class="req">*</b></label><input id="f_email" name="email" type="email" maxlength="150" required autocomplete="off"><small class="field-hint" id="emailHint">Dipakai untuk login. Tidak dapat diubah setelah akun dibuat.</small><p class="field-error" data-error-for="email"></p></div>
            <div class="field field-full"><label for="f_role">Role <b class="req">*</b></label>
                <select id="f_role" name="role" class="form-select" required>
                    <option value="">Pilih role</option>
                    <option value="viewer">Viewer — hanya melihat</option><option value="hc_staff">HC Staff — kelola data, import, laporan</option><option value="admin">Admin — akses penuh</option>
                </select><small class="field-hint" id="roleHint"></small><p class="field-error" data-error-for="role"></p></div>
            <div class="field field-full" id="createNote"><div class="notice notice-info" style="margin:0"><?= icon('info') ?><div>Sistem membuat <strong>password sementara</strong> secara acak dan menampilkannya <strong>sekali</strong> setelah akun dibuat. Pengguna wajib menggantinya saat login pertama.</div></div></div>
        </div>
        <div class="modal-foot"><button type="button" class="btn btn-outline" data-close>Batal</button><button type="submit" class="btn btn-primary">Simpan</button></div>
    </form>
</dialog>

<?php if ($secret): ?>
<dialog class="modal" id="secretDialog" data-autoopen aria-labelledby="secretTitle">
    <div class="modal-head"><h3 id="secretTitle"><?= $secret['kind'] === 'create' ? 'Akun berhasil dibuat' : 'Password direset' ?></h3></div>
    <div class="modal-body">
        <p style="margin:0 0 10px">Berikan kredensial berikut kepada <strong><?= e($secret['name']) ?></strong> melalui saluran yang aman. Password ini <strong>hanya ditampilkan sekali</strong> dan tidak dapat dilihat lagi.</p>
        <dl class="detail-list"><div><dt>Email</dt><dd><?= e($secret['email']) ?></dd></div><div><dt>Password sementara</dt><dd><code id="secretValue" class="secret-code"><?= e($secret['password']) ?></code></dd></div></dl>
        <div class="notice notice-warning" style="margin:12px 0 0"><?= icon('triangle-alert') ?><div>Pengguna akan diminta mengganti password ini saat login pertama.</div></div>
    </div>
    <div class="modal-foot"><button type="button" class="btn btn-outline" id="copySecret"><?= icon('circle-check') ?>Salin password</button><button type="button" class="btn btn-primary" data-close>Saya sudah mencatatnya</button></div>
</dialog>
<?php endif; ?>

<script type="application/json" id="formState"><?= json_encode($formState, JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_UNESCAPED_UNICODE) ?></script>
<?php require BASE_PATH . '/includes/footer.php'; ?>
