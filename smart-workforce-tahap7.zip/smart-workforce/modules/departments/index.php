<?php
declare(strict_types=1);
require_once dirname(__DIR__, 2) . '/includes/bootstrap.php';
require_once __DIR__ . '/repo.php';

$user      = require_permission('departments.view');
$canManage = user_can('departments.manage', $user);
$path      = 'modules/departments/index.php';

$f       = dept_filters();
$req     = list_request(DEPT_SORT, 'code', 'asc');
$total   = dept_count($f);
$pageNo  = list_clamp_page($total, $req['page'], $req['per']);
$rows    = dept_list($f, $req, $pageNo);
$hasFilter = $f['q'] !== '' || $f['status'] !== '';
$formState = form_state_pull('departments');
$returnQs  = safe_return_qs($_SERVER['QUERY_STRING'] ?? '');

$page = ['title' => 'Departemen', 'active' => 'departments', 'breadcrumb' => ['Workforce Management', 'Departemen'], 'css' => ['crud.css'], 'js' => ['crud.js']];
require BASE_PATH . '/includes/header.php';
$opt = fn ($v, $cur, $label) => '<option value="' . e($v) . '"' . ((string) $v === (string) $cur ? ' selected' : '') . '>' . e($label) . '</option>';
?>
<section class="crud-page">
    <div class="page-header">
        <div><h1>Departemen</h1><p class="page-sub">Master departemen dan jumlah tenaga kerjanya.</p></div>
        <div class="page-actions">
            <?php if ($canManage): ?><button type="button" class="btn btn-primary" data-action="create"><?= icon('plus') ?>Tambah departemen</button><?php endif; ?>
        </div>
    </div>

    <form class="card toolbar" method="get" action="<?= e(url($path)) ?>">
        <input type="hidden" name="sort" value="<?= e($req['sort']) ?>"><input type="hidden" name="dir" value="<?= e($req['dir']) ?>">
        <label class="search-box"><?= icon('search') ?><input type="search" name="q" value="<?= e($f['q']) ?>" placeholder="Cari kode, nama, atau deskripsi…" maxlength="100" aria-label="Cari"></label>
        <select name="status" class="form-select" data-autosubmit aria-label="Status">
            <option value="">Semua status</option>
            <?php foreach (ACTIVE_STATUSES as $k => $l) echo $opt($k, $f['status'], $l); ?>
        </select>
        <select name="per" class="form-select form-select-sm" data-autosubmit aria-label="Baris per halaman">
            <?php foreach (PER_PAGE_OPTIONS as $n) echo $opt($n, $req['per'], $n . ' / halaman'); ?>
        </select>
        <button type="submit" class="btn btn-outline btn-sm"><?= icon('search') ?>Cari</button>
        <?php if ($hasFilter): ?><a class="btn btn-outline btn-sm" href="<?= e(url($path)) ?>"><?= icon('rotate-ccw') ?>Reset</a><?php endif; ?>
    </form>

    <div class="card table-card">
        <?php if ($total === 0): ?>
            <?= $hasFilter
                ? ui_empty_state('search', 'Tidak ada departemen yang cocok', 'Coba ubah kata kunci atau filter.', '<a class="btn btn-outline btn-sm" href="' . e(url($path)) . '">Reset filter</a>')
                : ui_empty_state('building-2', 'Belum ada departemen', $canManage ? 'Tambahkan departemen pertama untuk mulai mengelompokkan tenaga kerja.' : 'Data akan tampil setelah ditambahkan oleh HC Staff atau Admin.') ?>
        <?php else: ?>
        <div class="table-scroll">
            <table class="table table-hover">
                <thead><tr>
                    <?= ui_sort_th('Kode', 'code', $req, $path) ?>
                    <?= ui_sort_th('Nama', 'name', $req, $path) ?>
                    <th>Deskripsi</th>
                    <?= ui_sort_th('Aktif', 'active', $req, $path, 'num') ?>
                    <?= ui_sort_th('Total', 'employees', $req, $path, 'num') ?>
                    <?= ui_sort_th('Status', 'status', $req, $path) ?>
                    <th class="col-actions"><span class="sr-only">Aksi</span></th>
                </tr></thead>
                <tbody>
                <?php foreach ($rows as $r): ?>
                    <tr data-record="<?= e(json_encode(dept_record($r), JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT)) ?>">
                        <td><code><?= e($r['code']) ?></code></td>
                        <td><strong><?= e($r['name']) ?></strong></td>
                        <td class="text-truncate"><?= e($r['description'] ?: '-') ?></td>
                        <td class="num"><?= e($r['active_emp']) ?></td>
                        <td class="num"><?= e($r['total_emp']) ?></td>
                        <td><?= ui_badge(ACTIVE_STATUSES[$r['status']] ?? $r['status'], $r['status'] === 'active' ? 'success' : 'neutral') ?></td>
                        <td class="col-actions">
                            <?= ui_row_action('detail', 'Lihat detail', 'eye') ?>
                            <?php if ($canManage): ?><?= ui_row_action('edit', 'Edit', 'pencil') ?><?= ui_row_action('delete', 'Hapus', 'trash-2', 'is-danger') ?><?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        <?= ui_pagination($total, $pageNo, $req['per'], $path) ?>
        <?php endif; ?>
    </div>
</section>

<?= ui_detail_dialog() ?>
<?php if ($canManage): ?>
<?= ui_confirm_dialog(url('modules/departments/delete.php'), $returnQs) ?>
<dialog class="modal" id="formDialog" data-title-create="Tambah departemen" data-title-edit="Edit departemen" aria-labelledby="formTitle">
    <form method="post" action="<?= e(url('modules/departments/save.php')) ?>">
        <?= csrf_field() ?><input type="hidden" name="id" value=""><input type="hidden" name="return_qs" value="<?= e($returnQs) ?>">
        <div class="modal-head"><h3 id="formTitle">Tambah departemen</h3><button type="button" class="icon-btn" data-close aria-label="Tutup"><?= icon('x') ?></button></div>
        <div class="modal-body form-grid">
            <div class="field"><label for="f_code">Kode <b class="req">*</b></label><input id="f_code" name="code" maxlength="20" required autocomplete="off" style="text-transform:uppercase"><small class="field-hint">Unik. Contoh: HCM</small><p class="field-error" data-error-for="code"></p></div>
            <div class="field"><label for="f_status">Status <b class="req">*</b></label><select id="f_status" name="status" class="form-select" required><?php foreach (ACTIVE_STATUSES as $k => $l) echo '<option value="' . e($k) . '">' . e($l) . '</option>'; ?></select><p class="field-error" data-error-for="status"></p></div>
            <div class="field field-full"><label for="f_name">Nama departemen <b class="req">*</b></label><input id="f_name" name="name" maxlength="120" required><p class="field-error" data-error-for="name"></p></div>
            <div class="field field-full"><label for="f_description">Deskripsi</label><textarea id="f_description" name="description" rows="3" maxlength="1000"></textarea><p class="field-error" data-error-for="description"></p></div>
        </div>
        <div class="modal-foot"><button type="button" class="btn btn-outline" data-close>Batal</button><button type="submit" class="btn btn-primary">Simpan</button></div>
    </form>
</dialog>
<?php endif; ?>
<script type="application/json" id="formState"><?= json_encode($formState, JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_UNESCAPED_UNICODE) ?></script>
<?php require BASE_PATH . '/includes/footer.php'; ?>
