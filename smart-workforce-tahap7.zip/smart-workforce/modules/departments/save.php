<?php
declare(strict_types=1);
require_once dirname(__DIR__, 2) . '/includes/bootstrap.php';
require_once __DIR__ . '/repo.php';

$user = require_permission('departments.manage');
if (!is_post()) {
    redirect('modules/departments/index.php');
}
csrf_require();

$back = 'modules/departments/index.php';
$rqs  = $_POST['return_qs'] ?? '';
$id   = (isset($_POST['id']) && ctype_digit((string) $_POST['id'])) ? (int) $_POST['id'] : 0;
$existing = $id > 0 ? dept_find($id) : null;
if ($id > 0 && $existing === null) {
    flash_set('danger', 'Departemen tidak ditemukan atau sudah dihapus.');
    redirect_to_list($back, $rqs);
}

[$d, $errors] = dept_validate($_POST, $existing);
$fail = function (array $errors) use ($existing, $id, $rqs, $back): void {
    form_state_set('departments', ['mode' => $existing ? 'edit' : 'create', 'id' => $id, 'old' => post_old_input(DEPT_FORM_FIELDS), 'errors' => $errors]);
    flash_set('warning', 'Periksa kembali isian formulir.');
    redirect_to_list($back, $rqs);
};
if ($errors) {
    $fail($errors);
}

try {
    if ($existing) {
        db_run('UPDATE departments SET code = ?, name = ?, description = ?, status = ? WHERE id = ?', 'ssssi', [$d['code'], $d['name'], $d['description'], $d['status'], $id]);
        $changed = changed_fields($existing, $d);
        audit_log('update', 'department', $id, 'Mengubah departemen ' . $d['code'] . ($changed ? ' (kolom: ' . implode(', ', $changed) . ')' : ' (tanpa perubahan)'), (int) $user['id']);
        flash_set('success', 'Departemen ' . $d['name'] . ' berhasil diperbarui.');
    } else {
        db_run('INSERT INTO departments (code, name, description, status) VALUES (?, ?, ?, ?)', 'ssss', [$d['code'], $d['name'], $d['description'], $d['status']]);
        audit_log('create', 'department', db_last_id(), 'Menambah departemen ' . $d['code'], (int) $user['id']);
        flash_set('success', 'Departemen ' . $d['name'] . ' berhasil ditambahkan.');
    }
} catch (Throwable $ex) {
    if (is_duplicate_error($ex)) {
        $fail(['code' => 'Kode departemen sudah dipakai.']);
    }
    throw $ex;
}
redirect_to_list($back, $rqs);
