<?php
/**
 * Data & aturan bisnis modul Departemen.
 * KEBIJAKAN: departemen tidak dapat dihapus jika masih memiliki tenaga kerja (berapa pun statusnya),
 * dan tidak dapat dinonaktifkan selama masih memiliki tenaga kerja berstatus Aktif.
 */
declare(strict_types=1);

const DEPT_SORT = ['code' => 'd.code', 'name' => 'd.name', 'status' => 'd.status', 'employees' => 'total_emp', 'active' => 'active_emp'];
const DEPT_FORM_FIELDS = ['code', 'name', 'description', 'status'];

function dept_filters(): array
{
    $g = fn (string $k): string => (isset($_GET[$k]) && is_string($_GET[$k])) ? trim($_GET[$k]) : '';
    return ['q' => mb_substr($g('q'), 0, 100), 'status' => array_key_exists($g('status'), ACTIVE_STATUSES) ? $g('status') : ''];
}

function dept_where(array $f): array
{
    $w = []; $types = ''; $params = [];
    if ($f['q'] !== '') {
        $like = '%' . like_escape($f['q']) . '%';
        $w[] = '(d.code LIKE ? OR d.name LIKE ? OR d.description LIKE ?)';
        $types .= 'sss';
        array_push($params, $like, $like, $like);
    }
    if ($f['status'] !== '') { $w[] = 'd.status = ?'; $types .= 's'; $params[] = $f['status']; }
    return [$w ? 'WHERE ' . implode(' AND ', $w) : '', $types, $params];
}

function dept_count(array $f): int
{
    [$where, $types, $params] = dept_where($f);
    return (int) db_value("SELECT COUNT(*) FROM departments d {$where}", $types, $params);
}

function dept_list(array $f, array $req, int $page): array
{
    [$where, $types, $params] = dept_where($f);
    $sql = "SELECT d.*,
                   (SELECT COUNT(*) FROM employees e WHERE e.department_id = d.id) AS total_emp,
                   (SELECT COUNT(*) FROM employees e WHERE e.department_id = d.id AND e.status = 'active') AS active_emp
            FROM departments d {$where}
            ORDER BY {$req['order_sql']}, d.id ASC LIMIT ? OFFSET ?";
    return db_fetch_all($sql, $types . 'ii', array_merge($params, [$req['per'], ($page - 1) * $req['per']]));
}

function dept_find(int $id): ?array
{
    return db_fetch_one('SELECT * FROM departments WHERE id = ?', 'i', [$id]);
}

function dept_record(array $r): array
{
    $raw = ['id' => (string) $r['id']];
    foreach (DEPT_FORM_FIELDS as $k) {
        $raw[$k] = (string) ($r[$k] ?? '');
    }
    return [
        'raw' => $raw, 'title' => $r['name'], 'name' => $r['code'] . ' — ' . $r['name'],
        'details' => [
            ['Kode', $r['code']], ['Nama', $r['name']], ['Deskripsi', $r['description'] ?: '-'],
            ['Status', ACTIVE_STATUSES[$r['status']] ?? $r['status']],
            ['Tenaga kerja aktif', (string) $r['active_emp']], ['Total tenaga kerja', (string) $r['total_emp']],
            ['Dibuat', format_datetime($r['created_at'])],
        ],
    ];
}

function dept_validate(array $in, ?array $existing): array
{
    $s = fn (string $k, int $max = 255): string => (isset($in[$k]) && is_string($in[$k])) ? mb_substr(trim($in[$k]), 0, $max) : '';
    $e = [];
    $c = ['code' => strtoupper($s('code', 20)), 'name' => preg_replace('/\s+/', ' ', $s('name', 120)), 'description' => $s('description', 1000), 'status' => $s('status', 10)];
    $id = $existing ? (int) $existing['id'] : null;

    if (!preg_match('/^[A-Z0-9][A-Z0-9_-]{1,19}$/', $c['code'])) {
        $e['code'] = 'Kode wajib diisi (2–20 karakter: huruf, angka, strip, garis bawah).';
    } elseif (!is_unique_value('departments', 'code', $c['code'], $id)) {
        $e['code'] = 'Kode departemen sudah dipakai.';
    }
    if (!val_len($c['name'], 2, 120)) {
        $e['name'] = 'Nama departemen wajib diisi (2–120 karakter).';
    }
    if (!array_key_exists($c['status'], ACTIVE_STATUSES)) {
        $e['status'] = 'Pilih status yang valid.';
    } elseif ($c['status'] === 'inactive' && $existing && $existing['status'] === 'active') {
        $n = (int) db_value("SELECT COUNT(*) FROM employees WHERE department_id = ? AND status = 'active'", 'i', [$id]);
        if ($n > 0) {
            $e['status'] = "Tidak dapat dinonaktifkan: masih ada {$n} tenaga kerja aktif di departemen ini.";
        }
    }
    $c['description'] = null_if_empty($c['description']);
    return [$c, $e];
}
