<?php
declare(strict_types=1);
require_once dirname(__DIR__, 2) . '/includes/bootstrap.php';
require_once __DIR__ . '/repo.php';

$user = require_permission('departments.manage');
if (!is_post()) {
    redirect('modules/departments/index.php');
}
csrf_require();

$back = 'modules/departments/index.php';
$rqs  = $_POST['return_qs'] ?? '';
$id   = (isset($_POST['id']) && ctype_digit((string) $_POST['id'])) ? (int) $_POST['id'] : 0;
$dept = $id > 0 ? dept_find($id) : null;
if ($dept === null) {
    flash_set('danger', 'Departemen tidak ditemukan atau sudah dihapus.');
    redirect_to_list($back, $rqs);
}

$n = (int) db_value('SELECT COUNT(*) FROM employees WHERE department_id = ?', 'i', [$id]);
if ($n > 0) {
    audit_log('delete_blocked', 'department', $id, 'Penghapusan ditolak: ' . $dept['code'] . " masih memiliki {$n} tenaga kerja", (int) $user['id']);
    flash_set('danger', 'Departemen ' . $dept['name'] . " tidak dapat dihapus karena masih memiliki {$n} tenaga kerja. Pindahkan tenaga kerja atau nonaktifkan departemen.");
    redirect_to_list($back, $rqs);
}

try {
    db_run('DELETE FROM departments WHERE id = ?', 'i', [$id]);
} catch (Throwable $e) {
    if (is_fk_error($e)) {
        flash_set('danger', 'Departemen ' . $dept['name'] . ' tidak dapat dihapus karena masih direferensikan data lain.');
        redirect_to_list($back, $rqs);
    }
    throw $e;
}
audit_log('delete', 'department', $id, 'Menghapus departemen ' . $dept['code'], (int) $user['id']);
flash_set('success', 'Departemen ' . $dept['name'] . ' berhasil dihapus.');
redirect_to_list($back, $rqs);
