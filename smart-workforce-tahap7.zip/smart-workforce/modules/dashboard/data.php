<?php
/**
 * Endpoint JSON dashboard (GET, hanya baca).
 * Parameter: period=YYYY-MM, dept=<id departemen> (opsional)
 */
declare(strict_types=1);
require_once dirname(__DIR__, 2) . '/includes/bootstrap.php';
require_once __DIR__ . '/queries.php';

require_permission('dashboard.view', true);

if (($_SERVER['REQUEST_METHOD'] ?? 'GET') !== 'GET') {
    json_response(['success' => false, 'message' => 'Metode tidak diizinkan.'], 405);
}

header('Cache-Control: no-store');

try {
    $period = dash_parse_period($_GET['period'] ?? null);
    $dept   = dash_parse_department($_GET['dept'] ?? null);
    json_response(dash_build_payload($period, $dept));
} catch (Throwable $e) {
    error_log('[DASHBOARD] ' . $e->getMessage() . ' @ ' . $e->getFile() . ':' . $e->getLine());
    json_response(['success' => false, 'message' => 'Data dashboard tidak dapat dimuat saat ini.'], 500);
}
