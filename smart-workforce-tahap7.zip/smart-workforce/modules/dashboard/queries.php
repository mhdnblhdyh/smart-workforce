<?php
/**
 * Query agregasi dashboard. SEMUA angka dihitung di MySQL, bukan di frontend.
 *
 * DEFINISI (konsisten untuk dashboard, dan dipakai ulang modul Analytics/Report/Data Quality):
 *  - "Aktif pada bulan M"  : start_date <= akhir bulan M  DAN  (end_date NULL ATAU end_date >= awal bulan M).
 *                            Berbasis tanggal supaya periode historis akurat; kolom status adalah kondisi saat ini.
 *  - "Mandays bulan M"     : SUM(workforce_records.mandays) dengan period_month = awal bulan M. Bukan jumlah karyawan.
 *  - "Record lengkap"      : jabatan terisi, TAD punya vendor, peserta magang punya tanggal berakhir,
 *                            dan ada record mandays pada bulan M.
 *  - "Kelengkapan data"    : record lengkap / tenaga kerja aktif pada bulan M x 100.
 */
declare(strict_types=1);

/** Fragmen SQL: karyawan e aktif pada bulan yang dimulai ?, membutuhkan 2 parameter 's' (awal bulan, awal bulan). */
const SQL_ACTIVE_IN_MONTH = '(e.start_date <= LAST_DAY(?) AND (e.end_date IS NULL OR e.end_date >= ?))';

/** Daftar bulan yang bisa dipilih ('YYYY-MM'): bulan yang punya record mandays + bulan berjalan. Terbaru dulu. */
function dash_period_options(): array
{
    $rows   = db_fetch_all("SELECT DISTINCT DATE_FORMAT(period_month, '%Y-%m') AS ym FROM workforce_records ORDER BY ym DESC");
    $months = array_column($rows, 'ym');
    $now    = date('Y-m');
    if (!in_array($now, $months, true)) {
        array_unshift($months, $now);
    }
    return $months;
}

/** Periode bawaan: bulan terbaru yang memiliki data mandays; jika kosong, bulan berjalan. */
function dash_default_period(): string
{
    $ym = db_value("SELECT DATE_FORMAT(MAX(period_month), '%Y-%m') FROM workforce_records");
    return $ym ?: date('Y-m');
}

/** Validasi input periode dari pengguna. Mengembalikan 'YYYY-MM' yang valid. */
function dash_parse_period($raw): string
{
    if (is_string($raw) && preg_match('/^(\d{4})-(0[1-9]|1[0-2])$/', $raw, $m) && (int) $m[1] >= 2000 && (int) $m[1] <= 2100) {
        return $raw;
    }
    return dash_default_period();
}

/** Validasi departemen; null = semua departemen. */
function dash_parse_department($raw): ?int
{
    if (!is_string($raw) || !ctype_digit($raw) || (int) $raw <= 0) {
        return null;
    }
    $id = (int) $raw;
    return db_value('SELECT id FROM departments WHERE id = ?', 'i', [$id]) !== null ? $id : null;
}

function dash_month_start(string $ym): string
{
    return $ym . '-01';
}

function dash_shift_month(string $ym, int $delta): string
{
    return date('Y-m', strtotime(dash_month_start($ym) . " {$delta} month"));
}

/** Rentang 12 bulan yang berakhir pada $ym (urut lama -> baru). */
function dash_trend_months(string $ym, int $count = 12): array
{
    $out = [];
    for ($i = $count - 1; $i >= 0; $i--) {
        $out[] = dash_shift_month($ym, -$i);
    }
    return $out;
}

/** KPI headcount untuk satu bulan: total, per kategori, jumlah record lengkap. */
function dash_headcount(string $ms, ?int $dept): array
{
    $sql = "SELECT COUNT(*) AS total,
                   COALESCE(SUM(e.category = 'employee'), 0) AS employee,
                   COALESCE(SUM(e.category = 'tad'), 0)      AS tad,
                   COALESCE(SUM(e.category = 'intern'), 0)   AS intern,
                   COALESCE(SUM(
                       e.position IS NOT NULL AND e.position <> ''
                       AND (e.category <> 'tad' OR e.vendor_id IS NOT NULL)
                       AND (e.category <> 'intern' OR e.end_date IS NOT NULL)
                       AND EXISTS (SELECT 1 FROM workforce_records r WHERE r.employee_id = e.id AND r.period_month = ?)
                   ), 0) AS complete
            FROM employees e
            WHERE " . SQL_ACTIVE_IN_MONTH;
    $types  = 'sss';
    $params = [$ms, $ms, $ms];
    if ($dept !== null) {
        $sql .= ' AND e.department_id = ?';
        $types .= 'i';
        $params[] = $dept;
    }
    $row = db_fetch_one($sql, $types, $params) ?? [];
    return array_map('intval', $row + ['total' => 0, 'employee' => 0, 'tad' => 0, 'intern' => 0, 'complete' => 0]);
}

/** Total mandays dan jumlah record pada satu bulan. */
function dash_mandays_total(string $ms, ?int $dept): array
{
    $sql = 'SELECT COALESCE(SUM(r.mandays), 0) AS total, COUNT(r.id) AS records
            FROM workforce_records r JOIN employees e ON e.id = r.employee_id
            WHERE r.period_month = ?';
    $types  = 's';
    $params = [$ms];
    if ($dept !== null) {
        $sql .= ' AND e.department_id = ?';
        $types .= 'i';
        $params[] = $dept;
    }
    $row = db_fetch_one($sql, $types, $params);
    return ['total' => (float) $row['total'], 'records' => (int) $row['records']];
}

function dash_department_count(?int $dept): int
{
    return $dept !== null ? 1 : (int) db_value("SELECT COUNT(*) FROM departments WHERE status = 'active'");
}

/** Vendor berstatus aktif (jika ada filter departemen: yang punya tenaga kerja aktif di departemen itu pada bulan tsb). */
function dash_active_vendor_count(string $ms, ?int $dept): int
{
    if ($dept === null) {
        return (int) db_value("SELECT COUNT(*) FROM vendors WHERE status = 'active'");
    }
    return (int) db_value(
        "SELECT COUNT(*) FROM vendors v WHERE v.status = 'active' AND EXISTS (
            SELECT 1 FROM employees e
            WHERE e.vendor_id = v.id AND e.department_id = ? AND " . SQL_ACTIVE_IN_MONTH . ')',
        'iss',
        [$dept, $ms, $ms]
    );
}

/** Tren 12 bulan: total & per kategori (satu query agregasi, bulan dibangkitkan lewat UNION ALL). */
function dash_trend(string $ym, ?int $dept): array
{
    $months = dash_trend_months($ym);
    $union  = implode(' UNION ALL ', array_fill(0, count($months), 'SELECT CAST(? AS DATE) AS ms'));
    $sql    = "SELECT m.ms,
                      COUNT(e.id) AS total,
                      COALESCE(SUM(e.category = 'employee'), 0) AS employee,
                      COALESCE(SUM(e.category = 'tad'), 0)      AS tad,
                      COALESCE(SUM(e.category = 'intern'), 0)   AS intern
               FROM ({$union}) m
               LEFT JOIN employees e
                      ON e.start_date <= LAST_DAY(m.ms) AND (e.end_date IS NULL OR e.end_date >= m.ms)";
    $types  = str_repeat('s', count($months));
    $params = array_map('dash_month_start', $months);
    if ($dept !== null) {
        $sql .= ' AND e.department_id = ?';
        $types .= 'i';
        $params[] = $dept;
    }
    $sql .= ' GROUP BY m.ms ORDER BY m.ms';

    $byMonth = [];
    foreach (db_fetch_all($sql, $types, $params) as $r) {
        $byMonth[substr($r['ms'], 0, 7)] = $r;
    }
    $out = ['labels' => [], 'total' => [], 'employee' => [], 'tad' => [], 'intern' => []];
    foreach ($months as $m) {
        $r = $byMonth[$m] ?? ['total' => 0, 'employee' => 0, 'tad' => 0, 'intern' => 0];
        $out['labels'][]   = month_label($m, true);
        $out['total'][]    = (int) $r['total'];
        $out['employee'][] = (int) $r['employee'];
        $out['tad'][]      = (int) $r['tad'];
        $out['intern'][]   = (int) $r['intern'];
    }
    return $out;
}

/** Distribusi tenaga kerja aktif per departemen. */
function dash_by_department(string $ms, ?int $dept): array
{
    $sql = "SELECT d.id, d.code, d.name, COUNT(e.id) AS total
            FROM departments d
            LEFT JOIN employees e ON e.department_id = d.id AND " . SQL_ACTIVE_IN_MONTH . "
            WHERE (d.status = 'active' OR e.id IS NOT NULL)";
    $types  = 'ss';
    $params = [$ms, $ms];
    if ($dept !== null) {
        $sql .= ' AND d.id = ?';
        $types .= 'i';
        $params[] = $dept;
    }
    $sql .= ' GROUP BY d.id, d.code, d.name ORDER BY total DESC, d.name ASC';
    return db_fetch_all($sql, $types, $params);
}

/** Total mandays per departemen pada satu bulan. */
function dash_mandays_by_department(string $ms, ?int $dept): array
{
    $sql = "SELECT d.id, d.code, d.name, COALESCE(SUM(r.mandays), 0) AS total
            FROM departments d
            LEFT JOIN employees e ON e.department_id = d.id
            LEFT JOIN workforce_records r ON r.employee_id = e.id AND r.period_month = ?
            WHERE (d.status = 'active' OR r.id IS NOT NULL)";
    $types  = 's';
    $params = [$ms];
    if ($dept !== null) {
        $sql .= ' AND d.id = ?';
        $types .= 'i';
        $params[] = $dept;
    }
    $sql .= ' GROUP BY d.id, d.code, d.name ORDER BY total DESC, d.name ASC';
    return db_fetch_all($sql, $types, $params);
}

/**
 * Ringkasan data quality untuk tenaga kerja aktif pada bulan tsb.
 * Tiga tingkat: 'error' (pasti salah/kosong), 'review' (anomali yang perlu ditinjau), 'info' (hanya informasi).
 * Data TIDAK diubah otomatis.
 */
function dash_quality(string $ms, ?int $dept, array $headcount): array
{
    $sql = "SELECT
                COALESCE(SUM(e.position IS NULL OR e.position = ''), 0) AS no_position,
                COALESCE(SUM(e.category = 'tad' AND e.vendor_id IS NULL), 0) AS tad_no_vendor,
                COALESCE(SUM(e.category = 'intern' AND e.end_date IS NULL), 0) AS intern_no_end,
                COALESCE(SUM(NOT EXISTS (SELECT 1 FROM workforce_records r WHERE r.employee_id = e.id AND r.period_month = ?)), 0) AS no_mandays,
                COALESCE(SUM(e.category = 'tad' AND v.id IS NOT NULL AND (v.status = 'inactive' OR (v.contract_end IS NOT NULL AND v.contract_end < ?))), 0) AS tad_vendor_expired
            FROM employees e
            LEFT JOIN vendors v ON v.id = e.vendor_id
            WHERE " . SQL_ACTIVE_IN_MONTH;
    $types  = 'ssss';
    $params = [$ms, $ms, $ms, $ms];
    if ($dept !== null) {
        $sql .= ' AND e.department_id = ?';
        $types .= 'i';
        $params[] = $dept;
    }
    $q = db_fetch_one($sql, $types, $params);

    $attSql = 'SELECT COUNT(*) FROM workforce_records r JOIN employees e ON e.id = r.employee_id
               WHERE r.period_month = ? AND (r.attended_days IS NULL OR r.scheduled_days IS NULL)';
    $attTypes = 's';
    $attParams = [$ms];
    if ($dept !== null) {
        $attSql .= ' AND e.department_id = ?';
        $attTypes .= 'i';
        $attParams[] = $dept;
    }
    $attNull = (int) db_value($attSql, $attTypes, $attParams);

    $checks = [
        ['key' => 'no_position',        'label' => 'Jabatan belum diisi',                          'count' => (int) $q['no_position'],        'level' => 'error',  'hint' => 'Lengkapi jabatan di data tenaga kerja.'],
        ['key' => 'tad_no_vendor',      'label' => 'TAD tanpa vendor',                             'count' => (int) $q['tad_no_vendor'],      'level' => 'error',  'hint' => 'Pilih vendor penyedia untuk setiap TAD.'],
        ['key' => 'intern_no_end',      'label' => 'Peserta magang tanpa tanggal berakhir',        'count' => (int) $q['intern_no_end'],      'level' => 'error',  'hint' => 'Isi tanggal berakhir periode magang.'],
        ['key' => 'no_mandays',         'label' => 'Belum ada record mandays pada periode ini',    'count' => (int) $q['no_mandays'],         'level' => 'error',  'hint' => 'Input atau import mandays untuk periode ini.'],
        ['key' => 'tad_vendor_expired', 'label' => 'TAD aktif pada vendor nonaktif/kontrak habis', 'count' => (int) $q['tad_vendor_expired'], 'level' => 'review', 'hint' => 'Tinjau: perpanjang kontrak vendor atau perbarui data TAD.'],
        ['key' => 'attendance_missing', 'label' => 'Record mandays tanpa data kehadiran',          'count' => $attNull,                       'level' => 'info',   'hint' => 'Informasi saja. Kehadiran tidak diisi/diestimasi bila memang tidak tersedia.'],
    ];

    $total = $headcount['total'];
    return [
        'score'    => $total > 0 ? round($headcount['complete'] / $total * 100, 1) : null,
        'complete' => $headcount['complete'],
        'total'    => $total,
        'checks'   => $checks,
    ];
}

/** Ringkasan per vendor: tenaga kerja aktif, mandays bulan tsb, dan status kontrak. */
function dash_vendor_summary(string $ms, ?int $dept): array
{
    $deptCond = $dept !== null ? ' AND e.department_id = ?' : '';
    $sql = "SELECT v.id, v.code, v.name, v.status, v.contract_end,
                (SELECT COUNT(*) FROM employees e
                  WHERE e.vendor_id = v.id AND " . SQL_ACTIVE_IN_MONTH . $deptCond . ") AS active_workers,
                (SELECT COALESCE(SUM(r.mandays), 0) FROM workforce_records r
                   JOIN employees e ON e.id = r.employee_id
                  WHERE e.vendor_id = v.id AND r.period_month = ?" . $deptCond . ") AS mandays
            FROM vendors v
            ORDER BY active_workers DESC, v.name ASC";
    $types  = 'ss' . ($dept !== null ? 'i' : '') . 's' . ($dept !== null ? 'i' : '');
    $params = [$ms, $ms];
    if ($dept !== null) {
        $params[] = $dept;
    }
    $params[] = $ms;
    if ($dept !== null) {
        $params[] = $dept;
    }

    $rows = [];
    foreach (db_fetch_all($sql, $types, $params) as $r) {
        $contract = vendor_contract_state($r['contract_end']);
        $rows[] = [
            'code'         => $r['code'],
            'name'         => $r['name'],
            'status'       => $r['status'],
            'workers'      => (int) $r['active_workers'],
            'mandays'      => (float) $r['mandays'],
            'contract_end' => $r['contract_end'] ? date('d M Y', strtotime($r['contract_end'])) : null,
            'contract'     => $contract['state'],
            'days_left'    => $contract['days_left'],
        ];
    }
    // Dengan filter departemen, sembunyikan vendor tanpa tenaga kerja & mandays di departemen itu.
    if ($dept !== null) {
        $rows = array_values(array_filter($rows, fn ($r) => $r['workers'] > 0 || $r['mandays'] > 0));
    }
    return $rows;
}

/** Susun seluruh payload dashboard. */
function dash_build_payload(string $ym, ?int $dept): array
{
    $ms     = dash_month_start($ym);
    $prevYm = dash_shift_month($ym, -1);
    $prevMs = dash_month_start($prevYm);

    $cur  = dash_headcount($ms, $dept);
    $prev = dash_headcount($prevMs, $dept);
    $md   = dash_mandays_total($ms, $dept);
    $mdPv = dash_mandays_total($prevMs, $dept);

    $deptName = 'Semua departemen';
    if ($dept !== null) {
        $deptName = (string) db_value('SELECT name FROM departments WHERE id = ?', 'i', [$dept]);
    }

    $byDept = dash_by_department($ms, $dept);
    $mdDept = dash_mandays_by_department($ms, $dept);

    $quality = dash_quality($ms, $dept, $cur);

    $totalEmployeesInDb = (int) db_value('SELECT COUNT(*) FROM employees');

    return [
        'success' => true,
        'meta' => [
            'period'          => $ym,
            'period_label'    => month_label($ym),
            'prev_label'      => month_label($prevYm),
            'department'      => $dept,
            'department_name' => $deptName,
            'database_empty'  => $totalEmployeesInDb === 0,
            'generated_at'    => date('d M Y, H:i'),
        ],
        'kpis' => [
            'headcount'    => ['value' => $cur['total'],  'prev' => $prev['total']],
            'tad'          => ['value' => $cur['tad'],    'prev' => $prev['tad']],
            'intern'       => ['value' => $cur['intern'], 'prev' => $prev['intern']],
            'departments'  => ['value' => dash_department_count($dept)],
            'vendors'      => ['value' => dash_active_vendor_count($ms, $dept)],
            'mandays'      => ['value' => $md['total'], 'prev' => $mdPv['total'], 'records' => $md['records'], 'prev_available' => $mdPv['records'] > 0],
            'completeness' => ['value' => $quality['score'], 'complete' => $quality['complete'], 'total' => $quality['total']],
        ],
        'trend'       => dash_trend($ym, $dept),
        'departments' => [
            'labels' => array_column($byDept, 'code'),
            'names'  => array_column($byDept, 'name'),
            'values' => array_map('intval', array_column($byDept, 'total')),
        ],
        'categories'  => [
            'labels' => ['Karyawan', 'TAD', 'Peserta magang'],
            'values' => [$cur['employee'], $cur['tad'], $cur['intern']],
        ],
        'mandays_dept' => [
            'labels' => array_column($mdDept, 'code'),
            'names'  => array_column($mdDept, 'name'),
            'values' => array_map('floatval', array_column($mdDept, 'total')),
        ],
        'quality' => $quality,
        'vendors' => dash_vendor_summary($ms, $dept),
    ];
}
