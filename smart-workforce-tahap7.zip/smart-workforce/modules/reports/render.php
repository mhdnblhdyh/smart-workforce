<?php
/**
 * Renderer laporan: Excel (PhpSpreadsheet) dan PDF (Dompdf) dari dataset yang SAMA dengan preview.
 * Teks sel tidak pernah ditulis sebagai rumus (anti formula injection); seluruh teks di HTML PDF di-escape.
 */
declare(strict_types=1);

use PhpOffice\PhpSpreadsheet\Cell\Coordinate;
use PhpOffice\PhpSpreadsheet\Cell\DataType;
use PhpOffice\PhpSpreadsheet\IOFactory;
use PhpOffice\PhpSpreadsheet\Shared\Date as XlDate;
use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Style\Alignment;
use PhpOffice\PhpSpreadsheet\Style\Border;
use PhpOffice\PhpSpreadsheet\Style\Fill;
use PhpOffice\PhpSpreadsheet\Worksheet\PageSetup;

function rpt_libs_ready(): bool
{
    $auto = BASE_PATH . '/vendor/autoload.php';
    if (is_file($auto)) {
        require_once $auto;
    }
    return class_exists(Spreadsheet::class) && class_exists(\Dompdf\Dompdf::class);
}

function rpt_filename(array $ds, string $ext): string
{
    $period = preg_replace('/[^0-9A-Za-z_-]/', '', (string) $ds['period_key']);
    return 'laporan-' . $ds['slug'] . '_' . $period . '_' . date('Ymd-His') . '.' . $ext;
}

function rpt_filter_text(array $ds): string
{
    if (!$ds['filters']) {
        return 'Tanpa filter tambahan';
    }
    return implode('; ', array_map(fn ($l) => $l[0] . ': ' . $l[1], $ds['filters']));
}

/** Pasangan [label, nilai] yang sama dipakai di header Excel dan PDF. */
function rpt_header_lines(array $ds, array $meta): array
{
    return [
        ['Periode', $ds['period_label']], ['Filter', rpt_filter_text($ds)], ['Dibuat', $meta['generated_at'] . ' oleh ' . $meta['user']], ['Sumber data', $ds['source']],
    ];
}

/* ====================================================================== EXCEL */
function rpt_render_xlsx(array $ds, array $meta): void
{
    rpt_prepare();
    $ss = new Spreadsheet();
    $ss->getProperties()->setTitle($ds['title'])->setCreator('Smart Workforce Analytics')->setSubject($ds['period_label']);
    $ws = $ss->getActiveSheet();
    $ws->setTitle('Laporan');
    $ncol = count($ds['columns']);
    $lastCol = Coordinate::stringFromColumnIndex(max(2, $ncol));

    $r = 1;
    $ws->setCellValue("A{$r}", $ds['title']);
    $ws->getStyle("A{$r}")->getFont()->setBold(true)->setSize(15);
    $r++;
    foreach (rpt_header_lines($ds, $meta) as [$label, $value]) {
        $ws->setCellValue("A{$r}", $label);
        $ws->getStyle("A{$r}")->getFont()->setBold(true);
        rpt_set_text($ws, "B{$r}", (string) $value);
        $r++;
    }
    $r++;

    if ($ds['summary']) {
        $ws->setCellValue("A{$r}", 'Ringkasan');
        $ws->getStyle("A{$r}")->getFont()->setBold(true)->setSize(12);
        $r++;
        foreach ($ds['summary'] as [$label, $value]) {
            rpt_set_text($ws, "A{$r}", (string) $label);
            rpt_set_text($ws, "B{$r}", (string) $value);
            $ws->getStyle("A{$r}:B{$r}")->getFill()->setFillType(Fill::FILL_SOLID)->getStartColor()->setRGB('F1F5F9');
            $r++;
        }
        $r++;
    }

    $hdr = $r;
    foreach ($ds['columns'] as $i => $c) {
        $ws->setCellValue([$i + 1, $hdr], $c['label']);
        $ws->getColumnDimensionByColumn($i + 1)->setWidth(max((int) $c['w'], 10));
    }
    $ws->getStyle("A{$hdr}:{$lastCol}{$hdr}")->applyFromArray([
        'font' => ['bold' => true, 'color' => ['rgb' => 'FFFFFF']],
        'fill' => ['fillType' => Fill::FILL_SOLID, 'startColor' => ['rgb' => '0B132B']],
        'alignment' => ['vertical' => Alignment::VERTICAL_CENTER, 'wrapText' => true],
    ]);

    $fmt = ['int' => '#,##0', 'dec' => '#,##0.00', 'pct' => '0.0"%"', 'date' => 'dd-mm-yyyy', 'month' => 'mmm yyyy', 'datetime' => 'dd-mm-yyyy hh:mm'];
    $r = $hdr + 1;
    $first = $r;
    foreach ($ds['rows'] as $row) {
        foreach ($ds['columns'] as $i => $c) {
            rpt_set_cell($ws, [$i + 1, $r], $row[$i] ?? null, $c['type']);
        }
        $r++;
    }
    $last = $r - 1;
    foreach ($ds['columns'] as $i => $c) {
        $L = Coordinate::stringFromColumnIndex($i + 1);
        if (isset($fmt[$c['type']]) && $last >= $first) {
            $ws->getStyle("{$L}{$first}:{$L}{$last}")->getNumberFormat()->setFormatCode($fmt[$c['type']]);
        }
        if (in_array($c['type'], ['int', 'dec', 'pct'], true)) {
            $ws->getStyle("{$L}{$hdr}:{$L}" . max($last, $hdr))->getAlignment()->setHorizontal(Alignment::HORIZONTAL_RIGHT);
        }
    }
    if ($ds['total'] !== null) {
        foreach ($ds['columns'] as $i => $c) {
            rpt_set_cell($ws, [$i + 1, $r], $ds['total'][$i] ?? null, $i === 0 ? 'text' : $c['type']);   // kolom pertama baris total = label
            $L = Coordinate::stringFromColumnIndex($i + 1);
            if ($i > 0 && isset($fmt[$c['type']])) {
                $ws->getStyle("{$L}{$r}")->getNumberFormat()->setFormatCode($fmt[$c['type']]);
            }
        }
        $ws->getStyle("A{$r}:{$lastCol}{$r}")->applyFromArray([
            'font' => ['bold' => true], 'fill' => ['fillType' => Fill::FILL_SOLID, 'startColor' => ['rgb' => 'E8EEF9']],
            'borders' => ['top' => ['borderStyle' => Border::BORDER_THIN, 'color' => ['rgb' => '0B132B']]],
        ]);
        $r++;
    }
    if ($last >= $first) {
        $ws->setAutoFilter("A{$hdr}:{$lastCol}{$last}");
    }
    $ws->freezePane('A' . ($hdr + 1));

    $r++;
    $notes = $ds['notes'];
    if ($ds['truncated']) {
        $notes[] = 'Tabel memuat ' . format_number(count($ds['rows']), 0) . ' dari ' . format_number($ds['row_count'], 0) . ' baris (dibatasi). Persempit filter untuk data lengkap. Total di atas dihitung dari seluruh data.';
    }
    foreach ($notes as $n) {
        $ws->setCellValue("A{$r}", 'Catatan: ' . $n);
        $ws->getStyle("A{$r}")->getFont()->setItalic(true)->getColor()->setRGB('64748B');
        $r++;
    }

    // Kolom A/B (header & ringkasan) cukup lebar; sheet siap cetak
    $ws->getColumnDimension('A')->setWidth(max(24, (int) ($ds['columns'][0]['w'] ?? 24)));
    $ws->getPageSetup()->setOrientation($ncol > 6 ? PageSetup::ORIENTATION_LANDSCAPE : PageSetup::ORIENTATION_PORTRAIT)->setPaperSize(PageSetup::PAPERSIZE_A4)->setFitToPage(true)->setFitToWidth(1)->setFitToHeight(0);
    $ws->getPageSetup()->setRowsToRepeatAtTopByStartAndEnd($hdr, $hdr);
    $ws->getHeaderFooter()->setOddFooter('&L' . $ds['title'] . '&RHalaman &P dari &N');

    audit_log('export', 'report', null, sprintf('Ekspor Excel %s (%d baris) — %s; %s', $ds['title'], count($ds['rows']), $ds['period_label'], rpt_filter_text($ds)), $meta['user_id']);

    $fn = rpt_filename($ds, 'xlsx');
    header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
    header('Content-Disposition: attachment; filename="' . $fn . '"');
    header('Cache-Control: no-store');
    IOFactory::createWriter($ss, 'Xlsx')->save('php://output');
    exit;
}

/** Teks aman: selalu string eksplisit, tidak pernah rumus; diawali ' bila tampak seperti rumus. */
function rpt_set_text($ws, string $coord, string $text): void
{
    $ws->setCellValueExplicit($coord, $text, DataType::TYPE_STRING);
    if ($text !== '' && in_array($text[0], ['=', '+', '-', '@'], true)) {
        $ws->getStyle($coord)->setQuotePrefix(true);
    }
}

function rpt_set_cell($ws, array $coord, $v, string $type): void
{
    if ($v === null || $v === '') {
        return;
    }
    switch ($type) {
        case 'int': case 'dec': case 'pct':
            $ws->setCellValueExplicit($coord, (float) $v, DataType::TYPE_NUMERIC);
            break;
        case 'date':
            $ws->setCellValueExplicit($coord, XlDate::PHPToExcel(new DateTime((string) $v)), DataType::TYPE_NUMERIC);
            break;
        case 'datetime':
            $ws->setCellValueExplicit($coord, XlDate::PHPToExcel(new DateTime((string) $v)), DataType::TYPE_NUMERIC);
            break;
        case 'month':
            $ws->setCellValueExplicit($coord, XlDate::PHPToExcel(new DateTime($v . '-01')), DataType::TYPE_NUMERIC);
            break;
        default:
            $text = (string) $v;
            $ws->setCellValueExplicit($coord, $text, DataType::TYPE_STRING);
            if (in_array($text[0], ['=', '+', '-', '@'], true)) {
                $ws->getCell($coord)->getStyle()->setQuotePrefix(true);
            }
    }
}

function rpt_prepare(): void
{
    @ini_set('memory_limit', '512M');
    @set_time_limit(180);
}

/* ====================================================================== PDF */
function rpt_render_pdf(array $ds, array $meta): void
{
    rpt_prepare();
    $cacheDir = BASE_PATH . '/storage/cache';
    foreach (['', '/fonts', '/tmp'] as $sub) {
        if (!is_dir($cacheDir . $sub)) {
            mkdir($cacheDir . $sub, 0750, true);
        }
    }
    $o = new \Dompdf\Options();
    $o->set('defaultFont', 'DejaVu Sans');
    $o->set('isRemoteEnabled', false);
    $o->set('isPhpEnabled', false);
    $o->set('chroot', BASE_PATH);
    $o->set('fontCache', $cacheDir . '/fonts');
    $o->set('tempDir', $cacheDir . '/tmp');

    $landscape = count($ds['columns']) > 6;
    $dompdf = new \Dompdf\Dompdf($o);
    $dompdf->setPaper('A4', $landscape ? 'landscape' : 'portrait');
    $dompdf->loadHtml(rpt_pdf_html($ds, $meta));
    $dompdf->render();

    $canvas = $dompdf->getCanvas();
    $font = $dompdf->getFontMetrics()->getFont('DejaVu Sans');
    $w = $canvas->get_width();
    $h = $canvas->get_height();
    $canvas->page_text(36, $h - 28, $ds['title'] . ' · ' . $ds['period_label'], $font, 7.5, [0.4, 0.45, 0.55]);
    $canvas->page_text($w - 120, $h - 28, 'Halaman {PAGE_NUM} dari {PAGE_COUNT}', $font, 7.5, [0.4, 0.45, 0.55]);

    audit_log('export', 'report', null, sprintf('Ekspor PDF %s (%d baris) — %s; %s', $ds['title'], count($ds['rows']), $ds['period_label'], rpt_filter_text($ds)), $meta['user_id']);

    $fn = rpt_filename($ds, 'pdf');
    header('Content-Type: application/pdf');
    header('Content-Disposition: attachment; filename="' . $fn . '"');
    header('Cache-Control: no-store');
    echo $dompdf->output();
    exit;
}

/** Jumlah kolom yang dipakai label baris total (kolom pertama + sel kosong berurutan sesudahnya). */
function rpt_total_span(array $total): int
{
    $n = 1;
    while (array_key_exists($n, $total) && $total[$n] === null) {
        $n++;
    }
    return $n;
}

function rpt_pdf_html(array $ds, array $meta): string
{
    $numTypes = ['int', 'dec', 'pct'];
    $h = '<!DOCTYPE html><html><head><meta charset="UTF-8"><style>
        @page { margin: 32px 36px 44px 36px; }
        body { font-family: "DejaVu Sans", sans-serif; font-size: 8.5px; color: #172033; }
        h1 { font-size: 16px; margin: 0 0 2px; color: #0B132B; } .sub { color: #64748B; font-size: 9px; margin: 0 0 10px; }
        .bar { height: 3px; background: #0B132B; margin-bottom: 10px; } .bar i { display: block; width: 60px; height: 3px; background: #D71920; }
        table { border-collapse: collapse; width: 100%; }
        .meta td { padding: 2px 6px 2px 0; vertical-align: top; font-size: 8.5px; } .meta td:first-child { width: 80px; font-weight: bold; color: #475569; }
        .summary { margin: 8px 0 10px; width: auto; } .summary td { background: #F1F5F9; padding: 3px 10px; border-bottom: 1px solid #FFFFFF; } .summary td:first-child { color: #475569; } .summary td:last-child { font-weight: bold; }
        .data th { background: #0B132B; color: #FFFFFF; padding: 5px 5px; text-align: left; font-size: 8px; } .data thead { display: table-header-group; }
        .data td { padding: 3.5px 5px; border-bottom: 1px solid #E2E8F0; vertical-align: top; } .data tr:nth-child(even) td { background: #FAFBFD; }
        .data tr { page-break-inside: avoid; } .r { text-align: right; } .total td { background: #E8EEF9; font-weight: bold; border-top: 1.5px solid #0B132B; }
        .note { margin-top: 10px; color: #64748B; font-size: 8px; } .warn { color: #92400E; }
    </style></head><body>';
    $h .= '<h1>' . e($ds['title']) . '</h1><p class="sub">' . e($ds['desc']) . '</p><div class="bar"><i></i></div>';
    $h .= '<table class="meta">';
    foreach (rpt_header_lines($ds, $meta) as [$l, $v]) {
        $h .= '<tr><td>' . e($l) . '</td><td>' . e($v) . '</td></tr>';
    }
    $h .= '</table>';
    if ($ds['summary']) {
        $h .= '<table class="summary">';
        foreach ($ds['summary'] as [$l, $v]) {
            $h .= '<tr><td>' . e($l) . '</td><td>' . e($v) . '</td></tr>';
        }
        $h .= '</table>';
    }
    $h .= '<table class="data"><thead><tr>';
    $total = array_sum(array_column($ds['columns'], 'w')) ?: 1;
    foreach ($ds['columns'] as $c) {
        $h .= '<th style="width:' . round($c['w'] / $total * 100, 1) . '%"' . (in_array($c['type'], $numTypes, true) ? ' class="r"' : '') . '>' . e($c['label']) . '</th>';
    }
    $h .= '</tr></thead><tbody>';
    if (!$ds['rows']) {
        $h .= '<tr><td colspan="' . count($ds['columns']) . '" style="text-align:center;color:#64748B;padding:14px">Tidak ada data untuk periode dan filter ini.</td></tr>';
    }
    foreach ($ds['rows'] as $row) {
        $h .= '<tr>';
        foreach ($ds['columns'] as $i => $c) {
            $h .= '<td' . (in_array($c['type'], $numTypes, true) ? ' class="r"' : '') . '>' . e(rpt_fmt($row[$i] ?? null, $c['type'])) . '</td>';
        }
        $h .= '</tr>';
    }
    if ($ds['total'] !== null) {
        $h .= '<tr class="total">';
        $span = rpt_total_span($ds['total']);
        $h .= '<td colspan="' . $span . '">' . e((string) $ds['total'][0]) . '</td>';
        for ($i = $span; $i < count($ds['columns']); $i++) {
            $v = $ds['total'][$i] ?? null;
            $h .= '<td' . (in_array($ds['columns'][$i]['type'], $numTypes, true) ? ' class="r"' : '') . '>' . ($v === null ? '' : e(rpt_fmt($v, $ds['columns'][$i]['type']))) . '</td>';
        }
        $h .= '</tr>';
    }
    $h .= '</tbody></table>';
    foreach ($ds['notes'] as $n) {
        $h .= '<p class="note">Catatan: ' . e($n) . '</p>';
    }
    if ($ds['truncated']) {
        $h .= '<p class="note warn">Tabel memuat ' . e(format_number(count($ds['rows']), 0)) . ' dari ' . e(format_number($ds['row_count'], 0)) . ' baris (dibatasi untuk PDF). Gunakan ekspor Excel untuk data lengkap. Total di atas dihitung dari seluruh data.</p>';
    }
    return $h . '</body></html>';
}
