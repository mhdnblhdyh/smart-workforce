<?php
/**
 * Report Center — definisi laporan dan pembangun dataset.
 *
 * Satu fungsi rpt_dataset() menjadi SATU-SATUNYA sumber data untuk preview, Excel, dan PDF, sehingga ketiganya
 * selalu memakai filter dan angka yang sama. Total/ringkasan dihitung di MySQL pada kondisi yang sama dengan baris
 * (bukan dari baris yang tampil), sehingga tetap konsisten walau baris dibatasi pada preview.
 *
 * DEFINISI angka sama dengan Dashboard/Analytics: "aktif pada bulan M" berbasis tanggal mulai/berakhir; mandays = SUM(mandays).
 */
declare(strict_types=1);

require_once dirname(__DIR__) . '/dashboard/queries.php';     // dash_vendor_summary, dash_headcount
require_once dirname(__DIR__) . '/data-quality/queries.php';   // dq_* (Laporan Data Quality)
require_once dirname(__DIR__) . '/imports/schema.php';         // IMPORT_TYPES, IMPORT_STATUS_LABELS
require_once dirname(__DIR__) . '/employees/repo.php';         // EMP_CATEGORIES, EMP_STATUSES

const RPT_PREVIEW_ROWS = 100;
const RPT_XLSX_ROW_CAP = 20000;
const RPT_PDF_ROW_CAP  = 1500;

const RPT = [
    'workforce'      => ['slug' => 'tenaga-kerja', 'icon' => 'users',          'title' => 'Laporan Tenaga Kerja per Periode', 'desc' => 'Daftar tenaga kerja aktif pada satu bulan, lengkap dengan departemen, vendor, dan mandays bulan itu.', 'params' => ['period', 'dept', 'vendor', 'category', 'status']],
    'tad_vendor'     => ['slug' => 'tad-vendor',   'icon' => 'handshake',      'title' => 'Laporan TAD per Vendor',           'desc' => 'Jumlah TAD aktif, mandays, dan masa kontrak untuk setiap vendor pada satu bulan.', 'params' => ['period', 'dept']],
    'department'     => ['slug' => 'departemen',   'icon' => 'building-2',     'title' => 'Laporan per Departemen',           'desc' => 'Tenaga kerja aktif per kategori, mandays, dan kelengkapan data untuk setiap departemen.', 'params' => ['period']],
    'mandays'        => ['slug' => 'mandays',      'icon' => 'calendar-check', 'title' => 'Laporan Mandays',                  'desc' => 'Rincian mandays dan kehadiran per tenaga kerja untuk rentang bulan, dengan subtotal per bulan.', 'params' => ['from', 'to', 'dept', 'vendor', 'category']],
    'data_quality'   => ['slug' => 'data-quality', 'icon' => 'shield-check',   'title' => 'Laporan Data Quality',             'desc' => 'Temuan kualitas data pada bulan acuan beserta saran perbaikan.', 'params' => ['period', 'level']],
    'import_history' => ['slug' => 'riwayat-import', 'icon' => 'history',      'title' => 'Laporan Riwayat Import',           'desc' => 'Daftar proses import pada rentang waktu: file, pengguna, jumlah baris, dan hasilnya.', 'params' => ['from', 'to', 'bstatus', 'btype']],
];

/** Parse filter laporan dari query string (nilai tidak valid diganti default/diabaikan). */
function rpt_parse(string $key): array
{
    $g = fn (string $k): string => (isset($_GET[$k]) && is_string($_GET[$k])) ? trim($_GET[$k]) : '';
    $params = RPT[$key]['params'];
    $f = ['report' => $key, 'notices' => []];

    if (in_array('period', $params, true)) {
        $f['period'] = stats_parse_month($g('period')) ?? stats_latest_month();
    }
    if (in_array('from', $params, true)) {
        $default = $key === 'import_history' ? date('Y-m') : stats_latest_month();
        $to   = stats_parse_month($g('to')) ?? $default;
        $from = stats_parse_month($g('from')) ?? stats_shift_month($to, -(STATS_DEFAULT_MONTHS - 1));
        if ($from > $to) {
            [$from, $to] = [$to, $from];
            $f['notices'][] = 'Periode awal lebih besar dari periode akhir, rentang dibalik otomatis.';
        }
        if (stats_month_diff($from, $to) + 1 > STATS_MAX_MONTHS) {
            $from = stats_shift_month($to, -(STATS_MAX_MONTHS - 1));
            $f['notices'][] = 'Rentang dibatasi maksimum ' . STATS_MAX_MONTHS . ' bulan; periode awal disesuaikan.';
        }
        $f['from'] = $from;
        $f['to']   = $to;
    }
    $f['dept']     = (in_array('dept', $params, true) && ctype_digit($g('dept'))) ? (int) $g('dept') : 0;
    $f['vendor']   = (in_array('vendor', $params, true) && ctype_digit($g('vendor'))) ? (int) $g('vendor') : 0;
    $f['category'] = (in_array('category', $params, true) && array_key_exists($g('category'), EMP_CATEGORIES)) ? $g('category') : '';
    $f['status']   = (in_array('status', $params, true) && array_key_exists($g('status'), EMP_STATUSES)) ? $g('status') : '';
    $f['level']    = (in_array('level', $params, true) && array_key_exists($g('level'), DQ_LEVELS)) ? $g('level') : '';
    $f['bstatus']  = (in_array('bstatus', $params, true) && array_key_exists($g('bstatus'), IMPORT_STATUS_LABELS)) ? $g('bstatus') : '';
    $f['btype']    = (in_array('btype', $params, true) && array_key_exists($g('btype'), IMPORT_TYPES)) ? $g('btype') : '';
    return $f;
}

/** Nilai filter dalam bentuk teks untuk header laporan. @return array<int,array{0:string,1:string}> */
function rpt_filter_lines(array $f): array
{
    $lines = [];
    if ($f['dept'] > 0)       { $lines[] = ['Departemen', (string) db_value('SELECT name FROM departments WHERE id = ?', 'i', [$f['dept']])]; }
    if ($f['vendor'] > 0)     { $lines[] = ['Vendor', (string) db_value('SELECT name FROM vendors WHERE id = ?', 'i', [$f['vendor']])]; }
    if ($f['category'] !== '') { $lines[] = ['Kategori', EMP_CATEGORIES[$f['category']]]; }
    if ($f['status'] !== '')   { $lines[] = ['Status tenaga kerja', EMP_STATUSES[$f['status']]]; }
    if ($f['level'] !== '')    { $lines[] = ['Tingkat temuan', DQ_LEVELS[$f['level']]]; }
    if ($f['bstatus'] !== '')  { $lines[] = ['Status import', IMPORT_STATUS_LABELS[$f['bstatus']]]; }
    if ($f['btype'] !== '')    { $lines[] = ['Jenis import', IMPORT_TYPES[$f['btype']]]; }
    return $lines;
}

/** Format nilai sel untuk tampilan (preview HTML & PDF). */
function rpt_fmt($v, string $type): string
{
    if ($v === null || $v === '') {
        return '-';
    }
    return match ($type) {
        'int'   => format_number($v, 0),
        'dec'   => format_number($v, 2),
        'pct'   => number_format((float) $v, 1, ',', '.') . '%',
        'date'  => date('d-m-Y', strtotime((string) $v)),
        'month' => month_label((string) $v),
        'datetime' => format_datetime((string) $v),
        default => (string) $v,
    };
}

/** Rangka dataset. */
function rpt_base(string $key, array $f, string $periodLabel, string $source): array
{
    return [
        'key' => $key, 'title' => RPT[$key]['title'], 'desc' => RPT[$key]['desc'], 'slug' => RPT[$key]['slug'],
        'period_label' => $periodLabel, 'period_key' => $f['period'] ?? (($f['from'] ?? '') . '_' . ($f['to'] ?? '')),
        'filters' => rpt_filter_lines($f), 'source' => $source, 'columns' => [], 'rows' => [], 'total' => null, 'summary' => [],
        'row_count' => 0, 'truncated' => false, 'notes' => [],
    ];
}

function rpt_range_label(array $f): string
{
    return month_label($f['from']) . ($f['from'] === $f['to'] ? '' : ' – ' . month_label($f['to']));
}

/** Bangun dataset laporan. $limit = jumlah baris maksimum yang dimuat (total/ringkasan tetap dari seluruh data). */
function rpt_dataset(string $key, array $f, int $limit): array
{
    return match ($key) {
        'workforce'      => rpt_ds_workforce($f, $limit),
        'tad_vendor'     => rpt_ds_tad_vendor($f),
        'department'     => rpt_ds_department($f),
        'mandays'        => rpt_ds_mandays($f, $limit),
        'data_quality'   => rpt_ds_data_quality($f, $limit),
        'import_history' => rpt_ds_import_history($f, $limit),
        default          => throw new InvalidArgumentException('Laporan tidak dikenal.'),
    };
}

/* ---------------------------------------------------------------- 1. Tenaga kerja per periode */
function rpt_ds_workforce(array $f, int $limit): array
{
    $ym = $f['period'];
    $ms = $ym . '-01';
    [$cond, $ct, $cp] = stats_emp_cond($f);
    $from  = 'FROM employees e JOIN departments d ON d.id = e.department_id LEFT JOIN vendors v ON v.id = e.vendor_id';
    $where = 'WHERE ' . SQL_ACTIVE_IN_MONTH . $cond;
    $wt = 'ss' . $ct;
    $wp = array_merge([$ms, $ms], $cp);

    $agg = db_fetch_one(
        "SELECT COUNT(*) AS total, COALESCE(SUM(e.category='employee'),0) AS emp, COALESCE(SUM(e.category='tad'),0) AS tad, COALESCE(SUM(e.category='intern'),0) AS intern,
                COALESCE(SUM(m.mandays),0) AS mandays, COALESCE(SUM(m.mandays IS NULL),0) AS no_md
         {$from} LEFT JOIN workforce_records m ON m.employee_id = e.id AND m.period_month = ? {$where}",
        's' . $wt,
        array_merge([$ms], $wp)
    );
    $rows = db_fetch_all(
        "SELECT e.employee_code, e.full_name, e.category, d.name AS dept, v.name AS vendor, e.position, e.start_date, e.end_date, e.status, m.mandays
         {$from} LEFT JOIN workforce_records m ON m.employee_id = e.id AND m.period_month = ? {$where}
         ORDER BY d.name ASC, e.employee_code ASC LIMIT ?",
        's' . $wt . 'i',
        array_merge([$ms], $wp, [$limit])
    );

    $ds = rpt_base('workforce', $f, month_label($ym), 'Tabel employees, departments, vendors, workforce_records');
    $ds['columns'] = [
        ['label' => 'ID Internal', 'type' => 'text', 'w' => 14], ['label' => 'Nama', 'type' => 'text', 'w' => 28], ['label' => 'Kategori', 'type' => 'text', 'w' => 16],
        ['label' => 'Departemen', 'type' => 'text', 'w' => 24], ['label' => 'Vendor', 'type' => 'text', 'w' => 26], ['label' => 'Jabatan', 'type' => 'text', 'w' => 20],
        ['label' => 'Mulai', 'type' => 'date', 'w' => 12], ['label' => 'Berakhir', 'type' => 'date', 'w' => 12], ['label' => 'Status', 'type' => 'text', 'w' => 12], ['label' => 'Mandays', 'type' => 'dec', 'w' => 10],
    ];
    foreach ($rows as $r) {
        $ds['rows'][] = [$r['employee_code'], $r['full_name'], EMP_CATEGORIES[$r['category']] ?? $r['category'], $r['dept'], $r['vendor'], $r['position'], $r['start_date'], $r['end_date'], EMP_STATUSES[$r['status']] ?? $r['status'], $r['mandays'] === null ? null : (float) $r['mandays']];
    }
    $ds['row_count'] = (int) $agg['total'];
    $ds['truncated'] = $ds['row_count'] > count($ds['rows']);
    $ds['total'] = ['Total ' . format_number($agg['total'], 0) . ' tenaga kerja', null, null, null, null, null, null, null, null, (float) $agg['mandays']];
    $ds['summary'] = [
        ['Tenaga kerja aktif', format_number($agg['total'], 0)], ['Karyawan', format_number($agg['emp'], 0)], ['TAD', format_number($agg['tad'], 0)], ['Peserta magang', format_number($agg['intern'], 0)],
        ['Total mandays', format_number($agg['mandays'], 2) . ' hari'], ['Tanpa record mandays', format_number($agg['no_md'], 0)],
    ];
    $ds['notes'][] = 'Aktif = tanggal mulai ≤ akhir bulan dan (tanggal berakhir kosong atau ≥ awal bulan). Mandays kosong (-) berarti belum ada record pada bulan tersebut.';
    return $ds;
}

/* ---------------------------------------------------------------- 2. TAD per vendor */
function rpt_ds_tad_vendor(array $f): array
{
    $ym = $f['period'];
    $ms = $ym . '-01';
    $dept = $f['dept'] > 0 ? $f['dept'] : null;
    $vendors = dash_vendor_summary($ms, $dept);            // fungsi yang sama dengan tabel di Dashboard
    $head = dash_headcount($ms, $dept);
    $ds = rpt_base('tad_vendor', $f, month_label($ym), 'Tabel vendors, employees, workforce_records');
    $ds['columns'] = [
        ['label' => 'Kode', 'type' => 'text', 'w' => 12], ['label' => 'Vendor', 'type' => 'text', 'w' => 32], ['label' => 'Status vendor', 'type' => 'text', 'w' => 14],
        ['label' => 'Kontrak berakhir', 'type' => 'text', 'w' => 16], ['label' => 'Status kontrak', 'type' => 'text', 'w' => 18], ['label' => 'TAD aktif', 'type' => 'int', 'w' => 10], ['label' => 'Mandays', 'type' => 'dec', 'w' => 12],
    ];
    $stateLabel = ['none' => '-', 'ok' => 'Berjalan', 'warning' => 'Segera berakhir', 'expired' => 'Sudah berakhir'];
    $sumW = 0; $sumM = 0.0;
    foreach ($vendors as $v) {
        $ds['rows'][] = [$v['code'], $v['name'], ACTIVE_STATUSES[$v['status']] ?? $v['status'], $v['contract_end'], $stateLabel[$v['contract']] ?? '-', $v['workers'], $v['mandays']];
        $sumW += $v['workers'];
        $sumM += $v['mandays'];
    }
    $ds['row_count'] = count($ds['rows']);
    $ds['total'] = ['Total', null, null, null, null, $sumW, $sumM];
    $ds['summary'] = [
        ['TAD aktif (Dashboard)', format_number($head['tad'], 0)], ['TAD pada tabel (bervendor)', format_number($sumW, 0)],
        ['TAD tanpa vendor', format_number($head['tad'] - $sumW, 0)], ['Mandays TAD bervendor', format_number($sumM, 2) . ' hari'],
    ];
    $ds['notes'][] = 'Selisih "TAD tanpa vendor" menunjukkan data yang perlu dilengkapi (lihat Data Quality). Total TAD sama dengan KPI Dashboard untuk filter yang sama.';
    return $ds;
}

/* ---------------------------------------------------------------- 3. Per departemen */
function rpt_ds_department(array $f): array
{
    $ym = $f['period'];
    $ms = $ym . '-01';
    $rows = db_fetch_all(
        "SELECT d.code, d.name,
                COUNT(e.id) AS total,
                COALESCE(SUM(e.category = 'employee'), 0) AS emp, COALESCE(SUM(e.category = 'tad'), 0) AS tad, COALESCE(SUM(e.category = 'intern'), 0) AS intern,
                COALESCE(SUM(
                    e.position IS NOT NULL AND e.position <> '' AND (e.category <> 'tad' OR e.vendor_id IS NOT NULL) AND (e.category <> 'intern' OR e.end_date IS NOT NULL)
                    AND EXISTS (SELECT 1 FROM workforce_records r WHERE r.employee_id = e.id AND r.period_month = ?)
                ), 0) AS complete,
                (SELECT COALESCE(SUM(r2.mandays), 0) FROM workforce_records r2 JOIN employees e2 ON e2.id = r2.employee_id WHERE e2.department_id = d.id AND r2.period_month = ?) AS mandays
         FROM departments d
         LEFT JOIN employees e ON e.department_id = d.id AND " . SQL_ACTIVE_IN_MONTH . "
         WHERE d.status = 'active' OR e.id IS NOT NULL
         GROUP BY d.id, d.code, d.name ORDER BY d.name ASC",
        'ssss',
        [$ms, $ms, $ms, $ms]
    );
    $ds = rpt_base('department', $f, month_label($ym), 'Tabel departments, employees, workforce_records');
    $ds['columns'] = [
        ['label' => 'Kode', 'type' => 'text', 'w' => 10], ['label' => 'Departemen', 'type' => 'text', 'w' => 30], ['label' => 'Karyawan', 'type' => 'int', 'w' => 11], ['label' => 'TAD', 'type' => 'int', 'w' => 9],
        ['label' => 'Peserta magang', 'type' => 'int', 'w' => 15], ['label' => 'Total aktif', 'type' => 'int', 'w' => 12], ['label' => 'Mandays', 'type' => 'dec', 'w' => 12], ['label' => 'Kelengkapan data', 'type' => 'pct', 'w' => 16],
    ];
    $t = ['emp' => 0, 'tad' => 0, 'intern' => 0, 'total' => 0, 'complete' => 0, 'mandays' => 0.0];
    foreach ($rows as $r) {
        $ds['rows'][] = [$r['code'], $r['name'], (int) $r['emp'], (int) $r['tad'], (int) $r['intern'], (int) $r['total'], (float) $r['mandays'], $r['total'] > 0 ? round($r['complete'] / $r['total'] * 100, 1) : null];
        foreach ($t as $k => $_) { $t[$k] += $r[$k]; }
    }
    $ds['row_count'] = count($ds['rows']);
    $overall = $t['total'] > 0 ? round($t['complete'] / $t['total'] * 100, 1) : null;
    $ds['total'] = ['Total', null, $t['emp'], $t['tad'], $t['intern'], $t['total'], $t['mandays'], $overall];
    $ds['summary'] = [['Tenaga kerja aktif', format_number($t['total'], 0)], ['Total mandays', format_number($t['mandays'], 2) . ' hari'], ['Kelengkapan data keseluruhan', $overall === null ? '-' : number_format($overall, 1, ',', '.') . '%']];
    $ds['notes'][] = 'Kelengkapan = tenaga kerja aktif dengan jabatan terisi, TAD punya vendor, magang punya tanggal berakhir, dan punya record mandays pada bulan tersebut.';
    return $ds;
}

/* ---------------------------------------------------------------- 4. Mandays */
function rpt_ds_mandays(array $f, int $limit): array
{
    $f['status'] = '';
    [$cond, $ct, $cp] = stats_emp_cond($f);
    $from  = 'FROM workforce_records r JOIN employees e ON e.id = r.employee_id JOIN departments d ON d.id = e.department_id LEFT JOIN vendors v ON v.id = e.vendor_id';
    $where = "WHERE r.period_month BETWEEN ? AND ?{$cond}";
    $wt = 'ss' . $ct;
    $wp = array_merge([$f['from'] . '-01', $f['to'] . '-01'], $cp);

    $months = stats_months($f['from'], $f['to']);
    $series = stats_mandays_series($months, $f);
    $tot    = stats_mandays_totals($f['from'], $f['to'], $f);
    $rows = db_fetch_all(
        "SELECT DATE_FORMAT(r.period_month, '%Y-%m') AS ym, e.employee_code, e.full_name, e.category, d.name AS dept, v.name AS vendor, r.mandays, r.scheduled_days, r.attended_days, r.source
         {$from} {$where} ORDER BY r.period_month ASC, d.name ASC, e.employee_code ASC LIMIT ?",
        $wt . 'i',
        array_merge($wp, [$limit])
    );

    $ds = rpt_base('mandays', $f, rpt_range_label($f), 'Tabel workforce_records, employees, departments, vendors');
    $ds['columns'] = [
        ['label' => 'Periode', 'type' => 'month', 'w' => 12], ['label' => 'ID Internal', 'type' => 'text', 'w' => 14], ['label' => 'Nama', 'type' => 'text', 'w' => 28], ['label' => 'Kategori', 'type' => 'text', 'w' => 16],
        ['label' => 'Departemen', 'type' => 'text', 'w' => 24], ['label' => 'Vendor', 'type' => 'text', 'w' => 26], ['label' => 'Mandays', 'type' => 'dec', 'w' => 10],
        ['label' => 'Hari terjadwal', 'type' => 'dec', 'w' => 14], ['label' => 'Hari hadir', 'type' => 'dec', 'w' => 11], ['label' => 'Sumber', 'type' => 'text', 'w' => 10],
    ];
    foreach ($rows as $r) {
        $ds['rows'][] = [$r['ym'], $r['employee_code'], $r['full_name'], EMP_CATEGORIES[$r['category']] ?? $r['category'], $r['dept'], $r['vendor'], (float) $r['mandays'],
            $r['scheduled_days'] === null ? null : (float) $r['scheduled_days'], $r['attended_days'] === null ? null : (float) $r['attended_days'], $r['source'] === 'import' ? 'Import' : 'Manual'];
    }
    $ds['row_count'] = $tot['records'];
    $ds['truncated'] = $tot['records'] > count($ds['rows']);
    $ds['total'] = ['Total ' . format_number($tot['records'], 0) . ' record', null, null, null, null, null, $tot['mandays'], null, null, null];
    foreach ($months as $m) {                                      // subtotal per bulan (konsisten dengan Dashboard/Analytics)
        $ds['summary'][] = ['Subtotal ' . month_label($m), format_number($series[$m]['mandays'], 2) . ' hari · ' . format_number($series[$m]['records'], 0) . ' record'];
    }
    $ds['summary'][] = ['TOTAL ' . rpt_range_label($f), format_number($tot['mandays'], 2) . ' hari · ' . format_number($tot['records'], 0) . ' record · ' . format_number($tot['workers'], 0) . ' tenaga kerja'];
    $ds['notes'][] = 'Satu record = satu tenaga kerja pada satu bulan. Kolom hari terjadwal/hadir kosong (-) berarti data kehadiran tidak tersedia; tidak diisi dengan perkiraan.';
    return $ds;
}

/* ---------------------------------------------------------------- 5. Data quality */
function rpt_ds_data_quality(array $f, int $limit): array
{
    $ym = $f['period'];
    $defs = dq_definitions($ym, date('Y-m-d'));
    $counts = dq_counts($defs);
    $series = stats_workforce_series([$ym], [])[$ym];
    $score = $series['total'] > 0 ? round($series['complete'] / $series['total'] * 100, 1) : null;
    $issues = dq_issues($defs, '', $f['level'], $limit, 0);
    $totalIssues = dq_issue_count($defs, '', $f['level']);

    $ds = rpt_base('data_quality', $f, month_label($ym), 'Pemeriksaan atas tabel employees, workforce_records, vendors, departments');
    $ds['columns'] = [
        ['label' => 'Kelompok', 'type' => 'text', 'w' => 14], ['label' => 'Tingkat', 'type' => 'text', 'w' => 16], ['label' => 'Temuan', 'type' => 'text', 'w' => 40], ['label' => 'ID Internal', 'type' => 'text', 'w' => 14],
        ['label' => 'Nama', 'type' => 'text', 'w' => 26], ['label' => 'Periode', 'type' => 'text', 'w' => 10], ['label' => 'Detail', 'type' => 'text', 'w' => 44], ['label' => 'Saran perbaikan', 'type' => 'text', 'w' => 48],
    ];
    foreach ($issues as $i) {
        $d = $defs[$i['check_key']];
        $ds['rows'][] = [$d['group'], DQ_LEVELS[$d['level']], $d['label'], $i['code'], $i['name'], $i['period'] !== '' ? $i['period'] : null, $i['detail'], $d['hint']];
    }
    $ds['row_count'] = $totalIssues;
    $ds['truncated'] = $totalIssues > count($ds['rows']);
    $byLevel = ['error' => 0, 'review' => 0, 'info' => 0];
    foreach ($defs as $k => $d) { $byLevel[$d['level']] += $counts[$k]; }
    $ds['total'] = ['Total ' . format_number($totalIssues, 0) . ' temuan', null, null, null, null, null, null, null];
    $ds['summary'] = [
        ['Skor kelengkapan data', $score === null ? '-' : number_format($score, 1, ',', '.') . '% (' . $series['complete'] . ' dari ' . $series['total'] . ' tenaga kerja)'],
        [DQ_LEVELS['error'], format_number($byLevel['error'], 0) . ' temuan'], [DQ_LEVELS['review'], format_number($byLevel['review'], 0) . ' temuan'], [DQ_LEVELS['info'], format_number($byLevel['info'], 0) . ' temuan'],
    ];
    $ds['notes'][] = 'Aplikasi hanya melaporkan temuan dan tidak mengubah data. "Perlu ditinjau" berarti anomali yang belum tentu salah.';
    return $ds;
}

/* ---------------------------------------------------------------- 6. Riwayat import */
function rpt_ds_import_history(array $f, int $limit): array
{
    $w = ['b.created_at >= ?', 'b.created_at <= ?']; $t = 'ss';
    $p = [$f['from'] . '-01 00:00:00', date('Y-m-t', strtotime($f['to'] . '-01')) . ' 23:59:59'];
    if ($f['bstatus'] !== '') { $w[] = 'b.status = ?'; $t .= 's'; $p[] = $f['bstatus']; }
    if ($f['btype'] !== '')   { $w[] = 'b.import_type = ?'; $t .= 's'; $p[] = $f['btype']; }
    $where = 'WHERE ' . implode(' AND ', $w);

    $agg = db_fetch_one("SELECT COUNT(*) n, COALESCE(SUM(total_rows),0) tr, COALESCE(SUM(valid_rows),0) vr, COALESCE(SUM(duplicate_rows),0) dr, COALESCE(SUM(invalid_rows),0) ir, COALESCE(SUM(imported_rows),0) imp,
                                COALESCE(SUM(status='completed'),0) ok, COALESCE(SUM(status='failed'),0) bad, COALESCE(SUM(status='cancelled'),0) cx FROM import_batches b {$where}", $t, $p);
    $rows = db_fetch_all("SELECT b.*, u.name AS user_name FROM import_batches b LEFT JOIN users u ON u.id = b.imported_by {$where} ORDER BY b.id DESC LIMIT ?", $t . 'i', array_merge($p, [$limit]));

    $ds = rpt_base('import_history', $f, rpt_range_label($f), 'Tabel import_batches, users');
    $ds['columns'] = [
        ['label' => 'Batch', 'type' => 'int', 'w' => 8], ['label' => 'Waktu', 'type' => 'datetime', 'w' => 18], ['label' => 'File', 'type' => 'text', 'w' => 30], ['label' => 'Jenis', 'type' => 'text', 'w' => 20], ['label' => 'Pengguna', 'type' => 'text', 'w' => 22],
        ['label' => 'Baris', 'type' => 'int', 'w' => 9], ['label' => 'Valid', 'type' => 'int', 'w' => 9], ['label' => 'Duplikat', 'type' => 'int', 'w' => 10], ['label' => 'Tidak valid', 'type' => 'int', 'w' => 12],
        ['label' => 'Diimpor', 'type' => 'int', 'w' => 10], ['label' => 'Status', 'type' => 'text', 'w' => 20], ['label' => 'Kebijakan duplikat', 'type' => 'text', 'w' => 18],
    ];
    foreach ($rows as $b) {
        $ds['rows'][] = [(int) $b['id'], $b['completed_at'] ?? $b['created_at'], $b['original_name'], IMPORT_TYPES[$b['import_type']] ?? $b['import_type'], $b['user_name'], (int) $b['total_rows'], (int) $b['valid_rows'],
            (int) $b['duplicate_rows'], (int) $b['invalid_rows'], (int) $b['imported_rows'], IMPORT_STATUS_LABELS[$b['status']] ?? $b['status'], $b['duplicate_policy'] === 'update' ? 'Perbarui' : 'Lewati'];
    }
    $ds['row_count'] = (int) $agg['n'];
    $ds['truncated'] = $ds['row_count'] > count($ds['rows']);
    $ds['total'] = ['Total ' . format_number($agg['n'], 0) . ' batch', null, null, null, null, (int) $agg['tr'], (int) $agg['vr'], (int) $agg['dr'], (int) $agg['ir'], (int) $agg['imp'], null, null];
    $ds['summary'] = [['Total batch', format_number($agg['n'], 0)], ['Selesai', format_number($agg['ok'], 0)], ['Gagal (rollback)', format_number($agg['bad'], 0)], ['Dibatalkan', format_number($agg['cx'], 0)], ['Total baris diimpor', format_number($agg['imp'], 0)]];
    $ds['notes'][] = 'Waktu = waktu selesai bila batch selesai, atau waktu unggah. Filter periode memakai waktu unggah.';
    return $ds;
}
