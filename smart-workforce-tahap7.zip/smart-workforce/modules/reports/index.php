<?php
declare(strict_types=1);
require_once dirname(__DIR__, 2) . '/includes/bootstrap.php';
require_once __DIR__ . '/definitions.php';
require_once __DIR__ . '/render.php';

$user      = require_permission('reports.view');
$canExport = user_can('reports.export', $user);
$path      = 'modules/reports/index.php';
$key       = (isset($_GET['report']) && is_string($_GET['report']) && isset(RPT[$_GET['report']])) ? $_GET['report'] : '';

$ds = null; $f = null; $libsOk = false; $exportQs = '';
if ($key !== '') {
    $f  = rpt_parse($key);
    $ds = rpt_dataset($key, $f, RPT_PREVIEW_ROWS);
    $libsOk = rpt_libs_ready();
    $q = ['report' => $key];
    foreach (RPT[$key]['params'] as $p) {
        $val = $f[$p] ?? '';
        if ($val !== '' && $val !== 0) { $q[$p] = $val; }
    }
    $exportQs = http_build_query($q);
}
$months = stats_available_months();
foreach ([$f['period'] ?? null, $f['from'] ?? null, $f['to'] ?? null] as $m) { if ($m && !in_array($m, $months, true)) { $months[] = $m; } }
rsort($months);

$page = ['title' => 'Report Center', 'active' => 'reports', 'breadcrumb' => ['Reporting', 'Report Center'] + ($key !== '' ? [2 => RPT[$key]['title']] : []), 'css' => ['crud.css', 'import.css'], 'js' => []];
require BASE_PATH . '/includes/header.php';
$opt = fn ($v, $cur, $label) => '<option value="' . e($v) . '"' . ((string) $v === (string) $cur ? ' selected' : '') . '>' . e($label) . '</option>';
$numTypes = ['int', 'dec', 'pct'];
?>
<section class="crud-page">
    <div class="page-header">
        <div><h1>Report Center</h1><p class="page-sub">Buat laporan, tinjau preview, lalu ekspor ke Excel atau PDF. Ekspor selalu memakai filter dan angka yang sama dengan preview.</p></div>
    </div>

    <?php if ($key === ''): ?>
        <div class="report-cards">
            <?php foreach (RPT as $k => $d): ?>
                <a class="report-card" href="<?= e(url($path . '?report=' . $k)) ?>">
                    <span class="type-icon"><?= icon($d['icon']) ?></span>
                    <strong><?= e($d['title']) ?></strong>
                    <small><?= e($d['desc']) ?></small>
                    <span class="report-open">Buka laporan <?= icon('chevron-right') ?></span>
                </a>
            <?php endforeach; ?>
        </div>
    <?php else: ?>
        <div class="chips" style="margin-bottom:16px">
            <?php foreach (RPT as $k => $d): ?><a class="chip<?= $k === $key ? ' is-active' : '' ?>" href="<?= e(url($path . '?report=' . $k)) ?>"><?= e($d['title']) ?></a><?php endforeach; ?>
        </div>

        <?php foreach ($f['notices'] as $n): ?><div class="notice notice-warning"><?= icon('info') ?><div><?= e($n) ?></div></div><?php endforeach; ?>

        <form class="card" method="get" action="<?= e(url($path)) ?>" style="padding:16px;margin-bottom:16px">
            <input type="hidden" name="report" value="<?= e($key) ?>">
            <div class="filter-row">
                <?php foreach (RPT[$key]['params'] as $p): ?>
                    <?php if ($p === 'period'): ?><label class="filter"><span>Periode (bulan)</span><select name="period" class="form-select" data-autosubmit><?php foreach ($months as $m) echo $opt($m, $f['period'], month_label($m)); ?></select></label>
                    <?php elseif ($p === 'from'): ?><label class="filter"><span>Dari bulan</span><select name="from" class="form-select" data-autosubmit><?php foreach ($months as $m) echo $opt($m, $f['from'], month_label($m)); ?></select></label>
                    <?php elseif ($p === 'to'): ?><label class="filter"><span>Sampai bulan</span><select name="to" class="form-select" data-autosubmit><?php foreach ($months as $m) echo $opt($m, $f['to'], month_label($m)); ?></select></label>
                    <?php elseif ($p === 'dept'): ?><label class="filter"><span>Departemen</span><select name="dept" class="form-select" data-autosubmit><option value="">Semua</option><?php foreach (db_fetch_all('SELECT id, name FROM departments ORDER BY name') as $x) echo $opt($x['id'], $f['dept'], $x['name']); ?></select></label>
                    <?php elseif ($p === 'vendor'): ?><label class="filter"><span>Vendor</span><select name="vendor" class="form-select" data-autosubmit><option value="">Semua</option><?php foreach (db_fetch_all('SELECT id, name FROM vendors ORDER BY name') as $x) echo $opt($x['id'], $f['vendor'], $x['name']); ?></select></label>
                    <?php elseif ($p === 'category'): ?><label class="filter"><span>Kategori</span><select name="category" class="form-select" data-autosubmit><option value="">Semua</option><?php foreach (EMP_CATEGORIES as $k => $l) echo $opt($k, $f['category'], $l); ?></select></label>
                    <?php elseif ($p === 'status'): ?><label class="filter"><span>Status tenaga kerja</span><select name="status" class="form-select" data-autosubmit><option value="">Semua</option><?php foreach (EMP_STATUSES as $k => $l) echo $opt($k, $f['status'], $l); ?></select></label>
                    <?php elseif ($p === 'level'): ?><label class="filter"><span>Tingkat temuan</span><select name="level" class="form-select" data-autosubmit><option value="">Semua</option><?php foreach (DQ_LEVELS as $k => $l) echo $opt($k, $f['level'], $l); ?></select></label>
                    <?php elseif ($p === 'bstatus'): ?><label class="filter"><span>Status import</span><select name="bstatus" class="form-select" data-autosubmit><option value="">Semua</option><?php foreach (IMPORT_STATUS_LABELS as $k => $l) echo $opt($k, $f['bstatus'], $l); ?></select></label>
                    <?php elseif ($p === 'btype'): ?><label class="filter"><span>Jenis import</span><select name="btype" class="form-select" data-autosubmit><option value="">Semua</option><?php foreach (IMPORT_TYPES as $k => $l) echo $opt($k, $f['btype'], $l); ?></select></label>
                    <?php endif; ?>
                <?php endforeach; ?>
                <noscript><button type="submit" class="btn btn-primary btn-sm">Terapkan</button></noscript>
                <a class="btn btn-outline btn-sm" href="<?= e(url($path . '?report=' . $key)) ?>"><?= icon('rotate-ccw') ?>Reset</a>
            </div>
        </form>

        <article class="card section-card report-head">
            <div>
                <h2><?= e($ds['title']) ?></h2>
                <p class="muted-note" style="margin-top:4px"><strong>Periode:</strong> <?= e($ds['period_label']) ?> · <strong>Filter:</strong> <?= e(rpt_filter_text($ds)) ?> · <strong>Sumber:</strong> <?= e($ds['source']) ?></p>
            </div>
            <div class="page-actions">
                <?php if ($canExport && $libsOk): ?>
                    <a class="btn btn-outline" href="<?= e(url('modules/reports/export.php?' . $exportQs . '&format=xlsx')) ?>"><?= icon('file-spreadsheet') ?>Excel (.xlsx)</a>
                    <a class="btn btn-primary" href="<?= e(url('modules/reports/export.php?' . $exportQs . '&format=pdf')) ?>"><?= icon('file-text') ?>PDF</a>
                <?php elseif ($canExport): ?>
                    <span class="muted-note">Ekspor memerlukan <code>composer install</code> (PhpSpreadsheet &amp; Dompdf).</span>
                <?php else: ?>
                    <span class="muted-note">Ekspor hanya untuk HC Staff dan Admin.</span>
                <?php endif; ?>
            </div>
        </article>

        <?php if ($ds['summary']): ?>
        <article class="card section-card">
            <header class="card-head"><div><h2>Ringkasan</h2><p>Dihitung dari seluruh data sesuai filter, bukan hanya baris yang tampil</p></div></header>
            <table class="summary-table"><tbody><?php foreach ($ds['summary'] as [$l, $v]): ?><tr><th><?= e($l) ?></th><td><?= e($v) ?></td></tr><?php endforeach; ?></tbody></table>
        </article>
        <?php endif; ?>

        <article class="card table-card section-card">
            <header class="card-head" style="padding:18px 22px 0"><div><h2>Preview</h2>
                <p><?= $ds['truncated'] ? 'Menampilkan ' . e(format_number(count($ds['rows']), 0)) . ' dari ' . e(format_number($ds['row_count'], 0)) . ' baris. Ekspor memuat data selengkapnya (Excel hingga ' . e(format_number(RPT_XLSX_ROW_CAP, 0)) . ' baris, PDF hingga ' . e(format_number(RPT_PDF_ROW_CAP, 0)) . ' baris).' : e(format_number(count($ds['rows']), 0)) . ' baris.' ?></p></div></header>
            <?php if (!$ds['rows']): ?>
                <?= ui_empty_state('inbox', 'Tidak ada data', 'Tidak ada data untuk periode dan filter ini. Ubah filter lalu coba lagi.') ?>
            <?php else: ?>
            <div class="table-scroll"><table class="table table-hover">
                <thead><tr><?php foreach ($ds['columns'] as $c): ?><th<?= in_array($c['type'], $numTypes, true) ? ' class="num"' : '' ?>><?= e($c['label']) ?></th><?php endforeach; ?></tr></thead>
                <tbody><?php foreach ($ds['rows'] as $row): ?><tr><?php foreach ($ds['columns'] as $i => $c): ?><td<?= in_array($c['type'], $numTypes, true) ? ' class="num"' : '' ?>><?= e(rpt_fmt($row[$i] ?? null, $c['type'])) ?></td><?php endforeach; ?></tr><?php endforeach; ?></tbody>
                <?php if ($ds['total'] !== null): ?><tfoot><tr><?php $span = rpt_total_span($ds['total']); ?><td colspan="<?= $span ?>"><?= e((string) $ds['total'][0]) ?></td><?php for ($i = $span; $i < count($ds['columns']); $i++): $v = $ds['total'][$i] ?? null; ?><td<?= in_array($ds['columns'][$i]['type'], $numTypes, true) ? ' class="num"' : '' ?>><?= $v === null ? '' : e(rpt_fmt($v, $ds['columns'][$i]['type'])) ?></td><?php endfor; ?></tr></tfoot><?php endif; ?>
            </table></div>
            <?php endif; ?>
        </article>
        <?php foreach ($ds['notes'] as $n): ?><p class="muted-note" style="margin:0 0 6px">Catatan: <?= e($n) ?></p><?php endforeach; ?>
    <?php endif; ?>
</section>
<?php require BASE_PATH . '/includes/footer.php'; ?>
