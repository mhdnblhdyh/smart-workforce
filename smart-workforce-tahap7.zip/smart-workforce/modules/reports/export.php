<?php
/** Ekspor laporan: ?report=<kunci>&format=xlsx|pdf&<filter yang sama seperti preview>. */
declare(strict_types=1);
require_once dirname(__DIR__, 2) . '/includes/bootstrap.php';
require_once __DIR__ . '/definitions.php';
require_once __DIR__ . '/render.php';

$user = require_permission('reports.export');
$key    = (isset($_GET['report']) && is_string($_GET['report']) && isset(RPT[$_GET['report']])) ? $_GET['report'] : '';
$format = (isset($_GET['format']) && is_string($_GET['format'])) ? $_GET['format'] : '';
if ($key === '' || !in_array($format, ['xlsx', 'pdf'], true)) {
    render_error_page(404);
}
if (!rpt_libs_ready()) {
    flash_set('danger', 'Ekspor memerlukan PhpSpreadsheet dan Dompdf. Jalankan "composer install" terlebih dahulu.');
    redirect('modules/reports/index.php?report=' . $key);
}

$f  = rpt_parse($key);
$ds = rpt_dataset($key, $f, $format === 'pdf' ? RPT_PDF_ROW_CAP : RPT_XLSX_ROW_CAP);
$meta = ['generated_at' => date('d-m-Y H:i'), 'user' => (string) $user['name'], 'user_id' => (int) $user['id']];

try {
    $format === 'pdf' ? rpt_render_pdf($ds, $meta) : rpt_render_xlsx($ds, $meta);
} catch (Throwable $e) {
    error_log('[REPORT] Ekspor ' . $format . ' ' . $key . ' gagal: ' . $e->getMessage() . ' @ ' . $e->getFile() . ':' . $e->getLine());
    if (!headers_sent()) {
        flash_set('danger', 'Ekspor gagal karena kesalahan di server. Coba persempit filter.');
        redirect('modules/reports/index.php?' . http_build_query(['report' => $key]));
    }
    throw $e;
}
