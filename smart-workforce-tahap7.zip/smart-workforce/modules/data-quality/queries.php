<?php
/**
 * Pemeriksaan kualitas data pada data yang SUDAH tersimpan. Aplikasi hanya MELAPORKAN; tidak pernah mengubah data otomatis.
 *
 * TINGKAT TEMUAN
 *  - error  : pasti salah atau kosong menurut aturan data (harus diperbaiki).
 *  - review : anomali yang perlu ditinjau manusia (belum tentu salah).
 *  - info   : hanya informasi.
 *
 * Skor kelengkapan = tenaga kerja aktif pada bulan acuan yang "lengkap" / seluruh tenaga kerja aktif pada bulan itu
 * (definisi sama dengan Dashboard dan Analytics). Pelanggaran ENUM, tanggal tidak valid, dan referensi departemen/vendor yang
 * tidak ada dicegah database (ENUM/FK/CHECK) sehingga dilaporkan pada validasi import, bukan pada data tersimpan.
 */
declare(strict_types=1);

const DQ_ACTIVE = '(e.start_date <= LAST_DAY(?) AND (e.end_date IS NULL OR e.end_date >= ?))';
const DQ_LEVELS = ['error' => 'Perlu diperbaiki', 'review' => 'Perlu ditinjau', 'info' => 'Informasi'];

/**
 * Definisi pemeriksaan. Setiap item: key, level, label, hint, group, sql (SELECT dengan kolom seragam), types, params.
 * Kolom seragam: check_key, sev_order, check_order, entity, entity_id, code, name, detail, period
 */
function dq_definitions(string $ym, string $today): array
{
    $ms = $ym . '-01';
    $defs = [];
    $n = 0;
    $emp = function (string $key, string $level, string $label, string $hint, string $group, string $detail, string $from, string $where, string $types = '', array $params = []) use (&$defs, &$n): void {
        $sev = ['error' => 1, 'review' => 2, 'info' => 3][$level];
        $n++;
        $defs[$key] = ['key' => $key, 'level' => $level, 'label' => $label, 'hint' => $hint, 'group' => $group, 'types' => $types, 'params' => $params,
            'sql' => "SELECT '{$key}' AS check_key, {$sev} AS sev_order, {$n} AS check_order, 'employee' AS entity, e.id AS entity_id, e.employee_code AS code, e.full_name AS name, {$detail} AS detail, '' AS period
                      FROM {$from} WHERE {$where}"];
    };
    $rec = function (string $key, string $level, string $label, string $hint, string $group, string $detail, string $where, string $types = '', array $params = []) use (&$defs, &$n): void {
        $sev = ['error' => 1, 'review' => 2, 'info' => 3][$level];
        $n++;
        $defs[$key] = ['key' => $key, 'level' => $level, 'label' => $label, 'hint' => $hint, 'group' => $group, 'types' => $types, 'params' => $params,
            'sql' => "SELECT '{$key}' AS check_key, {$sev} AS sev_order, {$n} AS check_order, 'record' AS entity, r.id AS entity_id, e.employee_code AS code, e.full_name AS name, {$detail} AS detail, DATE_FORMAT(r.period_month, '%Y-%m') AS period
                      FROM workforce_records r JOIN employees e ON e.id = r.employee_id WHERE {$where}"];
    };
    $act = ['ss', [$ms, $ms]];

    // --- Kelengkapan (dipakai skor), tenaga kerja aktif pada bulan acuan ---
    $emp('no_position', 'error', 'Jabatan belum diisi', 'Lengkapi jabatan pada data tenaga kerja.', 'Kelengkapan', "'Jabatan kosong'", 'employees e',
        DQ_ACTIVE . " AND (e.position IS NULL OR e.position = '')", ...$act);
    $emp('tad_no_vendor', 'error', 'TAD tanpa vendor', 'Pilih vendor penyedia untuk TAD tersebut.', 'Kelengkapan', "'TAD tidak memiliki vendor'", 'employees e',
        DQ_ACTIVE . " AND e.category = 'tad' AND e.vendor_id IS NULL", ...$act);
    $emp('intern_no_end', 'error', 'Peserta magang tanpa tanggal berakhir', 'Isi tanggal berakhir periode magang.', 'Kelengkapan', "'Tanggal berakhir kosong'", 'employees e',
        DQ_ACTIVE . " AND e.category = 'intern' AND e.end_date IS NULL", ...$act);
    $emp('no_mandays', 'error', 'Belum ada record mandays pada bulan acuan', 'Input atau import mandays untuk bulan ini.', 'Kelengkapan', "CONCAT('Tidak ada mandays ', DATE_FORMAT(?, '%Y-%m'))", 'employees e',
        DQ_ACTIVE . " AND NOT EXISTS (SELECT 1 FROM workforce_records r WHERE r.employee_id = e.id AND r.period_month = ?)", 'ssss', [$ms, $ms, $ms, $ms]);

    // --- Konsistensi data tenaga kerja ---
    $emp('vendor_on_non_tad', 'error', 'Vendor terisi pada non-TAD', 'Kosongkan vendor atau ubah kategori menjadi TAD.', 'Konsistensi', "'Vendor hanya berlaku untuk TAD'", 'employees e',
        "e.category <> 'tad' AND e.vendor_id IS NOT NULL");
    $emp('inactive_no_end', 'error', 'Status bukan Aktif tetapi tanggal berakhir kosong', 'Isi tanggal berakhir atau ubah status menjadi Aktif.', 'Konsistensi', "CONCAT('Status ', e.status, ' tanpa tanggal berakhir')", 'employees e',
        "e.status <> 'active' AND e.end_date IS NULL");
    $emp('active_past_end', 'review', 'Status Aktif tetapi tanggal berakhir sudah lewat', 'Tinjau: ubah status menjadi Tidak aktif/Selesai atau perpanjang tanggal berakhir.', 'Konsistensi', "CONCAT('Berakhir ', DATE_FORMAT(e.end_date, '%d-%m-%Y'), ' namun status Aktif')", 'employees e',
        "e.status = 'active' AND e.end_date < ?", 's', [$today]);
    $emp('inactive_future_end', 'review', 'Status bukan Aktif tetapi tanggal berakhir di masa depan', 'Tinjau: tanggal berakhir atau status mungkin keliru.', 'Konsistensi', "CONCAT('Status ', e.status, ' namun berakhir ', DATE_FORMAT(e.end_date, '%d-%m-%Y'))", 'employees e',
        "e.status <> 'active' AND e.end_date > ?", 's', [$today]);
    $emp('inactive_dept', 'review', 'Tenaga kerja aktif pada departemen nonaktif', 'Tinjau: aktifkan kembali departemen atau pindahkan tenaga kerja.', 'Konsistensi', "CONCAT('Departemen ', d.name, ' nonaktif')", 'employees e JOIN departments d ON d.id = e.department_id',
        "e.status = 'active' AND d.status = 'inactive'");
    $emp('tad_vendor_expired', 'review', 'TAD aktif pada vendor nonaktif / kontrak habis', 'Tinjau: perpanjang kontrak vendor atau perbarui data TAD.', 'Konsistensi', "CONCAT('Vendor ', v.name, IF(v.status = 'inactive', ' nonaktif', CONCAT(' kontrak berakhir ', DATE_FORMAT(v.contract_end, '%d-%m-%Y'))))", 'employees e JOIN vendors v ON v.id = e.vendor_id',
        DQ_ACTIVE . " AND e.category = 'tad' AND (v.status = 'inactive' OR (v.contract_end IS NOT NULL AND v.contract_end < ?))", 'sss', [$ms, $ms, $ms]);
    $emp('dup_name', 'review', 'Dugaan duplikat (nama dan departemen sama)', 'Tinjau: mungkin data ganda dengan ID berbeda. Gabungkan/hapus bila benar duplikat.', 'Duplikat', "CONCAT('Nama sama dengan tenaga kerja lain di departemen yang sama')", 'employees e',
        "(LOWER(TRIM(e.full_name)), e.department_id) IN (SELECT LOWER(TRIM(x.full_name)), x.department_id FROM employees x GROUP BY LOWER(TRIM(x.full_name)), x.department_id HAVING COUNT(*) > 1)");

    // --- Mandays ---
    $rec('record_outside_active', 'error', 'Record mandays di luar masa aktif tenaga kerja', 'Perbaiki tanggal mulai/berakhir tenaga kerja atau hapus record yang keliru.', 'Mandays',
        "CONCAT(DATE_FORMAT(r.period_month, '%Y-%m'), ' di luar masa aktif ', DATE_FORMAT(e.start_date, '%d-%m-%Y'), ' s/d ', IFNULL(DATE_FORMAT(e.end_date, '%d-%m-%Y'), 'berjalan'))",
        "(r.period_month < DATE_FORMAT(e.start_date, '%Y-%m-01') OR (e.end_date IS NOT NULL AND r.period_month > e.end_date))");
    $rec('mandays_over_schedule', 'review', 'Mandays melebihi hari kerja terjadwal', 'Tinjau: mungkin lembur/ketentuan khusus, atau salah input.', 'Mandays',
        "CONCAT(DATE_FORMAT(r.period_month, '%Y-%m'), ': mandays ', TRIM(TRAILING '.' FROM TRIM(TRAILING '0' FROM r.mandays)), ' > terjadwal ', TRIM(TRAILING '.' FROM TRIM(TRAILING '0' FROM r.scheduled_days)))",
        'r.scheduled_days IS NOT NULL AND r.mandays > r.scheduled_days');
    $rec('attendance_missing', 'info', 'Record mandays tanpa data kehadiran (bulan acuan)', 'Informasi saja. Kehadiran tidak diisi/diestimasi bila memang tidak tersedia.', 'Mandays',
        "CONCAT(DATE_FORMAT(r.period_month, '%Y-%m'), ': data kehadiran tidak tersedia')",
        'r.period_month = ? AND (r.attended_days IS NULL OR r.scheduled_days IS NULL)', 's', [$ms]);

    return $defs;
}

/** Jumlah temuan per pemeriksaan. @return array<string,int> */
function dq_counts(array $defs): array
{
    $out = [];
    foreach ($defs as $k => $d) {
        $out[$k] = (int) db_value("SELECT COUNT(*) FROM ({$d['sql']}) x", $d['types'], $d['params']);
    }
    return $out;
}

/** Gabungan SELECT untuk pemeriksaan terpilih. @return array{0:string,1:string,2:array} [sql, types, params] */
function dq_union(array $defs, string $checkKey, string $level): array
{
    $sqls = []; $types = ''; $params = [];
    foreach ($defs as $k => $d) {
        if (($checkKey !== '' && $k !== $checkKey) || ($level !== '' && $d['level'] !== $level)) {
            continue;
        }
        $sqls[] = '(' . $d['sql'] . ')';
        $types .= $d['types'];
        array_push($params, ...$d['params']);
    }
    return [implode(' UNION ALL ', $sqls), $types, $params];
}

function dq_issue_count(array $defs, string $checkKey, string $level): int
{
    [$sql, $t, $p] = dq_union($defs, $checkKey, $level);
    return $sql === '' ? 0 : (int) db_value("SELECT COUNT(*) FROM ({$sql}) u", $t, $p);
}

function dq_issues(array $defs, string $checkKey, string $level, int $limit, int $offset): array
{
    [$sql, $t, $p] = dq_union($defs, $checkKey, $level);
    if ($sql === '') {
        return [];
    }
    return db_fetch_all("SELECT * FROM ({$sql}) u ORDER BY sev_order, check_order, code, period LIMIT ? OFFSET ?", $t . 'ii', array_merge($p, [$limit, $offset]));
}

/** Tautan ke halaman untuk memperbaiki temuan. */
function dq_fix_url(array $issue): string
{
    if ($issue['entity'] === 'record') {
        return 'modules/mandays/index.php?' . http_build_query(['period' => $issue['period'], 'q' => $issue['code']]);
    }
    return 'modules/employees/index.php?' . http_build_query(['q' => $issue['code']]);
}

/** Ringkasan hasil validasi per batch impor (10 batch terakhir yang sudah divalidasi). */
function dq_import_batches(): array
{
    return db_fetch_all(
        "SELECT b.id, b.original_name, b.import_type, b.status, b.total_rows, b.valid_rows, b.duplicate_rows, b.invalid_rows, b.imported_rows, b.created_at,
                (SELECT GROUP_CONCAT(CONCAT(t.error_type, ':', t.n) ORDER BY t.n DESC SEPARATOR ',')
                   FROM (SELECT batch_id, error_type, COUNT(*) n FROM import_errors WHERE severity = 'error' GROUP BY batch_id, error_type) t WHERE t.batch_id = b.id) AS error_breakdown
         FROM import_batches b WHERE b.total_rows > 0 ORDER BY b.id DESC LIMIT 10"
    );
}
