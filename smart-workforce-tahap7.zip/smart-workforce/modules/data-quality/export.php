<?php
/** Ekspor laporan data quality (CSV) dengan filter yang sama seperti halaman. */
declare(strict_types=1);
require_once dirname(__DIR__, 2) . '/includes/bootstrap.php';
require_once __DIR__ . '/queries.php';

$user = require_permission('reports.export');
$g  = fn (string $k): string => (isset($_GET[$k]) && is_string($_GET[$k])) ? trim($_GET[$k]) : '';
$ym = stats_parse_month($g('period')) ?? stats_latest_month();
$defs  = dq_definitions($ym, date('Y-m-d'));
$check = isset($defs[$g('check')]) ? $g('check') : '';
$level = array_key_exists($g('level'), DQ_LEVELS) ? $g('level') : '';

$gen = (function () use ($defs, $check, $level): Generator {
    for ($off = 0; $off < 100000; $off += 1000) {
        $rows = dq_issues($defs, $check, $level, 1000, $off);
        if (!$rows) { return; }
        foreach ($rows as $i) {
            $d = $defs[$i['check_key']];
            yield [$d['group'], DQ_LEVELS[$d['level']], $d['label'], $i['code'], $i['name'], $i['period'], $i['detail'], $d['hint']];
        }
    }
})();

audit_log('export', 'data_quality', null, 'Ekspor laporan data quality ' . $ym . ' (' . dq_issue_count($defs, $check, $level) . ' temuan)', (int) $user['id']);
csv_download('data-quality_' . $ym . '_' . date('Ymd-His') . '.csv', ['Kelompok', 'Tingkat', 'Temuan', 'ID Internal', 'Nama', 'Periode', 'Detail', 'Saran Perbaikan'], $gen);
