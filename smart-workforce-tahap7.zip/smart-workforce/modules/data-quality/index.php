<?php
declare(strict_types=1);
require_once dirname(__DIR__, 2) . '/includes/bootstrap.php';
require_once dirname(__DIR__) . '/imports/schema.php';
require_once dirname(__DIR__) . '/imports/repo.php';
require_once __DIR__ . '/queries.php';

$user      = require_permission('dataquality.view');
$canExport = user_can('reports.export', $user);
$path      = 'modules/data-quality/index.php';

$g  = fn (string $k): string => (isset($_GET[$k]) && is_string($_GET[$k])) ? trim($_GET[$k]) : '';
$ym = stats_parse_month($g('period')) ?? stats_latest_month();
$defs   = dq_definitions($ym, date('Y-m-d'));
$check  = isset($defs[$g('check')]) ? $g('check') : '';
$level  = array_key_exists($g('level'), DQ_LEVELS) ? $g('level') : '';
$months = stats_available_months();
if (!in_array($ym, $months, true)) { $months[] = $ym; rsort($months); }

$counts = dq_counts($defs);
$series = stats_workforce_series([$ym], [])[$ym];
$score  = $series['total'] > 0 ? round($series['complete'] / $series['total'] * 100, 1) : null;
$byLevel = ['error' => 0, 'review' => 0, 'info' => 0];
foreach ($defs as $k => $d) { $byLevel[$d['level']] += $counts[$k]; }

$perPage = 25;
$total   = dq_issue_count($defs, $check, $level);
$pageNo  = list_clamp_page($total, (ctype_digit($g('page')) && $g('page') !== '') ? max(1, (int) $g('page')) : 1, $perPage);
$issues  = dq_issues($defs, $check, $level, $perPage, ($pageNo - 1) * $perPage);
$batches = dq_import_batches();
$hasFilter = $check !== '' || $level !== '';

$page = ['title' => 'Data Quality', 'active' => 'dataquality', 'breadcrumb' => ['Data Intelligence', 'Data Quality'], 'css' => ['dashboard.css', 'crud.css', 'import.css'], 'js' => []];
require BASE_PATH . '/includes/header.php';
$opt = fn ($v, $cur, $label) => '<option value="' . e($v) . '"' . ((string) $v === (string) $cur ? ' selected' : '') . '>' . e($label) . '</option>';
$scoreClass = $score === null ? '' : ($score >= 95 ? '' : ($score >= 80 ? ' is-warning' : ' is-danger'));
$levelVariant = ['error' => 'danger', 'review' => 'warning', 'info' => 'info'];
?>
<section class="crud-page">
    <div class="page-header">
        <div><h1>Data Quality</h1><p class="page-sub">Pemeriksaan kualitas data tersimpan untuk <?= e(month_label($ym)) ?>. Aplikasi hanya melaporkan temuan dan tidak mengubah data secara otomatis.</p></div>
        <div class="page-actions">
            <?php if ($canExport): ?><a class="btn btn-outline" href="<?= e(url('modules/data-quality/export.php?' . http_build_query(array_filter(['period' => $ym, 'check' => $check, 'level' => $level])))) ?>"><?= icon('download') ?>Ekspor laporan CSV</a><?php endif; ?>
        </div>
    </div>

    <form class="card toolbar" method="get" action="<?= e(url($path)) ?>">
        <label class="filter"><span>Bulan acuan</span><select name="period" class="form-select" data-autosubmit><?php foreach ($months as $m) echo $opt($m, $ym, month_label($m)); ?></select></label>
        <label class="filter"><span>Jenis temuan</span><select name="check" class="form-select" data-autosubmit><option value="">Semua pemeriksaan</option><?php foreach ($defs as $k => $d) echo $opt($k, $check, $d['label'] . ' (' . $counts[$k] . ')'); ?></select></label>
        <label class="filter"><span>Tingkat</span><select name="level" class="form-select" data-autosubmit><option value="">Semua tingkat</option><?php foreach (DQ_LEVELS as $k => $l) echo $opt($k, $level, $l . ' (' . $byLevel[$k] . ')'); ?></select></label>
        <?php if ($hasFilter || $ym !== stats_latest_month()): ?><a class="btn btn-outline btn-sm" href="<?= e(url($path)) ?>" style="align-self:flex-end"><?= icon('rotate-ccw') ?>Reset</a><?php endif; ?>
    </form>

    <div class="grid grid-1-2">
        <article class="card">
            <header class="card-head"><div><h2>Skor kelengkapan data</h2><p>Tenaga kerja aktif pada <?= e(month_label($ym)) ?> yang datanya lengkap</p></div></header>
            <?php if ($score === null): ?>
                <?= ui_empty_state('shield-check', 'Belum ada data untuk dinilai', 'Tidak ada tenaga kerja aktif pada bulan ini.') ?>
            <?php else: ?>
                <div class="q-score" style="display:flex;align-items:baseline;gap:8px;margin-bottom:8px"><strong style="font-size:34px;letter-spacing:-1px"><?= e(number_format($score, 1, ',', '.')) ?>%</strong><span style="color:var(--text-2);font-size:13px"><?= e(format_number($series['complete'], 0)) ?> dari <?= e(format_number($series['total'], 0)) ?> lengkap</span></div>
                <div class="progress<?= $scoreClass ?>" role="progressbar" aria-valuenow="<?= e($score) ?>" aria-valuemin="0" aria-valuemax="100"><i style="width:<?= e(max(0, min(100, $score))) ?>%"></i></div>
                <p class="muted-note">Lengkap = jabatan terisi, TAD punya vendor, magang punya tanggal berakhir, dan punya record mandays pada bulan acuan.</p>
            <?php endif; ?>
            <div class="mini-stats" style="grid-template-columns:repeat(3,minmax(0,1fr));margin:16px 0 0">
                <?php foreach (DQ_LEVELS as $k => $l): ?><div class="mini-stat"><span class="mini-label"><?= e($l) ?></span><strong><?= e(format_number($byLevel[$k], 0)) ?></strong><small>temuan</small></div><?php endforeach; ?>
            </div>
        </article>

        <article class="card table-card">
            <header class="card-head" style="padding:18px 22px 0"><div><h2>Ringkasan per jenis temuan</h2><p>Klik jenis temuan untuk melihat daftar record</p></div></header>
            <div class="table-scroll"><table class="table table-hover">
                <thead><tr><th>Pemeriksaan</th><th>Kelompok</th><th>Tingkat</th><th class="num">Jumlah</th></tr></thead>
                <tbody>
                <?php foreach ($defs as $k => $d): ?>
                    <tr<?= $check === $k ? ' style="background:#F2F7FF"' : '' ?>>
                        <td><a href="<?= e(list_url($path, ['check' => $k, 'page' => null])) ?>"><strong><?= e($d['label']) ?></strong></a><span class="cell-sub"><?= e($d['hint']) ?></span></td>
                        <td><?= e($d['group']) ?></td>
                        <td><?= ui_badge(DQ_LEVELS[$d['level']], $levelVariant[$d['level']]) ?></td>
                        <td class="num"><?= $counts[$k] > 0 ? '<strong>' . e(format_number($counts[$k], 0)) . '</strong>' : '<span class="muted-dash">0</span>' ?></td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table></div>
        </article>
    </div>

    <article class="card table-card section-card" style="margin-top:16px">
        <header class="card-head" style="padding:18px 22px 0"><div><h2>Record bermasalah</h2><p><?= e(format_number($total, 0)) ?> temuan<?= $hasFilter ? ' sesuai filter' : '' ?>. Gunakan tautan "Perbaiki" untuk membuka data terkait.</p></div></header>
        <?php if ($total === 0): ?>
            <?= ui_empty_state('circle-check', $hasFilter ? 'Tidak ada temuan untuk filter ini' : 'Tidak ada temuan', $hasFilter ? 'Ubah filter untuk melihat jenis temuan lain.' : 'Seluruh pemeriksaan lolos untuk bulan acuan ini.') ?>
        <?php else: ?>
        <div class="table-scroll"><table class="table table-hover">
            <thead><tr><th>Tenaga kerja</th><th>Temuan</th><th>Detail</th><th>Tingkat</th><th class="col-actions"></th></tr></thead>
            <tbody><?php foreach ($issues as $i): $d = $defs[$i['check_key']]; ?>
                <tr><td><strong><?= e($i['name']) ?></strong><span class="cell-sub"><?= e($i['code']) ?></span></td>
                    <td><?= e($d['label']) ?><span class="cell-sub">Saran: <?= e($d['hint']) ?></span></td>
                    <td><?= e($i['detail']) ?></td>
                    <td><?= ui_badge(DQ_LEVELS[$d['level']], $levelVariant[$d['level']]) ?></td>
                    <td class="col-actions"><?php if (user_can($i['entity'] === 'record' ? 'mandays.view' : 'employees.view', $user)): ?><a class="btn btn-outline btn-sm" href="<?= e(url(dq_fix_url($i))) ?>"><?= icon('pencil') ?>Perbaiki</a><?php endif; ?></td></tr>
            <?php endforeach; ?></tbody>
        </table></div>
        <?= ui_pagination($total, $pageNo, $perPage, $path) ?>
        <?php endif; ?>
    </article>

    <article class="card table-card section-card">
        <header class="card-head" style="padding:18px 22px 0"><div><h2>Hasil validasi per batch import</h2><p>10 batch terakhir. Menunjukkan kualitas file sumber sebelum data masuk ke database.</p></div></header>
        <?php if (!$batches): ?>
            <?= ui_empty_state('file-spreadsheet', 'Belum ada batch import', 'Hasil validasi akan tampil setelah ada file yang diunggah.') ?>
        <?php else: ?>
        <div class="table-scroll"><table class="table table-hover">
            <thead><tr><th>Batch</th><th>Jenis</th><th class="num">Baris</th><th class="num">Valid</th><th class="num">Duplikat</th><th class="num">Tidak valid</th><th>Kesalahan utama</th><th>Status</th></tr></thead>
            <tbody><?php foreach ($batches as $b):
                $parts = [];
                foreach (array_filter(explode(',', (string) $b['error_breakdown'])) as $pair) { [$t, $n] = explode(':', $pair); $parts[] = (IMPORT_ERROR_LABELS[$t] ?? $t) . ' (' . $n . ')'; } ?>
                <tr><td><a href="<?= e(url('modules/imports/review.php?id=' . (int) $b['id'])) ?>"><strong>#<?= (int) $b['id'] ?></strong></a><span class="cell-sub"><?= e($b['original_name']) ?></span></td>
                    <td><?= e(IMPORT_TYPES[$b['import_type']] ?? $b['import_type']) ?></td>
                    <td class="num"><?= e(format_number($b['total_rows'], 0)) ?></td><td class="num"><?= e(format_number($b['valid_rows'], 0)) ?></td><td class="num"><?= e(format_number($b['duplicate_rows'], 0)) ?></td>
                    <td class="num"><?= $b['invalid_rows'] > 0 ? '<strong class="text-danger">' . e(format_number($b['invalid_rows'], 0)) . '</strong>' : '0' ?></td>
                    <td><?= $parts ? e(implode('; ', array_slice($parts, 0, 3))) : '<span class="muted-dash">—</span>' ?></td>
                    <td><?= imp_status_badge($b['status']) ?></td></tr>
            <?php endforeach; ?></tbody>
        </table></div>
        <?php endif; ?>
    </article>
</section>
<?php require BASE_PATH . '/includes/footer.php'; ?>
