<?php
declare(strict_types=1);
require_once dirname(__DIR__, 2) . '/includes/bootstrap.php';
require_once dirname(__DIR__) . '/employees/repo.php';
require_once __DIR__ . '/queries.php';

$user = require_permission('analytics.view');
$path = 'modules/analytics/index.php';

$f    = stats_parse_filters();
$opts = stats_filter_options();
foreach ([$f['from'], $f['to']] as $m) { if (!in_array($m, $opts['months'], true)) { $opts['months'][] = $m; } }
rsort($opts['months']);

$d = an_build($f);
$charts = an_charts($d);
$defaultTo = stats_latest_month();
$hasFilter = $f['dept'] > 0 || $f['vendor'] > 0 || $f['category'] !== '' || $f['status'] !== '' || $f['to'] !== $defaultTo || $f['from'] !== stats_shift_month($defaultTo, -(STATS_DEFAULT_MONTHS - 1));
$n = count($d['months']);

$page = ['title' => 'Analytics', 'active' => 'analytics', 'breadcrumb' => ['Data Intelligence', 'Analytics'], 'css' => ['crud.css'], 'js' => ['page-charts.js'], 'chart' => true];
require BASE_PATH . '/includes/header.php';
$opt = fn ($v, $cur, $label) => '<option value="' . e($v) . '"' . ((string) $v === (string) $cur ? ' selected' : '') . '>' . e($label) . '</option>';
$STATUS = ['active' => 'Aktif', 'inactive' => 'Tidak aktif', 'completed' => 'Selesai'];
?>
<section class="crud-page">
    <div class="page-header">
        <div><h1>Analytics</h1><p class="page-sub">Analisis <?= e($d['range_label']) ?> (<?= $n ?> bulan), dibandingkan dengan <?= e($d['prev']['label']) ?>.</p></div>
    </div>

    <?php foreach ($f['notices'] as $note): ?><div class="notice notice-warning"><?= icon('info') ?><div><?= e($note) ?></div></div><?php endforeach; ?>

    <form class="card analytics-filter" method="get" action="<?= e(url($path)) ?>">
        <label class="filter"><span>Dari bulan</span><select name="from" class="form-select" data-autosubmit><?php foreach ($opts['months'] as $ym) echo $opt($ym, $f['from'], month_label($ym)); ?></select></label>
        <label class="filter"><span>Sampai bulan</span><select name="to" class="form-select" data-autosubmit><?php foreach ($opts['months'] as $ym) echo $opt($ym, $f['to'], month_label($ym)); ?></select></label>
        <label class="filter"><span>Departemen</span><select name="dept" class="form-select" data-autosubmit><option value="">Semua</option><?php foreach ($opts['departments'] as $x) echo $opt($x['id'], $f['dept'], $x['name']); ?></select></label>
        <label class="filter"><span>Vendor</span><select name="vendor" class="form-select" data-autosubmit><option value="">Semua</option><?php foreach ($opts['vendors'] as $x) echo $opt($x['id'], $f['vendor'], $x['name']); ?></select></label>
        <label class="filter"><span>Kategori</span><select name="category" class="form-select" data-autosubmit><option value="">Semua</option><?php foreach (EMP_CATEGORIES as $k => $l) echo $opt($k, $f['category'], $l); ?></select></label>
        <label class="filter"><span>Status saat ini</span><select name="status" class="form-select" data-autosubmit><option value="">Semua</option><?php foreach ($STATUS as $k => $l) echo $opt($k, $f['status'], $l); ?></select></label>
        <?php if ($hasFilter): ?><div class="filter-actions"><a class="btn btn-outline btn-sm" href="<?= e(url($path)) ?>"><?= icon('rotate-ccw') ?>Reset</a></div><?php endif; ?>
    </form>

    <div class="notice notice-info"><?= icon('info') ?><div>Analisis berbasis <strong>bulan</strong> karena mandays dicatat bulanan. Filter status memakai status tenaga kerja <em>saat ini</em>, sedangkan jumlah tenaga kerja per bulan dihitung dari tanggal mulai dan berakhir.</div></div>

    <article class="card section-card">
        <header class="card-head"><div><h2>Ringkasan perubahan</h2><p>Periode ini (<?= e($d['range_label']) ?>) vs periode sebelumnya yang sejenis (<?= e($d['prev']['label']) ?>)</p></div></header>
        <ul class="insights">
            <?php foreach ($d['insights'] as $line): ?><li><?= e($line) ?></li><?php endforeach; ?>
        </ul>
        <p class="insights-note">Perubahan bersifat deskriptif. Grafik dan angka di halaman ini tidak menunjukkan hubungan sebab-akibat.</p>
    </article>

    <article class="card table-card section-card">
        <header class="card-head" style="padding:18px 22px 0"><div><h2>Perbandingan indikator</h2><p>Indikator "akhir periode" dibandingkan pada <?= e(month_label($f['to'])) ?> vs <?= e(month_label($d['prev']['to'])) ?>; indikator "jumlah periode" dijumlahkan pada seluruh rentang.</p></div></header>
        <div class="table-scroll"><table class="table">
            <thead><tr><th>Indikator</th><th>Dasar</th><th class="num">Periode ini</th><th class="num">Periode sebelumnya</th><th>Perubahan</th></tr></thead>
            <tbody>
            <?php foreach ($d['indicators'] as $i):
                $u = $i['key'] === 'quality' ? '%' : ''; $comparable = $i['cur'] !== null && $i['prev'] !== null; ?>
                <tr>
                    <td><strong><?= e($i['label']) ?></strong></td>
                    <td><span class="cell-sub" style="margin:0"><?= e($i['basis']) ?></span></td>
                    <td class="num"><?= $i['cur'] === null ? '—' : e(format_number($i['cur'])) . $u ?></td>
                    <td class="num"><?= $i['prev'] === null ? '—' : e(format_number($i['prev'])) . $u ?></td>
                    <td><?= $comparable ? ui_change($i['cur'], $i['prev'], $i['unit'], 1, $i['pct']) : '<span class="muted-dash">Tidak dapat dibandingkan</span>' ?></td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table></div>
    </article>

    <div class="chart-grid">
        <article class="card chart-card"><header class="card-head"><div><h2>Tren tenaga kerja aktif</h2><p>Per bulan, total dan per kategori</p></div></header>
            <div class="chart-box"><canvas id="cTrend" role="img" aria-label="Grafik garis tren tenaga kerja aktif"></canvas><div class="chart-empty" hidden><?= icon('inbox') ?><span>Belum ada data</span></div></div></article>
        <article class="card chart-card"><header class="card-head"><div><h2>Mandays per bulan</h2><p>Total hari kerja tercatat</p></div></header>
            <div class="chart-box"><canvas id="cMandays" role="img" aria-label="Grafik batang mandays per bulan"></canvas><div class="chart-empty" hidden><?= icon('inbox') ?><span>Belum ada mandays</span></div></div></article>
        <article class="card chart-card"><header class="card-head"><div><h2>Distribusi per departemen</h2><p>Aktif pada <?= e(month_label($f['to'])) ?></p></div></header>
            <div class="chart-box"><canvas id="cDept" role="img" aria-label="Grafik batang tenaga kerja per departemen"></canvas><div class="chart-empty" hidden><?= icon('inbox') ?><span>Belum ada data</span></div></div></article>
        <article class="card chart-card"><header class="card-head"><div><h2>Distribusi kategori</h2><p>Aktif pada <?= e(month_label($f['to'])) ?></p></div></header>
            <div class="chart-box"><canvas id="cCategory" role="img" aria-label="Grafik donat kategori tenaga kerja"></canvas><div class="chart-empty" hidden><?= icon('inbox') ?><span>Belum ada data</span></div></div></article>
        <article class="card chart-card"><header class="card-head"><div><h2>Tenaga kerja per vendor</h2><p>TAD aktif pada <?= e(month_label($f['to'])) ?></p></div></header>
            <div class="chart-box"><canvas id="cVendor" role="img" aria-label="Grafik batang TAD per vendor"></canvas><div class="chart-empty" hidden><?= icon('inbox') ?><span>Belum ada data</span></div></div></article>
        <article class="card chart-card"><header class="card-head"><div><h2>Data quality per periode</h2><p>Kelengkapan data tenaga kerja aktif</p></div></header>
            <div class="chart-box"><canvas id="cQuality" role="img" aria-label="Grafik garis kelengkapan data per bulan"></canvas><div class="chart-empty" hidden><?= icon('inbox') ?><span>Belum ada data</span></div></div></article>
    </div>

    <article class="card table-card section-card">
        <header class="card-head" style="padding:18px 22px 0"><div><h2>Perbandingan mandays antarperiode</h2><p>Perubahan dibandingkan bulan sebelumnya; "—" bila salah satu bulan tidak memiliki record</p></div></header>
        <div class="table-scroll"><table class="table">
            <thead><tr><th>Bulan</th><th class="num">Tenaga kerja aktif</th><th class="num">Record</th><th class="num">Total mandays</th><th class="num">Rata-rata/record</th><th>Perubahan mandays</th><th class="num">Kelengkapan</th></tr></thead>
            <tbody>
            <?php foreach (array_reverse($d['month_rows']) as $r): $q = $d['quality'][$r['ym']]; ?>
                <tr>
                    <td><strong><?= e($r['label']) ?></strong></td>
                    <td class="num"><?= e(format_number($r['headcount'])) ?></td>
                    <td class="num"><?= e(format_number($r['records'])) ?></td>
                    <td class="num"><strong><?= e(format_number($r['mandays'])) ?></strong></td>
                    <td class="num"><?= $r['avg'] === null ? '—' : e(format_number($r['avg'])) ?></td>
                    <td><?= $r['comparable'] ? ui_change($r['mandays'], $r['prev_mandays']) : '<span class="muted-dash">—</span>' ?></td>
                    <td class="num"><?= $q === null ? '—' : e(format_number($q)) . '%' ?></td>
                </tr>
            <?php endforeach; ?>
            </tbody>
            <tfoot><tr><td>Total rentang</td><td class="num"></td><td class="num"><?= e(format_number($d['totals']['records'])) ?></td><td class="num"><?= e(format_number($d['totals']['mandays'])) ?></td><td class="num"><?= $d['totals']['records'] > 0 ? e(format_number($d['totals']['mandays'] / $d['totals']['records'])) : '—' ?></td><td></td><td></td></tr></tfoot>
        </table></div>
    </article>

    <div class="chart-grid">
        <article class="card table-card chart-card"><header class="card-head" style="padding:18px 22px 0"><div><h2>Tenaga kerja per departemen</h2><p>Aktif pada <?= e(month_label($f['to'])) ?></p></div></header>
            <div class="table-scroll"><table class="table"><thead><tr><th>Departemen</th><th class="num">Aktif</th></tr></thead><tbody>
            <?php foreach ($d['by_dept'] as $r): ?><tr><td><strong><?= e($r['name']) ?></strong><span class="cell-sub"><?= e($r['code']) ?></span></td><td class="num"><?= e(format_number($r['total'])) ?></td></tr><?php endforeach; ?>
            </tbody><tfoot><tr><td>Total</td><td class="num"><?= e(format_number(array_sum(array_column($d['by_dept'], 'total')))) ?></td></tr></tfoot></table></div></article>
        <article class="card table-card chart-card"><header class="card-head" style="padding:18px 22px 0"><div><h2>Tenaga kerja per vendor</h2><p>TAD aktif pada <?= e(month_label($f['to'])) ?></p></div></header>
            <?php if (!$d['by_vendor']): ?><?= ui_empty_state('handshake', 'Belum ada data vendor') ?>
            <?php else: ?><div class="table-scroll"><table class="table"><thead><tr><th>Vendor</th><th class="num">TAD aktif</th></tr></thead><tbody>
            <?php foreach ($d['by_vendor'] as $r): ?><tr><td><strong><?= e($r['name']) ?></strong><span class="cell-sub"><?= e($r['code']) ?></span></td><td class="num"><?= e(format_number($r['total'])) ?></td></tr><?php endforeach; ?>
            </tbody><tfoot><tr><td>Total</td><td class="num"><?= e(format_number(array_sum(array_column($d['by_vendor'], 'total')))) ?></td></tr></tfoot></table></div><?php endif; ?></article>
    </div>
</section>
<script type="application/json" id="chartData"><?= json_encode($charts, JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_UNESCAPED_UNICODE | JSON_PARTIAL_OUTPUT_ON_ERROR) ?></script>
<?php require BASE_PATH . '/includes/footer.php'; ?>
