<?php
/**
 * Perhitungan halaman Analytics.
 *
 * ATURAN PERBANDINGAN: "periode sebelumnya" = rentang bulan dengan PANJANG SAMA yang berakhir tepat sebelum periode awal
 * (mis. Apr–Sep 2026 dibanding Okt 2025–Mar 2026). Indikator "titik waktu" (jumlah tenaga kerja, kelengkapan) dibandingkan pada
 * bulan terakhir tiap rentang; indikator "akumulasi" (mandays, record) dijumlahkan pada seluruh rentang. Perubahan hanya deskriptif.
 */
declare(strict_types=1);

function an_build(array $f): array
{
    $months     = stats_months($f['from'], $f['to']);
    $n          = count($months);
    $prevTo     = stats_shift_month($f['from'], -1);
    $prevFrom   = stats_shift_month($f['from'], -$n);
    $prevMonths = stats_months($prevFrom, $prevTo);

    $wf = stats_workforce_series(array_merge($prevMonths, $months), $f);
    $md = stats_mandays_series(array_merge($prevMonths, $months), $f);          // bulan terakhir periode sebelumnya = pembanding bulan pertama
    $mdCur  = stats_mandays_totals($f['from'], $f['to'], $f);
    $mdPrev = stats_mandays_totals($prevFrom, $prevTo, $f);

    $cur  = $wf[$f['to']];
    $prev = $wf[$prevTo];
    $pct  = fn (array $w): ?float => $w['total'] > 0 ? round($w['complete'] / $w['total'] * 100, 1) : null;

    $indicators = [
        ['key' => 'headcount', 'label' => 'Tenaga kerja aktif', 'basis' => 'akhir periode', 'cur' => (float) $cur['total'],  'prev' => (float) $prev['total'],  'unit' => '', 'pct' => true],
        ['key' => 'tad',       'label' => 'TAD aktif',          'basis' => 'akhir periode', 'cur' => (float) $cur['tad'],    'prev' => (float) $prev['tad'],    'unit' => '', 'pct' => true],
        ['key' => 'intern',    'label' => 'Peserta magang aktif', 'basis' => 'akhir periode', 'cur' => (float) $cur['intern'], 'prev' => (float) $prev['intern'], 'unit' => '', 'pct' => true],
        ['key' => 'mandays',   'label' => 'Total mandays',      'basis' => 'jumlah periode', 'cur' => $mdCur['mandays'],     'prev' => $mdPrev['mandays'],      'unit' => ' hari', 'pct' => true, 'needs_records' => true],
        ['key' => 'records',   'label' => 'Jumlah record mandays', 'basis' => 'jumlah periode', 'cur' => (float) $mdCur['records'], 'prev' => (float) $mdPrev['records'], 'unit' => '', 'pct' => true],
        ['key' => 'avg',       'label' => 'Rata-rata mandays per record', 'basis' => 'periode', 'cur' => $mdCur['records'] > 0 ? $mdCur['mandays'] / $mdCur['records'] : null, 'prev' => $mdPrev['records'] > 0 ? $mdPrev['mandays'] / $mdPrev['records'] : null, 'unit' => ' hari', 'pct' => true],
        ['key' => 'quality',   'label' => 'Kelengkapan data',   'basis' => 'akhir periode (%)', 'cur' => $pct($cur), 'prev' => $pct($prev), 'unit' => ' poin', 'pct' => false],
    ];

    // Kalimat ringkasan (deskriptif, tanpa klaim sebab-akibat)
    $curEnd = month_label($f['to']); $prevEnd = month_label($prevTo);
    $curRange = month_label($f['from']) . ($n > 1 ? ' – ' . month_label($f['to']) : '');
    $prevRange = month_label($prevFrom) . ($n > 1 ? ' – ' . month_label($prevTo) : '');
    $insights = [];
    $byKey = array_column($indicators, null, 'key');
    foreach (['headcount' => 'Jumlah tenaga kerja aktif', 'tad' => 'Jumlah TAD aktif', 'intern' => 'Jumlah peserta magang aktif'] as $k => $lbl) {
        $i = $byKey[$k];
        $insights[] = "{$lbl} pada {$curEnd} " . change_phrase($i['cur'], $i['prev']) . " dibandingkan {$prevEnd} (" . format_number($i['cur']) . " vs " . format_number($i['prev']) . ").";
    }
    if ($mdPrev['records'] === 0 && $mdCur['records'] === 0) {
        $insights[] = 'Belum ada record mandays pada periode ini maupun periode sebelumnya.';
    } elseif ($mdPrev['records'] === 0) {
        $insights[] = "Total mandays {$curRange} adalah " . format_number($mdCur['mandays']) . " hari; tidak ada record mandays pada {$prevRange} sebagai pembanding.";
    } else {
        $i = $byKey['mandays'];
        $insights[] = "Total mandays {$curRange} " . change_phrase($i['cur'], $i['prev'], ' hari') . " dibandingkan {$prevRange} (" . format_number($i['cur']) . " vs " . format_number($i['prev']) . " hari).";
    }
    $q = $byKey['quality'];
    if ($q['cur'] === null || $q['prev'] === null) {
        $insights[] = 'Kelengkapan data tidak dapat dibandingkan karena salah satu bulan tidak memiliki tenaga kerja aktif.';
    } else {
        $insights[] = "Kelengkapan data pada {$curEnd} " . change_phrase($q['cur'], $q['prev'], ' poin persentase') . " dibandingkan {$prevEnd} (" . format_number($q['cur']) . "% vs " . format_number($q['prev']) . "%).";
    }

    // Tabel mandays per bulan + perubahan terhadap bulan sebelumnya
    $monthRows = [];
    foreach ($months as $m) {
        $s = $md[$m]; $p = $md[stats_shift_month($m, -1)];
        $monthRows[] = ['ym' => $m, 'label' => month_label($m)] + $s + [
            'avg' => $s['records'] > 0 ? $s['mandays'] / $s['records'] : null,
            'comparable' => $s['records'] > 0 && $p['records'] > 0, 'prev_mandays' => $p['mandays'],
            'headcount' => $wf[$m]['total'],
        ];
    }

    // Kualitas data per periode
    $quality = [];
    foreach ($months as $m) {
        $quality[$m] = $pct($wf[$m]);
    }

    return [
        'months' => $months, 'prev' => ['from' => $prevFrom, 'to' => $prevTo, 'label' => $prevRange], 'range_label' => $curRange,
        'wf' => $wf, 'md' => $md, 'indicators' => $indicators, 'insights' => $insights, 'month_rows' => $monthRows, 'quality' => $quality,
        'by_dept' => stats_snapshot_by_group($f['to'], $f, 'department'),
        'by_vendor' => stats_snapshot_by_group($f['to'], $f, 'vendor'),
        'cur' => $cur,
        'totals' => $mdCur,
    ];
}

/** Konfigurasi grafik untuk page-charts.js. */
function an_charts(array $d): array
{
    $labels = array_map(fn ($m) => month_label($m, true), $d['months']);
    $col = fn (string $k): array => array_map(fn ($m) => $d['wf'][$m][$k], $d['months']);
    $endLabel = month_label(end($d['months']));
    $empty = 'Belum ada data pada rentang ini';

    return ['charts' => [
        ['id' => 'cTrend', 'type' => 'line', 'labels' => $labels, 'yTitle' => 'Tenaga kerja aktif', 'emptyText' => $empty, 'datasets' => [
            ['label' => 'Total', 'data' => $col('total'), 'color' => '#0B132B', 'width' => 3],
            ['label' => 'Karyawan', 'data' => $col('employee'), 'color' => '#3A86FF'],
            ['label' => 'TAD', 'data' => $col('tad'), 'color' => '#14A3A8'],
            ['label' => 'Peserta magang', 'data' => $col('intern'), 'color' => '#94A3B8'],
        ]],
        ['id' => 'cMandays', 'type' => 'bar', 'labels' => $labels, 'yTitle' => 'Mandays (hari)', 'emptyText' => 'Belum ada mandays pada rentang ini', 'datasets' => [
            ['label' => 'Total mandays', 'data' => array_map(fn ($m) => $d['md'][$m]['mandays'], $d['months']), 'color' => '#1C2541', 'unit' => ' hari'],
        ]],
        ['id' => 'cDept', 'type' => 'bar', 'labels' => array_column($d['by_dept'], 'code'), 'names' => array_column($d['by_dept'], 'name'), 'yTitle' => "Aktif pada {$endLabel}", 'emptyText' => $empty, 'datasets' => [
            ['label' => 'Tenaga kerja aktif', 'data' => array_map('intval', array_column($d['by_dept'], 'total')), 'color' => '#3A86FF'],
        ]],
        ['id' => 'cCategory', 'type' => 'doughnut', 'labels' => ['Karyawan', 'TAD', 'Peserta magang'], 'emptyText' => $empty, 'datasets' => [
            ['data' => [$d['cur']['employee'], $d['cur']['tad'], $d['cur']['intern']], 'colors' => ['#3A86FF', '#14A3A8', '#94A3B8']],
        ]],
        ['id' => 'cVendor', 'type' => 'bar', 'horizontal' => true, 'labels' => array_column($d['by_vendor'], 'name'), 'emptyText' => 'Tidak ada TAD bervendor pada periode ini', 'datasets' => [
            ['label' => 'TAD aktif', 'data' => array_map('intval', array_column($d['by_vendor'], 'total')), 'color' => '#14A3A8'],
        ]],
        ['id' => 'cQuality', 'type' => 'line', 'percent' => true, 'labels' => $labels, 'yTitle' => 'Kelengkapan (%)', 'emptyText' => $empty, 'datasets' => [
            ['label' => 'Kelengkapan data', 'data' => array_values($d['quality']), 'color' => '#16A34A', 'width' => 3],
        ]],
    ]];
}
