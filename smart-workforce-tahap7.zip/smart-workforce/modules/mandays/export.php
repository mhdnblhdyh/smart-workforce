<?php
/** Ekspor CSV record mandays dengan filter yang sama seperti daftar. */
declare(strict_types=1);
require_once dirname(__DIR__, 2) . '/includes/bootstrap.php';
require_once dirname(__DIR__) . '/employees/repo.php';
require_once __DIR__ . '/repo.php';

$user = require_permission('reports.export');
$f = md_filters();
$n = md_summary($f)['records'];
audit_log('export', 'workforce_record', null, "Ekspor CSV mandays ({$n} baris, periode " . $f['period'] . ')', (int) $user['id']);
csv_download(
    'mandays_' . ($f['period'] === 'all' ? 'semua-periode' : $f['period']) . '_' . date('Ymd-His') . '.csv',
    ['Periode', 'ID Internal', 'Nama', 'Kategori', 'Departemen', 'Vendor', 'Mandays', 'Hari Terjadwal', 'Hari Hadir', 'Sumber', 'Keterangan'],
    md_export_rows($f)
);
