<?php
declare(strict_types=1);
require_once dirname(__DIR__, 2) . '/includes/bootstrap.php';
require_once dirname(__DIR__) . '/employees/repo.php';   // EMP_CATEGORIES
require_once __DIR__ . '/repo.php';

$user = require_permission('mandays.manage');
if (!is_post()) {
    redirect('modules/mandays/index.php');
}
csrf_require();

$back = 'modules/mandays/index.php';
$rqs  = $_POST['return_qs'] ?? '';
$id   = (isset($_POST['id']) && ctype_digit((string) $_POST['id'])) ? (int) $_POST['id'] : 0;
$existing = $id > 0 ? md_find($id) : null;
if ($id > 0 && $existing === null) {
    flash_set('danger', 'Record mandays tidak ditemukan atau sudah dihapus.');
    redirect_to_list($back, $rqs);
}

[$d, $errors] = md_validate($_POST, $existing);
$fail = function (array $errors) use ($existing, $id, $rqs, $back): void {
    form_state_set('mandays', ['mode' => $existing ? 'edit' : 'create', 'id' => $id, 'old' => post_old_input(MD_FORM_FIELDS), 'errors' => $errors]);
    flash_set('warning', 'Periksa kembali isian formulir.');
    redirect_to_list($back, $rqs);
};
if ($errors) {
    $fail($errors);
}

try {
    if ($existing) {
        db_run(
            'UPDATE workforce_records SET mandays = ?, scheduled_days = ?, attended_days = ?, notes = ? WHERE id = ?',
            'ssssi',
            [$d['mandays'], $d['scheduled_days'], $d['attended_days'], $d['notes'], $id]
        );
        $changed = changed_fields($existing, $d);
        audit_log('update', 'workforce_record', $id, 'Mengubah mandays pegawai #' . $existing['employee_id'] . ' periode ' . substr($existing['period_month'], 0, 7) . ($changed ? ' (kolom: ' . implode(', ', $changed) . ')' : ' (tanpa perubahan)'), (int) $user['id']);
        flash_set('success', 'Record mandays berhasil diperbarui.');
    } else {
        db_run(
            "INSERT INTO workforce_records (employee_id, period_month, mandays, scheduled_days, attended_days, notes, source, created_by) VALUES (?, ?, ?, ?, ?, ?, 'manual', ?)",
            'isssssi',
            [$d['employee_id'], $d['period_month'], $d['mandays'], $d['scheduled_days'], $d['attended_days'], $d['notes'], (int) $user['id']]
        );
        audit_log('create', 'workforce_record', db_last_id(), 'Menambah mandays pegawai #' . $d['employee_id'] . ' periode ' . substr($d['period_month'], 0, 7), (int) $user['id']);
        flash_set('success', 'Record mandays berhasil ditambahkan untuk ' . month_label($d['period_month']) . '.');
    }
} catch (Throwable $ex) {
    if (is_duplicate_error($ex)) {
        $fail(['employee_id' => 'Record untuk tenaga kerja ini pada periode tersebut sudah ada. Edit record yang ada.']);
    }
    throw $ex;
}
redirect_to_list($back, $rqs);
