<?php
/**
 * Data & aturan bisnis modul Mandays & Kehadiran.
 *
 * GRANULARITAS : 1 record = 1 tenaga kerja x 1 bulan (period_month = tanggal 1). Kunci unik (employee_id, period_month).
 * MANDAYS      : jumlah hari kerja yang diakui pada bulan tersebut (0 .. jumlah hari kalender bulan itu). Bukan jumlah karyawan.
 * KEHADIRAN    : hari terjadwal & hari hadir bersifat OPSIONAL dan harus diisi berpasangan; bila tidak tersedia dibiarkan
 *                kosong (NULL) — tidak pernah diestimasi atau diisi otomatis.
 * ATURAN       : periode tidak boleh di masa depan; tenaga kerja harus aktif pada bulan tsb (berdasarkan tanggal mulai/berakhir);
 *                hari hadir <= hari terjadwal.
 */
declare(strict_types=1);

const MD_SOURCES = ['manual' => 'Manual', 'import' => 'Import'];
const MD_SORT = [
    'period' => 'r.period_month', 'code' => 'e.employee_code', 'name' => 'e.full_name', 'department' => 'd.name',
    'vendor' => 'v.name', 'mandays' => 'r.mandays', 'source' => 'r.source',
];
const MD_FORM_FIELDS = ['employee_id', 'period', 'mandays', 'scheduled_days', 'attended_days', 'notes'];
const MD_FROM = 'FROM workforce_records r JOIN employees e ON e.id = r.employee_id JOIN departments d ON d.id = e.department_id LEFT JOIN vendors v ON v.id = e.vendor_id';

function md_filters(): array
{
    $g = fn (string $k): string => (isset($_GET[$k]) && is_string($_GET[$k])) ? trim($_GET[$k]) : '';
    $period = $g('period') === 'all' ? 'all' : (stats_parse_month($g('period')) ?? stats_latest_month());
    return [
        'period'   => $period,
        'q'        => mb_substr($g('q'), 0, 100),
        'dept'     => ctype_digit($g('dept')) ? (int) $g('dept') : 0,
        'vendor'   => ctype_digit($g('vendor')) ? (int) $g('vendor') : 0,
        'category' => array_key_exists($g('category'), EMP_CATEGORIES) ? $g('category') : '',
        'source'   => array_key_exists($g('source'), MD_SOURCES) ? $g('source') : '',
    ];
}

function md_where(array $f): array
{
    $w = []; $t = ''; $p = [];
    if ($f['period'] !== 'all') { $w[] = 'r.period_month = ?'; $t .= 's'; $p[] = $f['period'] . '-01'; }
    if ($f['q'] !== '') {
        $like = '%' . like_escape($f['q']) . '%';
        $w[] = '(e.full_name LIKE ? OR e.employee_code LIKE ?)'; $t .= 'ss'; array_push($p, $like, $like);
    }
    if ($f['dept'] > 0)       { $w[] = 'e.department_id = ?'; $t .= 'i'; $p[] = $f['dept']; }
    if ($f['vendor'] > 0)     { $w[] = 'e.vendor_id = ?'; $t .= 'i'; $p[] = $f['vendor']; }
    if ($f['category'] !== '') { $w[] = 'e.category = ?'; $t .= 's'; $p[] = $f['category']; }
    if ($f['source'] !== '')   { $w[] = 'r.source = ?'; $t .= 's'; $p[] = $f['source']; }
    return [$w ? 'WHERE ' . implode(' AND ', $w) : '', $t, $p];
}

/** Ringkasan pada hasil filter (bukan hanya halaman aktif). */
function md_summary(array $f): array
{
    [$where, $t, $p] = md_where($f);
    $r = db_fetch_one(
        "SELECT COUNT(*) AS records, COALESCE(SUM(r.mandays), 0) AS mandays, COUNT(DISTINCT r.employee_id) AS workers,
                COALESCE(SUM(r.attended_days IS NULL OR r.scheduled_days IS NULL), 0) AS no_attendance " . MD_FROM . " {$where}",
        $t,
        $p
    );
    return ['records' => (int) $r['records'], 'mandays' => (float) $r['mandays'], 'workers' => (int) $r['workers'], 'no_attendance' => (int) $r['no_attendance']];
}

function md_list(array $f, array $req, int $page): array
{
    [$where, $t, $p] = md_where($f);
    return db_fetch_all(
        "SELECT r.*, e.employee_code, e.full_name, e.category, d.name AS department_name, d.code AS department_code, v.name AS vendor_name
         " . MD_FROM . " {$where} ORDER BY {$req['order_sql']}, r.id ASC LIMIT ? OFFSET ?",
        $t . 'ii',
        array_merge($p, [$req['per'], ($page - 1) * $req['per']])
    );
}

function md_export_rows(array $f): Generator
{
    [$where, $t, $p] = md_where($f);
    foreach (db_fetch_all(
        "SELECT r.*, e.employee_code, e.full_name, e.category, d.name AS department_name, v.name AS vendor_name
         " . MD_FROM . " {$where} ORDER BY r.period_month ASC, e.employee_code ASC LIMIT 50000",
        $t,
        $p
    ) as $r) {
        yield [
            substr($r['period_month'], 0, 7), $r['employee_code'], $r['full_name'], EMP_CATEGORIES[$r['category']] ?? $r['category'],
            $r['department_name'], $r['vendor_name'] ?? '', $r['mandays'], $r['scheduled_days'] ?? '', $r['attended_days'] ?? '',
            MD_SOURCES[$r['source']] ?? $r['source'], $r['notes'] ?? '',
        ];
    }
}

function md_find(int $id): ?array
{
    return db_fetch_one('SELECT * FROM workforce_records WHERE id = ?', 'i', [$id]);
}

function md_num($v): string
{
    return $v === null ? '' : rtrim(rtrim((string) $v, '0'), '.');
}

function md_record(array $r): array
{
    $period = substr($r['period_month'], 0, 7);
    $raw = [
        'id' => (string) $r['id'], 'employee_id' => (string) $r['employee_id'], 'period' => $period,
        'mandays' => md_num($r['mandays']), 'scheduled_days' => md_num($r['scheduled_days']), 'attended_days' => md_num($r['attended_days']),
        'notes' => (string) ($r['notes'] ?? ''),
    ];
    $att = ($r['attended_days'] === null || $r['scheduled_days'] === null) ? 'Tidak tersedia' : md_num($r['attended_days']) . ' dari ' . md_num($r['scheduled_days']) . ' hari terjadwal';
    return [
        'raw' => $raw, 'title' => $r['full_name'] . ' — ' . month_label($period),
        'name' => $r['employee_code'] . ' · ' . month_label($period),
        'details' => [
            ['Tenaga kerja', $r['employee_code'] . ' — ' . $r['full_name']], ['Kategori', EMP_CATEGORIES[$r['category']] ?? $r['category']],
            ['Departemen', $r['department_name']], ['Vendor', $r['vendor_name'] ?? '-'], ['Periode', month_label($period)],
            ['Mandays', md_num($r['mandays']) . ' hari'], ['Kehadiran', $att],
            ['Sumber data', MD_SOURCES[$r['source']] ?? $r['source']], ['Keterangan', $r['notes'] ?: '-'],
            ['Dibuat', format_datetime($r['created_at'])], ['Diperbarui', format_datetime($r['updated_at'])],
        ],
    ];
}

/** @return array{0:array,1:array} [data bersih, errors] */
function md_validate(array $in, ?array $existing): array
{
    $s = fn (string $k, int $max = 255): string => (isset($in[$k]) && is_string($in[$k])) ? mb_substr(trim($in[$k]), 0, $max) : '';
    $e = [];

    // Saat edit, tenaga kerja & periode TIDAK dapat diubah (mencegah pemindahan record).
    $empId  = $existing ? (int) $existing['employee_id'] : (ctype_digit($s('employee_id', 10)) ? (int) $s('employee_id', 10) : 0);
    $period = $existing ? substr($existing['period_month'], 0, 7) : $s('period', 7);
    $selfId = $existing ? (int) $existing['id'] : null;

    $emp = $empId > 0 ? db_fetch_one('SELECT id, start_date, end_date FROM employees WHERE id = ?', 'i', [$empId]) : null;
    if ($emp === null) {
        $e['employee_id'] = 'Pilih tenaga kerja yang valid.';
    }

    $ym = stats_parse_month($period);
    $days = null;
    if ($ym === null) {
        $e['period'] = 'Periode wajib diisi dengan format yang valid (YYYY-MM).';
    } elseif ($ym > date('Y-m')) {
        $e['period'] = 'Periode tidak boleh di masa depan.';
    } else {
        $days = (int) date('t', strtotime($ym . '-01'));
        if ($emp !== null) {
            $first = $ym . '-01';
            $last  = $ym . '-' . $days;
            if ($emp['start_date'] > $last || ($emp['end_date'] !== null && $emp['end_date'] < $first)) {
                $e['period'] = 'Tenaga kerja tidak aktif pada periode ini (aktif ' . fmt_date($emp['start_date']) . ' s/d ' . ($emp['end_date'] ? fmt_date($emp['end_date']) : 'berjalan') . ').';
            }
        }
    }
    $max = $days ?? 31;

    $mandays = val_decimal($s('mandays', 7), (float) $max);
    if ($s('mandays', 7) === '') {
        $e['mandays'] = 'Mandays wajib diisi.';
    } elseif ($mandays === null) {
        $e['mandays'] = "Mandays harus angka 0–{$max} (maksimal 2 desimal)" . ($days ? ' sesuai jumlah hari pada bulan tersebut.' : '.');
    }

    $schedRaw = $s('scheduled_days', 7);
    $attRaw   = $s('attended_days', 7);
    $sched = $att = null;
    if ($schedRaw !== '' || $attRaw !== '') {
        if ($schedRaw === '' || $attRaw === '') {
            $e[$schedRaw === '' ? 'scheduled_days' : 'attended_days'] = 'Isi hari terjadwal dan hari hadir bersamaan, atau kosongkan keduanya.';
        } else {
            $sched = val_decimal($schedRaw, (float) $max);
            $att   = val_decimal($attRaw, (float) $max);
            if ($sched === null) { $e['scheduled_days'] = "Hari terjadwal harus angka 0–{$max}."; }
            if ($att === null)   { $e['attended_days'] = "Hari hadir harus angka 0–{$max}."; }
            if ($sched !== null && $att !== null && (float) $att > (float) $sched) {
                $e['attended_days'] = 'Hari hadir tidak boleh melebihi hari terjadwal.';
            }
        }
    }

    $notes = $s('notes', 255);

    if (!isset($e['employee_id']) && !isset($e['period']) && $emp !== null && $ym !== null) {
        $dup = (int) db_value(
            'SELECT COUNT(*) FROM workforce_records WHERE employee_id = ? AND period_month = ?' . ($selfId ? ' AND id <> ?' : ''),
            'is' . ($selfId ? 'i' : ''),
            $selfId ? [$empId, $ym . '-01', $selfId] : [$empId, $ym . '-01']
        );
        if ($dup > 0) {
            $e['employee_id'] = 'Record untuk tenaga kerja ini pada periode tersebut sudah ada. Edit record yang ada.';
        }
    }

    return [[
        'employee_id' => $empId, 'period_month' => ($ym ?? '') . '-01', 'mandays' => $mandays, 'scheduled_days' => $sched,
        'attended_days' => $att, 'notes' => null_if_empty($notes),
    ], $e];
}
