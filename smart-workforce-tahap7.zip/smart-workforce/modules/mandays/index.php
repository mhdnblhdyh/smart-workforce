<?php
declare(strict_types=1);
require_once dirname(__DIR__, 2) . '/includes/bootstrap.php';
require_once dirname(__DIR__) . '/employees/repo.php';
require_once __DIR__ . '/repo.php';

$user      = require_permission('mandays.view');
$canManage = user_can('mandays.manage', $user);
$canExport = user_can('reports.export', $user);
$path      = 'modules/mandays/index.php';

$f       = md_filters();
$req     = list_request(MD_SORT, 'name', 'asc');
$total   = md_summary($f);
$pageNo  = list_clamp_page($total['records'], $req['page'], $req['per']);
$rows    = md_list($f, $req, $pageNo);
$months  = stats_available_months();
if ($f['period'] !== 'all' && !in_array($f['period'], $months, true)) {
    $months[] = $f['period'];
    rsort($months);
}
$departments = db_fetch_all('SELECT id, name FROM departments ORDER BY name');
$vendors     = db_fetch_all('SELECT id, name FROM vendors ORDER BY name');
$employees   = db_fetch_all('SELECT e.id, e.employee_code, e.full_name, d.code AS dept FROM employees e JOIN departments d ON d.id = e.department_id ORDER BY e.employee_code');
$hasFilter = $f['q'] !== '' || $f['dept'] > 0 || $f['vendor'] > 0 || $f['category'] !== '' || $f['source'] !== '' || $f['period'] === 'all' || $f['period'] !== stats_latest_month();
$formState = form_state_pull('mandays');
$returnQs  = safe_return_qs($_SERVER['QUERY_STRING'] ?? '');
$periodLabel = $f['period'] === 'all' ? 'semua periode' : month_label($f['period']);

$page = ['title' => 'Mandays & Kehadiran', 'active' => 'mandays', 'breadcrumb' => ['Workforce Management', 'Mandays & Kehadiran'], 'css' => ['crud.css'], 'js' => ['crud.js', 'mandays.js']];
require BASE_PATH . '/includes/header.php';
$opt = fn ($v, $cur, $label) => '<option value="' . e($v) . '"' . ((string) $v === (string) $cur ? ' selected' : '') . '>' . e($label) . '</option>';
?>
<section class="crud-page">
    <div class="page-header">
        <div><h1>Mandays & Kehadiran</h1><p class="page-sub">Satu record mewakili satu tenaga kerja pada satu bulan.</p></div>
        <div class="page-actions">
            <?php if ($canExport): ?><a class="btn btn-outline" href="<?= e(url('modules/mandays/export.php') . (($_SERVER['QUERY_STRING'] ?? '') !== '' ? '?' . safe_return_qs($_SERVER['QUERY_STRING']) : '')) ?>" title="Ekspor CSV sesuai filter saat ini"><?= icon('download') ?>Ekspor CSV</a><?php endif; ?>
            <?php if ($canManage): ?><button type="button" class="btn btn-primary" data-action="create"><?= icon('plus') ?>Tambah record</button><?php endif; ?>
        </div>
    </div>

    <?= ui_tabs([['records', 'Record', 'modules/mandays/index.php'], ['recap', 'Rekap & tren', 'modules/mandays/recap.php']], 'records') ?>

    <div class="mini-stats">
        <?= ui_mini_stat('Total mandays', format_number($total['mandays']) . ' hari', ucfirst($periodLabel)) ?>
        <?= ui_mini_stat('Jumlah record', format_number($total['records']), format_number($total['workers']) . ' tenaga kerja') ?>
        <?= ui_mini_stat('Rata-rata per record', $total['records'] > 0 ? format_number($total['mandays'] / $total['records']) . ' hari' : '—', 'mandays ÷ record') ?>
        <?= ui_mini_stat('Tanpa data kehadiran', format_number($total['no_attendance']), 'informasi, bukan kesalahan') ?>
    </div>

    <form class="card toolbar" method="get" action="<?= e(url($path)) ?>">
        <input type="hidden" name="sort" value="<?= e($req['sort']) ?>"><input type="hidden" name="dir" value="<?= e($req['dir']) ?>">
        <label class="search-box"><?= icon('search') ?><input type="search" name="q" value="<?= e($f['q']) ?>" placeholder="Cari nama atau ID…" maxlength="100" aria-label="Cari"></label>
        <select name="period" class="form-select" data-autosubmit aria-label="Periode">
            <option value="all"<?= $f['period'] === 'all' ? ' selected' : '' ?>>Semua periode</option>
            <?php foreach ($months as $ym) echo $opt($ym, $f['period'], month_label($ym)); ?>
        </select>
        <select name="dept" class="form-select" data-autosubmit aria-label="Departemen">
            <option value="">Semua departemen</option>
            <?php foreach ($departments as $d) echo $opt($d['id'], $f['dept'], $d['name']); ?>
        </select>
        <select name="vendor" class="form-select" data-autosubmit aria-label="Vendor">
            <option value="">Semua vendor</option>
            <?php foreach ($vendors as $v) echo $opt($v['id'], $f['vendor'], $v['name']); ?>
        </select>
        <select name="category" class="form-select" data-autosubmit aria-label="Kategori">
            <option value="">Semua kategori</option>
            <?php foreach (EMP_CATEGORIES as $k => $l) echo $opt($k, $f['category'], $l); ?>
        </select>
        <select name="source" class="form-select" data-autosubmit aria-label="Sumber data">
            <option value="">Semua sumber</option>
            <?php foreach (MD_SOURCES as $k => $l) echo $opt($k, $f['source'], $l); ?>
        </select>
        <select name="per" class="form-select form-select-sm" data-autosubmit aria-label="Baris per halaman">
            <?php foreach (PER_PAGE_OPTIONS as $n) echo $opt($n, $req['per'], $n . ' / halaman'); ?>
        </select>
        <button type="submit" class="btn btn-outline btn-sm"><?= icon('search') ?>Cari</button>
        <?php if ($hasFilter): ?><a class="btn btn-outline btn-sm" href="<?= e(url($path)) ?>"><?= icon('rotate-ccw') ?>Reset</a><?php endif; ?>
    </form>

    <div class="card table-card">
        <?php if ($total['records'] === 0): ?>
            <?= $hasFilter
                ? ui_empty_state('search', 'Tidak ada record yang cocok', 'Belum ada mandays pada ' . $periodLabel . ' dengan filter ini. Coba pilih periode lain atau reset filter.', '<a class="btn btn-outline btn-sm" href="' . e(url($path)) . '">Reset filter</a>')
                : ui_empty_state('calendar-check', 'Belum ada record mandays', $canManage ? 'Tambahkan record mandays pertama untuk tenaga kerja aktif.' : 'Data akan tampil setelah ditambahkan oleh HC Staff atau Admin.') ?>
        <?php else: ?>
        <div class="table-scroll">
            <table class="table table-hover">
                <thead><tr>
                    <?= ui_sort_th('Periode', 'period', $req, $path) ?>
                    <?= ui_sort_th('Tenaga kerja', 'name', $req, $path) ?>
                    <?= ui_sort_th('Departemen', 'department', $req, $path) ?>
                    <?= ui_sort_th('Vendor', 'vendor', $req, $path) ?>
                    <?= ui_sort_th('Mandays', 'mandays', $req, $path, 'num') ?>
                    <th class="num">Kehadiran</th>
                    <?= ui_sort_th('Sumber', 'source', $req, $path) ?>
                    <th class="col-actions"><span class="sr-only">Aksi</span></th>
                </tr></thead>
                <tbody>
                <?php foreach ($rows as $r): ?>
                    <tr data-record="<?= e(json_encode(md_record($r), JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT)) ?>">
                        <td><?= e(month_label($r['period_month'])) ?></td>
                        <td><strong><?= e($r['full_name']) ?></strong><span class="cell-sub"><?= e($r['employee_code']) ?></span></td>
                        <td><?= e($r['department_name']) ?></td>
                        <td><?= e($r['vendor_name'] ?? '-') ?></td>
                        <td class="num"><strong><?= e(format_number($r['mandays'])) ?></strong></td>
                        <td class="num"><?= ($r['attended_days'] === null || $r['scheduled_days'] === null) ? '<span class="muted-dash" title="Data kehadiran tidak tersedia">—</span>' : e(format_number($r['attended_days'])) . ' / ' . e(format_number($r['scheduled_days'])) ?></td>
                        <td><?= ui_badge(MD_SOURCES[$r['source']] ?? $r['source'], $r['source'] === 'import' ? 'info' : 'neutral') ?></td>
                        <td class="col-actions">
                            <?= ui_row_action('detail', 'Lihat detail', 'eye') ?>
                            <?php if ($canManage): ?><?= ui_row_action('edit', 'Edit', 'pencil') ?><?= ui_row_action('delete', 'Hapus', 'trash-2', 'is-danger') ?><?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        <?= ui_pagination($total['records'], $pageNo, $req['per'], $path) ?>
        <?php endif; ?>
    </div>
</section>

<?= ui_detail_dialog() ?>
<?php if ($canManage): ?>
<?= ui_confirm_dialog(url('modules/mandays/delete.php'), $returnQs) ?>
<dialog class="modal modal-lg" id="formDialog" data-title-create="Tambah record mandays" data-title-edit="Edit record mandays" aria-labelledby="formTitle">
    <form method="post" action="<?= e(url('modules/mandays/save.php')) ?>" id="entityForm">
        <?= csrf_field() ?><input type="hidden" name="id" value=""><input type="hidden" name="return_qs" value="<?= e($returnQs) ?>">
        <div class="modal-head"><h3 id="formTitle">Tambah record mandays</h3><button type="button" class="icon-btn" data-close aria-label="Tutup"><?= icon('x') ?></button></div>
        <div class="modal-body form-grid">
            <div class="field field-full"><label for="f_employee_id">Tenaga kerja <b class="req">*</b></label>
                <select id="f_employee_id" name="employee_id" class="form-select" required>
                    <option value="">Pilih tenaga kerja</option>
                    <?php foreach ($employees as $emp) echo '<option value="' . e($emp['id']) . '">' . e($emp['employee_code'] . ' — ' . $emp['full_name'] . ' (' . $emp['dept'] . ')') . '</option>'; ?>
                </select>
                <small class="field-hint" id="lockHint" hidden>Tenaga kerja dan periode tidak dapat diubah. Hapus dan buat ulang bila salah.</small>
                <p class="field-error" data-error-for="employee_id"></p></div>
            <div class="field"><label for="f_period">Periode (bulan) <b class="req">*</b></label>
                <input id="f_period" name="period" type="month" required placeholder="YYYY-MM" pattern="\d{4}-\d{2}" max="<?= e(date('Y-m')) ?>"><small class="field-hint">Tenaga kerja harus aktif pada bulan ini.</small><p class="field-error" data-error-for="period"></p></div>
            <div class="field"><label for="f_mandays">Mandays (hari) <b class="req">*</b></label>
                <input id="f_mandays" name="mandays" inputmode="decimal" required placeholder="mis. 21 atau 20,5"><small class="field-hint">0 sampai jumlah hari pada bulan tersebut.</small><p class="field-error" data-error-for="mandays"></p></div>
            <div class="field"><label for="f_scheduled_days">Hari kerja terjadwal</label>
                <input id="f_scheduled_days" name="scheduled_days" inputmode="decimal" placeholder="Kosongkan bila tidak tersedia"><p class="field-error" data-error-for="scheduled_days"></p></div>
            <div class="field"><label for="f_attended_days">Hari hadir</label>
                <input id="f_attended_days" name="attended_days" inputmode="decimal" placeholder="Kosongkan bila tidak tersedia"><small class="field-hint">Isi berpasangan dengan hari terjadwal. Jangan diisi dengan perkiraan.</small><p class="field-error" data-error-for="attended_days"></p></div>
            <div class="field field-full"><label for="f_notes">Keterangan</label><input id="f_notes" name="notes" maxlength="255"><p class="field-error" data-error-for="notes"></p></div>
        </div>
        <div class="modal-foot"><button type="button" class="btn btn-outline" data-close>Batal</button><button type="submit" class="btn btn-primary">Simpan</button></div>
    </form>
</dialog>
<?php endif; ?>
<script type="application/json" id="formState"><?= json_encode($formState, JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_UNESCAPED_UNICODE) ?></script>
<?php require BASE_PATH . '/includes/footer.php'; ?>
