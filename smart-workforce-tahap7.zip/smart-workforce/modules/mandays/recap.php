<?php
/** Rekap mandays per bulan, departemen, dan vendor + grafik tren. */
declare(strict_types=1);
require_once dirname(__DIR__, 2) . '/includes/bootstrap.php';
require_once dirname(__DIR__) . '/employees/repo.php';

$user = require_permission('mandays.view');
$path = 'modules/mandays/recap.php';

$f      = stats_parse_filters();
$f['status'] = '';                                   // rekap tidak memakai filter status
$months = stats_months($f['from'], $f['to']);
$opts   = stats_filter_options();
foreach ([$f['from'], $f['to']] as $m) { if (!in_array($m, $opts['months'], true)) { $opts['months'][] = $m; } }
rsort($opts['months']);

$prior  = stats_shift_month($f['from'], -1);
$series = stats_mandays_series(array_merge([$prior], $months), $f);       // bulan sebelum rentang dipakai sebagai pembanding bulan pertama
$totals = stats_mandays_totals($f['from'], $f['to'], $f);
$byDept = stats_mandays_by_group($f['from'], $f['to'], $f, 'department');
$byVend = stats_mandays_by_group($f['from'], $f['to'], $f, 'vendor');
$hasFilter = $f['dept'] > 0 || $f['vendor'] > 0 || $f['category'] !== '' || $f['from'] !== stats_shift_month(stats_latest_month(), -(STATS_DEFAULT_MONTHS - 1)) || $f['to'] !== stats_latest_month();
$rangeLabel = month_label($f['from']) . ($f['from'] === $f['to'] ? '' : ' – ' . month_label($f['to']));

$labels = $avg = $sum = [];
foreach ($months as $m) {
    $s = $series[$m];
    $labels[] = month_label($m, true);
    $sum[]    = $s['mandays'];
    $avg[]    = $s['records'] > 0 ? round($s['mandays'] / $s['records'], 2) : null;
}
$charts = ['charts' => [[
    'id' => 'chartTrend', 'type' => 'bar', 'labels' => $labels, 'emptyText' => 'Belum ada mandays pada rentang ini',
    'yTitle' => 'Total mandays (hari)', 'y1Title' => 'Rata-rata per record (hari)',
    'datasets' => [
        ['label' => 'Total mandays', 'data' => $sum, 'color' => '#1C2541', 'unit' => ' hari'],
        ['label' => 'Rata-rata per record', 'data' => $avg, 'color' => '#3A86FF', 'kind' => 'line', 'axis' => 'y1', 'unit' => ' hari'],
    ],
]]];

$page = ['title' => 'Rekap Mandays', 'active' => 'mandays', 'breadcrumb' => ['Workforce Management', 'Mandays & Kehadiran', 'Rekap & tren'], 'css' => ['crud.css'], 'js' => ['page-charts.js'], 'chart' => true];
require BASE_PATH . '/includes/header.php';
$opt = fn ($v, $cur, $label) => '<option value="' . e($v) . '"' . ((string) $v === (string) $cur ? ' selected' : '') . '>' . e($label) . '</option>';
?>
<section class="crud-page">
    <div class="page-header">
        <div><h1>Mandays & Kehadiran</h1><p class="page-sub">Rekap dan tren mandays untuk <?= e($rangeLabel) ?>.</p></div>
    </div>

    <?= ui_tabs([['records', 'Record', 'modules/mandays/index.php'], ['recap', 'Rekap & tren', 'modules/mandays/recap.php']], 'recap') ?>

    <?php foreach ($f['notices'] as $n): ?><div class="notice notice-warning"><?= icon('info') ?><div><?= e($n) ?></div></div><?php endforeach; ?>

    <form class="card analytics-filter" method="get" action="<?= e(url($path)) ?>">
        <label class="filter"><span>Dari bulan</span><select name="from" class="form-select" data-autosubmit><?php foreach ($opts['months'] as $ym) echo $opt($ym, $f['from'], month_label($ym)); ?></select></label>
        <label class="filter"><span>Sampai bulan</span><select name="to" class="form-select" data-autosubmit><?php foreach ($opts['months'] as $ym) echo $opt($ym, $f['to'], month_label($ym)); ?></select></label>
        <label class="filter"><span>Departemen</span><select name="dept" class="form-select" data-autosubmit><option value="">Semua</option><?php foreach ($opts['departments'] as $d) echo $opt($d['id'], $f['dept'], $d['name']); ?></select></label>
        <label class="filter"><span>Vendor</span><select name="vendor" class="form-select" data-autosubmit><option value="">Semua</option><?php foreach ($opts['vendors'] as $v) echo $opt($v['id'], $f['vendor'], $v['name']); ?></select></label>
        <label class="filter"><span>Kategori</span><select name="category" class="form-select" data-autosubmit><option value="">Semua</option><?php foreach (EMP_CATEGORIES as $k => $l) echo $opt($k, $f['category'], $l); ?></select></label>
        <?php if ($hasFilter): ?><div class="filter-actions"><a class="btn btn-outline btn-sm" href="<?= e(url($path)) ?>"><?= icon('rotate-ccw') ?>Reset</a></div><?php endif; ?>
    </form>

    <div class="mini-stats">
        <?= ui_mini_stat('Total mandays', format_number($totals['mandays']) . ' hari', $rangeLabel) ?>
        <?= ui_mini_stat('Jumlah record', format_number($totals['records']), count($months) . ' bulan') ?>
        <?= ui_mini_stat('Tenaga kerja tercatat', format_number($totals['workers']), 'unik pada rentang') ?>
        <?= ui_mini_stat('Rata-rata per record', $totals['records'] > 0 ? format_number($totals['mandays'] / $totals['records']) . ' hari' : '—', 'mandays ÷ record') ?>
    </div>

    <article class="card chart-card section-card">
        <header class="card-head"><div><h2>Tren mandays per bulan</h2><p>Total mandays (batang) dan rata-rata per record (garis)</p></div></header>
        <div class="chart-box"><canvas id="chartTrend" role="img" aria-label="Grafik tren mandays per bulan"></canvas><div class="chart-empty" hidden><?= icon('inbox') ?><span>Belum ada mandays pada rentang ini</span></div></div>
    </article>

    <article class="card table-card section-card">
        <header class="card-head" style="padding:18px 22px 0"><div><h2>Rekap per bulan</h2><p>Perubahan dibandingkan bulan sebelumnya; "—" bila bulan sebelumnya tidak memiliki record</p></div></header>
        <div class="table-scroll"><table class="table">
            <thead><tr><th>Bulan</th><th class="num">Record</th><th class="num">Tenaga kerja</th><th class="num">Total mandays</th><th class="num">Rata-rata/record</th><th class="num">Data kehadiran</th><th>Perubahan mandays</th></tr></thead>
            <tbody>
            <?php $prevKey = $prior; foreach (array_reverse($months) as $m):
                $s = $series[$m]; $p = $series[stats_shift_month($m, -1)] ?? ['records' => 0, 'mandays' => 0.0]; ?>
                <tr>
                    <td><strong><?= e(month_label($m)) ?></strong></td>
                    <td class="num"><?= e(format_number($s['records'])) ?></td>
                    <td class="num"><?= e(format_number($s['workers'])) ?></td>
                    <td class="num"><strong><?= e(format_number($s['mandays'])) ?></strong></td>
                    <td class="num"><?= $s['records'] > 0 ? e(format_number($s['mandays'] / $s['records'])) : '—' ?></td>
                    <td class="num"><?= $s['records'] > 0 ? e(format_number($s['with_attendance'] / $s['records'] * 100, 0)) . '%' : '—' ?></td>
                    <td><?= ($s['records'] > 0 && $p['records'] > 0) ? ui_change($s['mandays'], $p['mandays']) : '<span class="muted-dash">—</span>' ?></td>
                </tr>
            <?php endforeach; ?>
            </tbody>
            <tfoot><tr><td>Total rentang</td><td class="num"><?= e(format_number($totals['records'])) ?></td><td class="num"><?= e(format_number($totals['workers'])) ?></td><td class="num"><?= e(format_number($totals['mandays'])) ?></td><td class="num"><?= $totals['records'] > 0 ? e(format_number($totals['mandays'] / $totals['records'])) : '—' ?></td><td class="num"><?= $totals['records'] > 0 ? e(format_number($totals['with_attendance'] / $totals['records'] * 100, 0)) . '%' : '—' ?></td><td></td></tr></tfoot>
        </table></div>
    </article>

    <div class="chart-grid">
        <?php foreach ([['Rekap per departemen', $byDept, 'Departemen'], ['Rekap per vendor', $byVend, 'Vendor']] as [$title, $rows, $col]): ?>
        <article class="card table-card chart-card">
            <header class="card-head" style="padding:18px 22px 0"><div><h2><?= e($title) ?></h2><p><?= e($rangeLabel) ?><?= $col === 'Vendor' ? ' · hanya TAD yang memiliki vendor' : '' ?></p></div></header>
            <?php if (!$rows): ?>
                <?= ui_empty_state('inbox', 'Belum ada data', 'Tidak ada mandays pada rentang dan filter ini.') ?>
            <?php else: ?>
            <div class="table-scroll"><table class="table">
                <thead><tr><th><?= e($col) ?></th><th class="num">Tenaga kerja</th><th class="num">Record</th><th class="num">Mandays</th></tr></thead>
                <tbody><?php foreach ($rows as $r): ?>
                    <tr><td><strong><?= e($r['name']) ?></strong><span class="cell-sub"><?= e($r['code']) ?></span></td><td class="num"><?= e(format_number($r['workers'])) ?></td><td class="num"><?= e(format_number($r['records'])) ?></td><td class="num"><strong><?= e(format_number($r['mandays'])) ?></strong></td></tr>
                <?php endforeach; ?></tbody>
                <tfoot><tr><td>Subtotal</td><td class="num"></td><td class="num"><?= e(format_number(array_sum(array_column($rows, 'records')))) ?></td><td class="num"><?= e(format_number(array_sum(array_column($rows, 'mandays')))) ?></td></tr></tfoot>
            </table></div>
            <?php endif; ?>
        </article>
        <?php endforeach; ?>
    </div>
</section>
<script type="application/json" id="chartData"><?= json_encode($charts, JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_UNESCAPED_UNICODE) ?></script>
<?php require BASE_PATH . '/includes/footer.php'; ?>
