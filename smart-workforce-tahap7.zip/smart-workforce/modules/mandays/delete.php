<?php
declare(strict_types=1);
require_once dirname(__DIR__, 2) . '/includes/bootstrap.php';
require_once __DIR__ . '/repo.php';

$user = require_permission('mandays.manage');
if (!is_post()) {
    redirect('modules/mandays/index.php');
}
csrf_require();

$back = 'modules/mandays/index.php';
$rqs  = $_POST['return_qs'] ?? '';
$id   = (isset($_POST['id']) && ctype_digit((string) $_POST['id'])) ? (int) $_POST['id'] : 0;
$rec  = $id > 0 ? md_find($id) : null;
if ($rec === null) {
    flash_set('danger', 'Record mandays tidak ditemukan atau sudah dihapus.');
    redirect_to_list($back, $rqs);
}

db_run('DELETE FROM workforce_records WHERE id = ?', 'i', [$id]);
audit_log('delete', 'workforce_record', $id, 'Menghapus mandays pegawai #' . $rec['employee_id'] . ' periode ' . substr($rec['period_month'], 0, 7), (int) $user['id']);
flash_set('success', 'Record mandays periode ' . month_label($rec['period_month']) . ' berhasil dihapus.');
redirect_to_list($back, $rqs);
