<?php
/**
 * Data & aturan bisnis modul Tenaga Kerja.
 *
 * KEBIJAKAN:
 *  - Vendor WAJIB untuk TAD dan DILARANG untuk kategori lain.
 *  - Peserta magang WAJIB punya tanggal berakhir.
 *  - Status selain "Aktif" WAJIB punya tanggal berakhir; status "Aktif" tidak boleh berakhir di masa lalu.
 *  - Penghapusan DITOLAK jika tenaga kerja masih memiliki record mandays (gunakan status Tidak aktif/Selesai).
 */
declare(strict_types=1);

const EMP_CATEGORIES = ['employee' => 'Karyawan', 'tad' => 'TAD', 'intern' => 'Peserta magang'];
const EMP_STATUSES   = ['active' => 'Aktif', 'inactive' => 'Tidak aktif', 'completed' => 'Selesai'];
const EMP_PREFIX     = ['employee' => 'EMP', 'tad' => 'TAD', 'intern' => 'INT'];
const EMP_SORT = [
    'code'       => 'e.employee_code',
    'name'       => 'e.full_name',
    'category'   => 'e.category',
    'department' => 'd.name',
    'vendor'     => 'v.name',
    'start'      => 'e.start_date',
    'status'     => 'e.status',
];
const EMP_FORM_FIELDS = ['employee_code', 'full_name', 'category', 'department_id', 'vendor_id', 'position', 'start_date', 'end_date', 'status', 'notes'];

function emp_status_variant(string $s): string
{
    return ['active' => 'success', 'inactive' => 'neutral', 'completed' => 'info'][$s] ?? 'neutral';
}

/** Filter dari query string (nilai tidak valid diabaikan). */
function emp_filters(): array
{
    $g = fn (string $k): string => (isset($_GET[$k]) && is_string($_GET[$k])) ? trim($_GET[$k]) : '';
    $f = [
        'q'          => mb_substr($g('q'), 0, 100),
        'category'   => array_key_exists($g('category'), EMP_CATEGORIES) ? $g('category') : '',
        'department' => ctype_digit($g('department')) ? (int) $g('department') : 0,
        'vendor'     => ctype_digit($g('vendor')) ? (int) $g('vendor') : 0,
        'status'     => array_key_exists($g('status'), EMP_STATUSES) ? $g('status') : '',
    ];
    return $f;
}

/** @return array{0:string,1:string,2:array} [WHERE sql, types, params] */
function emp_where(array $f): array
{
    $w = [];
    $types = '';
    $params = [];
    if ($f['q'] !== '') {
        $like = '%' . like_escape($f['q']) . '%';
        $w[] = '(e.full_name LIKE ? OR e.employee_code LIKE ? OR e.position LIKE ?)';
        $types .= 'sss';
        array_push($params, $like, $like, $like);
    }
    if ($f['category'] !== '') { $w[] = 'e.category = ?'; $types .= 's'; $params[] = $f['category']; }
    if ($f['department'] > 0)  { $w[] = 'e.department_id = ?'; $types .= 'i'; $params[] = $f['department']; }
    if ($f['vendor'] > 0)      { $w[] = 'e.vendor_id = ?'; $types .= 'i'; $params[] = $f['vendor']; }
    if ($f['status'] !== '')   { $w[] = 'e.status = ?'; $types .= 's'; $params[] = $f['status']; }
    return [$w ? 'WHERE ' . implode(' AND ', $w) : '', $types, $params];
}

const EMP_FROM = 'FROM employees e JOIN departments d ON d.id = e.department_id LEFT JOIN vendors v ON v.id = e.vendor_id';

function emp_count(array $f): int
{
    [$where, $types, $params] = emp_where($f);
    return (int) db_value('SELECT COUNT(*) ' . EMP_FROM . ' ' . $where, $types, $params);
}

function emp_list(array $f, array $req, int $page): array
{
    [$where, $types, $params] = emp_where($f);
    $sql = "SELECT e.*, d.name AS department_name, d.code AS department_code, v.name AS vendor_name,
                   (SELECT COUNT(*) FROM workforce_records r WHERE r.employee_id = e.id) AS records_count
            " . EMP_FROM . " {$where}
            ORDER BY {$req['order_sql']}, e.id ASC LIMIT ? OFFSET ?";
    return db_fetch_all($sql, $types . 'ii', array_merge($params, [$req['per'], ($page - 1) * $req['per']]));
}

/** Generator baris untuk ekspor (semua hasil filter, tanpa pagination). */
function emp_export_rows(array $f): Generator
{
    [$where, $types, $params] = emp_where($f);
    $rows = db_fetch_all(
        "SELECT e.*, d.name AS department_name, v.name AS vendor_name " . EMP_FROM . " {$where} ORDER BY e.employee_code ASC LIMIT 50000",
        $types,
        $params
    );
    foreach ($rows as $r) {
        yield [
            $r['employee_code'], $r['full_name'], EMP_CATEGORIES[$r['category']] ?? $r['category'], $r['department_name'],
            $r['vendor_name'] ?? '', $r['position'] ?? '', $r['start_date'], $r['end_date'] ?? '',
            EMP_STATUSES[$r['status']] ?? $r['status'], $r['notes'] ?? '',
        ];
    }
}

function emp_find(int $id): ?array
{
    return db_fetch_one('SELECT * FROM employees WHERE id = ?', 'i', [$id]);
}

/** Data satu baris untuk JavaScript: nilai form (raw) dan pasangan label-nilai untuk dialog detail. */
function emp_record(array $r): array
{
    $raw = [];
    foreach (EMP_FORM_FIELDS as $k) {
        $raw[$k] = (string) ($r[$k] ?? '');
    }
    $raw['id'] = (string) $r['id'];
    return [
        'raw'   => $raw,
        'title' => $r['full_name'],
        'name'  => $r['employee_code'] . ' — ' . $r['full_name'],
        'details' => [
            ['ID internal', $r['employee_code']],
            ['Nama lengkap', $r['full_name']],
            ['Kategori', EMP_CATEGORIES[$r['category']] ?? $r['category']],
            ['Departemen', $r['department_name']],
            ['Vendor', $r['vendor_name'] ?? '-'],
            ['Jabatan', $r['position'] ?: '-'],
            ['Tanggal mulai', fmt_date($r['start_date'])],
            ['Tanggal berakhir', fmt_date($r['end_date'])],
            ['Status', EMP_STATUSES[$r['status']] ?? $r['status']],
            ['Record mandays', (string) $r['records_count'] . ' bulan tercatat'],
            ['Catatan', $r['notes'] ?: '-'],
            ['Dibuat', format_datetime($r['created_at'])],
            ['Diperbarui', format_datetime($r['updated_at'])],
        ],
    ];
}

/** Kode berikutnya, mis. EMP-0071 (berdasarkan angka terbesar pada prefix kategori). */
function emp_next_code(string $category): string
{
    $prefix = EMP_PREFIX[$category] ?? 'EMP';
    $max = (int) db_value(
        'SELECT COALESCE(MAX(CAST(SUBSTRING(employee_code, ?) AS UNSIGNED)), 0) FROM employees WHERE employee_code REGEXP ?',
        'is',
        [strlen($prefix) + 2, '^' . $prefix . '-[0-9]+$']
    );
    return sprintf('%s-%04d', $prefix, $max + 1);
}

/**
 * Validasi input form. Mengembalikan [data bersih, errors[field => pesan]].
 * $existing = baris lama saat edit (untuk aturan "tidak mengubah ke departemen/vendor nonaktif").
 */
function emp_validate(array $in, ?array $existing): array
{
    $s = fn (string $k, int $max = 255): string => (isset($in[$k]) && is_string($in[$k])) ? mb_substr(trim($in[$k]), 0, $max) : '';
    $e = [];

    $c = [
        'employee_code' => strtoupper($s('employee_code', 30)),
        'full_name'     => preg_replace('/\s+/', ' ', $s('full_name', 150)),
        'category'      => $s('category', 20),
        'department_id' => $s('department_id', 10),
        'vendor_id'     => $s('vendor_id', 10),
        'position'      => $s('position', 120),
        'start_date'    => $s('start_date', 10),
        'end_date'      => $s('end_date', 10),
        'status'        => $s('status', 20),
        'notes'         => $s('notes', 2000),
    ];
    $existingId = $existing ? (int) $existing['id'] : null;

    // Kode (opsional saat tambah: dibuat otomatis)
    if ($c['employee_code'] !== '') {
        if (!preg_match('/^[A-Z0-9][A-Z0-9._-]{1,29}$/', $c['employee_code'])) {
            $e['employee_code'] = 'Kode hanya boleh huruf, angka, titik, strip, atau garis bawah (2–30 karakter).';
        } elseif (!is_unique_value('employees', 'employee_code', $c['employee_code'], $existingId)) {
            $e['employee_code'] = 'Kode sudah dipakai tenaga kerja lain.';
        }
    } elseif ($existing) {
        $e['employee_code'] = 'Kode wajib diisi.';
    }

    if (!val_len($c['full_name'], 2, 150)) {
        $e['full_name'] = 'Nama lengkap wajib diisi (2–150 karakter).';
    }
    if (!array_key_exists($c['category'], EMP_CATEGORIES)) {
        $e['category'] = 'Pilih kategori yang valid.';
    }
    if (!array_key_exists($c['status'], EMP_STATUSES)) {
        $e['status'] = 'Pilih status yang valid.';
    }
    if (!val_len($c['position'], 2, 120)) {
        $e['position'] = 'Jabatan wajib diisi (2–120 karakter).';
    }

    // Departemen
    $deptId = ctype_digit($c['department_id']) ? (int) $c['department_id'] : 0;
    $dept = $deptId > 0 ? db_fetch_one('SELECT id, status FROM departments WHERE id = ?', 'i', [$deptId]) : null;
    if ($dept === null) {
        $e['department_id'] = 'Pilih departemen yang valid.';
    } elseif ($dept['status'] !== 'active' && (!$existing || (int) $existing['department_id'] !== $deptId)) {
        $e['department_id'] = 'Departemen nonaktif tidak dapat dipilih.';
    }

    // Vendor
    $vendorId = ctype_digit($c['vendor_id']) ? (int) $c['vendor_id'] : 0;
    if ($c['category'] === 'tad') {
        $vendor = $vendorId > 0 ? db_fetch_one('SELECT id, status FROM vendors WHERE id = ?', 'i', [$vendorId]) : null;
        if ($vendor === null) {
            $e['vendor_id'] = 'Vendor wajib dipilih untuk TAD.';
        } elseif ($vendor['status'] !== 'active' && (!$existing || (int) ($existing['vendor_id'] ?? 0) !== $vendorId)) {
            $e['vendor_id'] = 'Vendor nonaktif tidak dapat dipilih.';
        }
    } elseif ($c['vendor_id'] !== '') {
        $e['vendor_id'] = 'Vendor hanya berlaku untuk kategori TAD.';
    }

    // Tanggal
    $start = val_date($c['start_date']);
    $end   = $c['end_date'] === '' ? null : val_date($c['end_date']);
    if ($start === null) {
        $e['start_date'] = 'Tanggal mulai wajib diisi dengan format yang valid.';
    }
    if ($c['end_date'] !== '' && $end === null) {
        $e['end_date'] = 'Format tanggal berakhir tidak valid.';
    } elseif ($start !== null && $end !== null && $end < $start) {
        $e['end_date'] = 'Tanggal berakhir tidak boleh sebelum tanggal mulai.';
    } elseif ($c['category'] === 'intern' && $end === null) {
        $e['end_date'] = 'Peserta magang wajib memiliki tanggal berakhir.';
    } elseif (isset($c['status']) && $c['status'] !== 'active' && array_key_exists($c['status'], EMP_STATUSES) && $end === null) {
        $e['end_date'] = 'Status ' . mb_strtolower(EMP_STATUSES[$c['status']]) . ' memerlukan tanggal berakhir.';
    } elseif ($c['status'] === 'active' && $end !== null && $end < date('Y-m-d')) {
        $e['end_date'] = 'Tanggal berakhir sudah lewat; ubah status menjadi Tidak aktif atau Selesai.';
    }

    $clean = [
        'employee_code' => $c['employee_code'],
        'full_name'     => $c['full_name'],
        'category'      => $c['category'],
        'department_id' => $deptId,
        'vendor_id'     => $c['category'] === 'tad' && $vendorId > 0 ? $vendorId : null,
        'position'      => $c['position'],
        'start_date'    => $start,
        'end_date'      => $end,
        'status'        => $c['status'],
        'notes'         => null_if_empty($c['notes']),
    ];
    return [$clean, $e];
}
