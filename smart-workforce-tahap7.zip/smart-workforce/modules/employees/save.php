<?php
declare(strict_types=1);
require_once dirname(__DIR__, 2) . '/includes/bootstrap.php';
require_once __DIR__ . '/repo.php';

$user = require_permission('employees.manage');
if (!is_post()) {
    redirect('modules/employees/index.php');
}
csrf_require();

$back = 'modules/employees/index.php';
$rqs  = $_POST['return_qs'] ?? '';
$id   = (isset($_POST['id']) && ctype_digit((string) $_POST['id'])) ? (int) $_POST['id'] : 0;

$existing = null;
if ($id > 0) {
    $existing = emp_find($id);
    if ($existing === null) {
        flash_set('danger', 'Data tenaga kerja tidak ditemukan atau sudah dihapus.');
        redirect_to_list($back, $rqs);
    }
}

[$d, $errors] = emp_validate($_POST, $existing);

$fail = function (array $errors) use ($existing, $id, $rqs, $back): void {
    form_state_set('employees', ['mode' => $existing ? 'edit' : 'create', 'id' => $id, 'old' => post_old_input(EMP_FORM_FIELDS), 'errors' => $errors]);
    flash_set('warning', 'Periksa kembali isian formulir.');
    redirect_to_list($back, $rqs);
};
if ($errors) {
    $fail($errors);
}

$cols = ['full_name', 'category', 'department_id', 'vendor_id', 'position', 'start_date', 'end_date', 'status', 'notes'];

try {
    if ($existing) {
        $sets = 'employee_code = ?, ' . implode(' = ?, ', $cols) . ' = ?';
        db_run(
            "UPDATE employees SET {$sets} WHERE id = ?",
            'sssiisssssi',
            [$d['employee_code'], $d['full_name'], $d['category'], $d['department_id'], $d['vendor_id'], $d['position'], $d['start_date'], $d['end_date'], $d['status'], $d['notes'], $id]
        );
        $changed = changed_fields($existing, $d);
        audit_log('update', 'employee', $id, 'Mengubah tenaga kerja ' . $d['employee_code'] . ($changed ? ' (kolom: ' . implode(', ', $changed) . ')' : ' (tanpa perubahan)'), (int) $user['id']);
        flash_set('success', 'Data ' . $d['full_name'] . ' berhasil diperbarui.');
    } else {
        $attempts = 0;
        while (true) {
            $code = $d['employee_code'] !== '' ? $d['employee_code'] : emp_next_code($d['category']);
            try {
                db_run(
                    'INSERT INTO employees (employee_code, full_name, category, department_id, vendor_id, position, start_date, end_date, status, notes, created_by)
                     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)',
                    'sssiisssssi',
                    [$code, $d['full_name'], $d['category'], $d['department_id'], $d['vendor_id'], $d['position'], $d['start_date'], $d['end_date'], $d['status'], $d['notes'], (int) $user['id']]
                );
                break;
            } catch (mysqli_sql_exception $ex) {
                // Kode otomatis bentrok (dua pengguna menyimpan bersamaan): coba lagi dengan kode berikutnya.
                if (is_duplicate_error($ex) && $d['employee_code'] === '' && ++$attempts < 3) {
                    continue;
                }
                throw $ex;
            }
        }
        $newId = db_last_id();
        audit_log('create', 'employee', $newId, 'Menambah tenaga kerja ' . $code, (int) $user['id']);
        flash_set('success', 'Tenaga kerja ' . $d['full_name'] . ' (' . $code . ') berhasil ditambahkan.');
    }
} catch (Throwable $ex) {
    if (is_duplicate_error($ex)) {
        $fail(['employee_code' => 'Kode sudah dipakai tenaga kerja lain.']);
    }
    throw $ex;
}

redirect_to_list($back, $rqs);
