<?php
/** Ekspor CSV data tenaga kerja dengan filter yang sama seperti daftar. */
declare(strict_types=1);
require_once dirname(__DIR__, 2) . '/includes/bootstrap.php';
require_once __DIR__ . '/repo.php';

$user = require_permission('reports.export');
$f    = emp_filters();
$n    = emp_count($f);

audit_log('export', 'employee', null, "Ekspor CSV tenaga kerja ({$n} baris)", (int) $user['id']);
csv_download(
    'tenaga-kerja_' . date('Ymd-His') . '.csv',
    ['ID Internal', 'Nama Lengkap', 'Kategori', 'Departemen', 'Vendor', 'Jabatan', 'Tanggal Mulai', 'Tanggal Berakhir', 'Status', 'Catatan'],
    emp_export_rows($f)
);
