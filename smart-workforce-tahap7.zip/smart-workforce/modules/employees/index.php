<?php
declare(strict_types=1);
require_once dirname(__DIR__, 2) . '/includes/bootstrap.php';
require_once __DIR__ . '/repo.php';

$user      = require_permission('employees.view');
$canManage = user_can('employees.manage', $user);
$canExport = user_can('reports.export', $user);
$path      = 'modules/employees/index.php';

$f     = emp_filters();
$req   = list_request(EMP_SORT, 'code', 'asc');
$total = emp_count($f);
$pageNo = list_clamp_page($total, $req['page'], $req['per']);
$rows   = emp_list($f, $req, $pageNo);

$departments = db_fetch_all('SELECT id, name, status FROM departments ORDER BY name');
$vendors     = db_fetch_all('SELECT id, name, status FROM vendors ORDER BY name');
$hasFilter   = $f['q'] !== '' || $f['category'] !== '' || $f['department'] > 0 || $f['vendor'] > 0 || $f['status'] !== '';
$totalAll    = $hasFilter ? (int) db_value('SELECT COUNT(*) FROM employees') : $total;
$formState   = form_state_pull('employees');
$returnQs    = safe_return_qs($_SERVER['QUERY_STRING'] ?? '');

$page = [
    'title' => 'Data Tenaga Kerja', 'active' => 'employees',
    'breadcrumb' => ['Workforce Management', 'Data Tenaga Kerja'],
    'css' => ['crud.css'], 'js' => ['crud.js', 'employees.js'],
];
require BASE_PATH . '/includes/header.php';

$opt = fn ($v, $cur, $label, $disabled = false) => '<option value="' . e($v) . '"' . ((string) $v === (string) $cur ? ' selected' : '') . ($disabled ? ' disabled' : '') . '>' . e($label) . '</option>';
?>
<section class="crud-page" id="crudPage">
    <div class="page-header">
        <div>
            <h1>Data Tenaga Kerja</h1>
            <p class="page-sub">Kelola karyawan, tenaga alih daya (TAD), dan peserta magang.</p>
        </div>
        <div class="page-actions">
            <?php if ($canExport): ?>
                <a class="btn btn-outline" href="<?= e(url('modules/employees/export.php') . (($_SERVER['QUERY_STRING'] ?? '') !== '' ? '?' . safe_return_qs($_SERVER['QUERY_STRING']) : '')) ?>" title="Ekspor CSV sesuai filter saat ini"><?= icon('download') ?>Ekspor CSV</a>
            <?php endif; ?>
            <?php if ($canManage): ?>
                <button type="button" class="btn btn-primary" data-action="create"><?= icon('plus') ?>Tambah tenaga kerja</button>
            <?php endif; ?>
        </div>
    </div>

    <form class="card toolbar" method="get" action="<?= e(url($path)) ?>" id="filterForm">
        <input type="hidden" name="sort" value="<?= e($req['sort']) ?>"><input type="hidden" name="dir" value="<?= e($req['dir']) ?>">
        <label class="search-box">
            <?= icon('search') ?>
            <input type="search" name="q" value="<?= e($f['q']) ?>" placeholder="Cari nama, ID, atau jabatan…" maxlength="100" aria-label="Cari">
        </label>
        <select name="category" class="form-select" data-autosubmit aria-label="Kategori">
            <option value="">Semua kategori</option>
            <?php foreach (EMP_CATEGORIES as $k => $l) echo $opt($k, $f['category'], $l); ?>
        </select>
        <select name="department" class="form-select" data-autosubmit aria-label="Departemen">
            <option value="">Semua departemen</option>
            <?php foreach ($departments as $d) echo $opt($d['id'], $f['department'], $d['name'] . ($d['status'] === 'active' ? '' : ' (nonaktif)')); ?>
        </select>
        <select name="vendor" class="form-select" data-autosubmit aria-label="Vendor">
            <option value="">Semua vendor</option>
            <?php foreach ($vendors as $v) echo $opt($v['id'], $f['vendor'], $v['name'] . ($v['status'] === 'active' ? '' : ' (nonaktif)')); ?>
        </select>
        <select name="status" class="form-select" data-autosubmit aria-label="Status">
            <option value="">Semua status</option>
            <?php foreach (EMP_STATUSES as $k => $l) echo $opt($k, $f['status'], $l); ?>
        </select>
        <select name="per" class="form-select form-select-sm" data-autosubmit aria-label="Baris per halaman">
            <?php foreach (PER_PAGE_OPTIONS as $n) echo $opt($n, $req['per'], $n . ' / halaman'); ?>
        </select>
        <button type="submit" class="btn btn-outline btn-sm"><?= icon('search') ?>Cari</button>
        <?php if ($hasFilter): ?>
            <a class="btn btn-outline btn-sm" href="<?= e(url($path)) ?>"><?= icon('rotate-ccw') ?>Reset</a>
        <?php endif; ?>
    </form>

    <div class="card table-card">
        <?php if ($total === 0): ?>
            <?php if ($hasFilter): ?>
                <?= ui_empty_state('search', 'Tidak ada data yang cocok', 'Coba ubah kata kunci atau hapus sebagian filter.', '<a class="btn btn-outline btn-sm" href="' . e(url($path)) . '">Reset filter</a>') ?>
            <?php else: ?>
                <?= ui_empty_state('users', 'Belum ada data tenaga kerja', $canManage ? 'Mulai dengan menambahkan tenaga kerja pertama.' : 'Data akan tampil setelah ditambahkan oleh HC Staff atau Admin.') ?>
            <?php endif; ?>
        <?php else: ?>
        <div class="table-scroll">
            <table class="table table-hover">
                <thead><tr>
                    <?= ui_sort_th('ID', 'code', $req, $path) ?>
                    <?= ui_sort_th('Nama', 'name', $req, $path) ?>
                    <?= ui_sort_th('Kategori', 'category', $req, $path) ?>
                    <?= ui_sort_th('Departemen', 'department', $req, $path) ?>
                    <?= ui_sort_th('Vendor', 'vendor', $req, $path) ?>
                    <?= ui_sort_th('Periode', 'start', $req, $path) ?>
                    <?= ui_sort_th('Status', 'status', $req, $path) ?>
                    <th class="col-actions"><span class="sr-only">Aksi</span></th>
                </tr></thead>
                <tbody>
                <?php foreach ($rows as $r): $rec = emp_record($r); ?>
                    <tr data-record="<?= e(json_encode($rec, JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT)) ?>">
                        <td><code><?= e($r['employee_code']) ?></code></td>
                        <td><strong><?= e($r['full_name']) ?></strong><span class="cell-sub"><?= e($r['position'] ?: '-') ?></span></td>
                        <td><?= ui_badge(EMP_CATEGORIES[$r['category']] ?? $r['category'], $r['category'] === 'tad' ? 'info' : 'neutral') ?></td>
                        <td><?= e($r['department_name']) ?></td>
                        <td><?= e($r['vendor_name'] ?? '-') ?></td>
                        <td><?= e(fmt_date($r['start_date'])) ?><span class="cell-sub">s/d <?= e($r['end_date'] ? fmt_date($r['end_date']) : 'berjalan') ?></span></td>
                        <td><?= ui_badge(EMP_STATUSES[$r['status']] ?? $r['status'], emp_status_variant($r['status'])) ?></td>
                        <td class="col-actions">
                            <?= ui_row_action('detail', 'Lihat detail', 'eye') ?>
                            <?php if ($canManage): ?>
                                <?= ui_row_action('edit', 'Edit', 'pencil') ?>
                                <?= ui_row_action('delete', 'Hapus', 'trash-2', 'is-danger') ?>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        <?= ui_pagination($total, $pageNo, $req['per'], $path) ?>
        <?php endif; ?>
    </div>
</section>

<?= ui_detail_dialog() ?>

<?php if ($canManage): ?>
<?= ui_confirm_dialog(url('modules/employees/delete.php'), $returnQs) ?>

<dialog class="modal modal-lg" id="formDialog" data-title-create="Tambah tenaga kerja" data-title-edit="Edit tenaga kerja" aria-labelledby="formTitle">
    <form method="post" action="<?= e(url('modules/employees/save.php')) ?>" id="entityForm">
        <?= csrf_field() ?>
        <input type="hidden" name="id" value="">
        <input type="hidden" name="return_qs" value="<?= e($returnQs) ?>">
        <div class="modal-head"><h3 id="formTitle">Tambah tenaga kerja</h3><button type="button" class="icon-btn" data-close aria-label="Tutup"><?= icon('x') ?></button></div>
        <div class="modal-body form-grid">
            <div class="field"><label for="f_employee_code">ID internal</label>
                <input id="f_employee_code" name="employee_code" maxlength="30" placeholder="Kosongkan untuk dibuat otomatis" autocomplete="off">
                <small class="field-hint">Contoh: EMP-0071. Dibuat otomatis jika dikosongkan.</small><p class="field-error" data-error-for="employee_code"></p></div>
            <div class="field"><label for="f_full_name">Nama lengkap <b class="req">*</b></label>
                <input id="f_full_name" name="full_name" maxlength="150" required><p class="field-error" data-error-for="full_name"></p></div>
            <div class="field"><label for="f_category">Kategori <b class="req">*</b></label>
                <select id="f_category" name="category" class="form-select" required>
                    <option value="">Pilih kategori</option>
                    <?php foreach (EMP_CATEGORIES as $k => $l) echo '<option value="' . e($k) . '">' . e($l) . '</option>'; ?>
                </select><p class="field-error" data-error-for="category"></p></div>
            <div class="field"><label for="f_department_id">Departemen <b class="req">*</b></label>
                <select id="f_department_id" name="department_id" class="form-select" required>
                    <option value="">Pilih departemen</option>
                    <?php foreach ($departments as $d) echo '<option value="' . e($d['id']) . '">' . e($d['name'] . ($d['status'] === 'active' ? '' : ' (nonaktif)')) . '</option>'; ?>
                </select><p class="field-error" data-error-for="department_id"></p></div>
            <div class="field" id="vendorField"><label for="f_vendor_id">Vendor <b class="req" id="vendorReq" hidden>*</b></label>
                <select id="f_vendor_id" name="vendor_id" class="form-select">
                    <option value="">— Tidak berlaku —</option>
                    <?php foreach ($vendors as $v) echo '<option value="' . e($v['id']) . '">' . e($v['name'] . ($v['status'] === 'active' ? '' : ' (nonaktif)')) . '</option>'; ?>
                </select><small class="field-hint">Hanya untuk kategori TAD.</small><p class="field-error" data-error-for="vendor_id"></p></div>
            <div class="field"><label for="f_position">Jabatan / posisi <b class="req">*</b></label>
                <input id="f_position" name="position" maxlength="120" required><p class="field-error" data-error-for="position"></p></div>
            <div class="field"><label for="f_start_date">Tanggal mulai <b class="req">*</b></label>
                <input id="f_start_date" name="start_date" type="date" required><p class="field-error" data-error-for="start_date"></p></div>
            <div class="field"><label for="f_end_date">Tanggal berakhir <b class="req" id="endReq" hidden>*</b></label>
                <input id="f_end_date" name="end_date" type="date"><small class="field-hint" id="endHint">Wajib untuk peserta magang dan status selain Aktif.</small><p class="field-error" data-error-for="end_date"></p></div>
            <div class="field"><label for="f_status">Status <b class="req">*</b></label>
                <select id="f_status" name="status" class="form-select" required>
                    <?php foreach (EMP_STATUSES as $k => $l) echo '<option value="' . e($k) . '">' . e($l) . '</option>'; ?>
                </select><p class="field-error" data-error-for="status"></p></div>
            <div class="field field-full"><label for="f_notes">Catatan</label>
                <textarea id="f_notes" name="notes" rows="3" maxlength="2000"></textarea><p class="field-error" data-error-for="notes"></p></div>
        </div>
        <div class="modal-foot"><button type="button" class="btn btn-outline" data-close>Batal</button><button type="submit" class="btn btn-primary" id="formSubmit">Simpan</button></div>
    </form>
</dialog>
<?php endif; ?>

<script type="application/json" id="formState"><?= json_encode($formState, JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_UNESCAPED_UNICODE) ?></script>
<?php require BASE_PATH . '/includes/footer.php'; ?>
