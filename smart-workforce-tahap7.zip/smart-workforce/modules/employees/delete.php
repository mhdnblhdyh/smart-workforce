<?php
declare(strict_types=1);
require_once dirname(__DIR__, 2) . '/includes/bootstrap.php';
require_once __DIR__ . '/repo.php';

$user = require_permission('employees.manage');
if (!is_post()) {
    redirect('modules/employees/index.php');
}
csrf_require();

$back = 'modules/employees/index.php';
$rqs  = $_POST['return_qs'] ?? '';
$id   = (isset($_POST['id']) && ctype_digit((string) $_POST['id'])) ? (int) $_POST['id'] : 0;
$emp  = $id > 0 ? emp_find($id) : null;

if ($emp === null) {
    flash_set('danger', 'Data tenaga kerja tidak ditemukan atau sudah dihapus.');
    redirect_to_list($back, $rqs);
}

// Kebijakan: tenaga kerja dengan record mandays tidak boleh dihapus.
$records = (int) db_value('SELECT COUNT(*) FROM workforce_records WHERE employee_id = ?', 'i', [$id]);
if ($records > 0) {
    audit_log('delete_blocked', 'employee', $id, 'Penghapusan ditolak: ' . $emp['employee_code'] . " memiliki {$records} record mandays", (int) $user['id']);
    flash_set('danger', $emp['full_name'] . ' tidak dapat dihapus karena memiliki ' . $records . ' record mandays. Ubah statusnya menjadi Tidak aktif atau Selesai.');
    redirect_to_list($back, $rqs);
}

try {
    db_run('DELETE FROM employees WHERE id = ?', 'i', [$id]);
} catch (Throwable $e) {
    if (is_fk_error($e)) {
        flash_set('danger', $emp['full_name'] . ' tidak dapat dihapus karena masih direferensikan data lain.');
        redirect_to_list($back, $rqs);
    }
    throw $e;
}

audit_log('delete', 'employee', $id, 'Menghapus tenaga kerja ' . $emp['employee_code'], (int) $user['id']);
flash_set('success', 'Data ' . $emp['full_name'] . ' berhasil dihapus.');
redirect_to_list($back, $rqs);
