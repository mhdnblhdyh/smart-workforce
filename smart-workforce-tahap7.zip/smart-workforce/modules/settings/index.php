<?php
declare(strict_types=1);
require_once dirname(__DIR__, 2) . '/includes/bootstrap.php';
require_once __DIR__ . '/repo.php';

$user    = require_permission('settings.manage');
$current = settings_current();
$state   = form_state_pull('settings');
$old     = $state['old'] ?? [];
$errors  = $state['errors'] ?? [];
$limitMb = php_upload_limit_mb();
$info    = settings_system_info();

$page = ['title' => 'Pengaturan', 'active' => 'settings', 'breadcrumb' => ['Administration', 'Pengaturan'], 'css' => ['crud.css', 'settings.css']];
require BASE_PATH . '/includes/header.php';
?>
<section class="crud-page settings-page">
    <div class="page-header">
        <div><h1>Pengaturan</h1><p class="page-sub">Atur batas dan ambang yang dipakai aplikasi. Hanya Admin yang dapat mengubahnya; setiap perubahan dicatat di Activity Logs.</p></div>
    </div>

    <form class="card settings-form" method="post" action="<?= e(url('modules/settings/save.php')) ?>" novalidate>
        <?= csrf_field() ?>
        <div class="card-head"><div><h2>Parameter aplikasi</h2><p>Berlaku segera setelah disimpan.</p></div></div>
        <?php foreach (SETTING_DEFS as $key => $def):
            $val = $old[$key] ?? $current[$key]['value'];
            $err = $errors[$key] ?? '';
            $meta = $current[$key]['updated_at'] ? 'Diubah ' . format_datetime($current[$key]['updated_at']) . ($current[$key]['updated_by'] ? ' oleh ' . $current[$key]['updated_by'] : '') : 'Memakai nilai bawaan (' . $def['default'] . ')';
        ?>
        <div class="setting-row<?= $err !== '' ? ' has-error' : '' ?>">
            <div class="setting-text">
                <label for="s_<?= e($key) ?>"><?= e($def['label']) ?></label>
                <p><?= e($def['hint']) ?></p>
                <small class="setting-meta"><?= e($meta) ?></small>
            </div>
            <div class="setting-input">
                <div class="input-unit">
                    <input id="s_<?= e($key) ?>" name="<?= e($key) ?>" class="form-control" type="text" inputmode="numeric" pattern="[0-9]*" maxlength="6"
                           value="<?= e($val) ?>" required aria-describedby="e_<?= e($key) ?>"<?= $err !== '' ? ' aria-invalid="true"' : '' ?>>
                    <span><?= e($def['unit']) ?></span>
                </div>
                <small class="setting-range">Rentang <?= e(number_format($def['min'], 0, ',', '.')) ?>–<?= e(number_format($def['max'], 0, ',', '.')) ?> · bawaan <?= e((string) $def['default']) ?></small>
                <p class="field-error" id="e_<?= e($key) ?>" role="alert"><?= e($err) ?></p>
                <?php if ($key === 'import_max_file_mb' && $limitMb > 0 && (int) $val > $limitMb): ?>
                    <p class="setting-warn"><?= icon('triangle-alert') ?>Batas PHP saat ini hanya <?= e(format_number($limitMb, 1)) ?> MB; file lebih besar tetap ditolak server. Naikkan upload_max_filesize dan post_max_size di php.ini.</p>
                <?php endif; ?>
            </div>
        </div>
        <?php endforeach; ?>
        <div class="settings-foot"><button type="submit" class="btn btn-primary"><?= icon('circle-check') ?>Simpan pengaturan</button></div>
    </form>

    <div class="card">
        <div class="card-head"><div><h2>Informasi sistem</h2><p>Hanya-baca. Nilai ini berasal dari server dan file konfigurasi, bukan dari halaman ini.</p></div></div>
        <dl class="detail-list">
            <?php foreach ($info as $k => $v): ?><div><dt><?= e($k) ?></dt><dd><?= e((string) $v) ?></dd></div><?php endforeach; ?>
        </dl>
    </div>
</section>
<?php require BASE_PATH . '/includes/footer.php'; ?>
