<?php
/**
 * Pengaturan sistem (hanya Admin: izin settings.manage).
 *
 * Hanya pengaturan yang BENAR-BENAR dibaca aplikasi yang ditampilkan di sini. Nilai dibaca lewat setting_get()
 * (includes/domain.php) oleh: peringatan kontrak vendor/dashboard/notifikasi, dan batas import Excel.
 * Setiap perubahan dicatat di audit log (nilai lama -> baru). Validasi dilakukan di server; batas rentang
 * mencegah nilai yang membuat aplikasi tidak berguna atau membebani server.
 */
declare(strict_types=1);

const SETTING_DEFS = [
    'contract_warning_days' => [
        'label' => 'Masa peringatan kontrak vendor', 'unit' => 'hari', 'min' => 1, 'max' => 365, 'default' => 60,
        'hint'  => 'Kontrak vendor yang berakhir dalam jangka ini ditandai "Segera berakhir" di Vendor, Dashboard, dan notifikasi.',
    ],
    'import_max_file_mb' => [
        'label' => 'Ukuran maksimum file import', 'unit' => 'MB', 'min' => 1, 'max' => 50, 'default' => 10,
        'hint'  => 'Dibatasi juga oleh upload_max_filesize dan post_max_size di php.ini (lihat Informasi sistem).',
    ],
    'import_max_rows' => [
        'label' => 'Jumlah baris maksimum per import', 'unit' => 'baris', 'min' => 100, 'max' => 20000, 'default' => 5000,
        'hint'  => 'File dengan baris lebih banyak ditolak sebelum diproses. Nilai besar memerlukan memori PHP lebih banyak.',
    ],
];

/** Nilai tersimpan (langsung dari DB, bukan cache request) + metadata perubahan terakhir. */
function settings_current(): array
{
    $rows = db_fetch_all(
        'SELECT s.setting_key, s.setting_value, s.updated_at, u.name AS updated_by_name
         FROM settings s LEFT JOIN users u ON u.id = s.updated_by'
    );
    $byKey = [];
    foreach ($rows as $r) { $byKey[$r['setting_key']] = $r; }
    $out = [];
    foreach (SETTING_DEFS as $key => $def) {
        $r = $byKey[$key] ?? null;
        $out[$key] = [
            'value'      => ($r !== null && $r['setting_value'] !== null && $r['setting_value'] !== '') ? (string) $r['setting_value'] : (string) $def['default'],
            'stored'     => $r !== null,
            'updated_at' => $r['updated_at'] ?? null,
            'updated_by' => $r['updated_by_name'] ?? null,
        ];
    }
    return $out;
}

/** @return array{0: array<string,string>, 1: array<string,string>} [nilai bersih, galat per kunci] */
function settings_validate(array $post): array
{
    $clean = []; $errors = [];
    foreach (SETTING_DEFS as $key => $def) {
        $raw = (isset($post[$key]) && is_string($post[$key])) ? trim($post[$key]) : '';
        if ($raw === '') {
            $errors[$key] = $def['label'] . ' wajib diisi.';
        } elseif (!preg_match('/^[0-9]{1,6}$/', $raw)) {
            $errors[$key] = 'Isi dengan bilangan bulat positif (tanpa titik, koma, atau tanda lain).';
        } elseif ((int) $raw < $def['min'] || (int) $raw > $def['max']) {
            $errors[$key] = 'Nilai harus antara ' . number_format($def['min'], 0, ',', '.') . ' dan ' . number_format($def['max'], 0, ',', '.') . ' ' . $def['unit'] . '.';
        } else {
            $clean[$key] = (string) (int) $raw;   // normalisasi: "007" -> "7"
        }
    }
    return [$clean, $errors];
}

/**
 * Simpan dalam satu transaksi; hanya kunci yang nilainya berubah yang ditulis.
 * @return string[] deskripsi perubahan ("label: lama → baru")
 */
function settings_save(array $clean, array $current, int $actorId): array
{
    $changes = [];
    $conn = db();
    $conn->begin_transaction();
    try {
        foreach ($clean as $key => $value) {
            if (!isset(SETTING_DEFS[$key]) || $value === $current[$key]['value']) { continue; }
            db_run(
                'INSERT INTO settings (setting_key, setting_value, updated_by) VALUES (?, ?, ?)
                 ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value), updated_by = VALUES(updated_by)',
                'ssi',
                [$key, $value, $actorId]
            );
            $changes[] = $key . ': ' . $current[$key]['value'] . ' → ' . $value;
        }
        $conn->commit();
    } catch (Throwable $e) {
        $conn->rollback();
        throw $e;
    }
    return $changes;
}

/** Ukuran php.ini ("8M", "2G", "512K") -> byte. */
function ini_bytes(string $v): int
{
    $v = trim($v);
    if ($v === '' || !preg_match('/^(-?\d+)\s*([kmg]?)/i', $v, $m)) { return 0; }
    $n = (int) $m[1];
    return match (strtolower($m[2])) { 'g' => $n * 1073741824, 'm' => $n * 1048576, 'k' => $n * 1024, default => $n };
}

/** Batas unggahan efektif PHP (terkecil dari upload_max_filesize & post_max_size), dalam MB. 0 = tak terbatas. */
function php_upload_limit_mb(): float
{
    $a = ini_bytes((string) ini_get('upload_max_filesize'));
    $b = ini_bytes((string) ini_get('post_max_size'));
    $lim = array_filter([$a, $b], fn ($x) => $x > 0);
    return $lim ? min($lim) / 1048576 : 0.0;
}

/** Informasi sistem hanya-baca untuk Admin (tanpa kredensial atau path). */
function settings_system_info(): array
{
    $cache = BASE_PATH . '/storage/cache'; $imports = BASE_PATH . '/storage/imports';
    return [
        'Versi aplikasi'          => 'Tahap 7 (final)',
        'Lingkungan'              => (string) app_config('app_env'),
        'PHP'                     => PHP_VERSION,
        'Database'                => (string) (db()->server_info ?? '-'),
        'Zona waktu'              => (string) app_config('timezone'),
        'Batas unggah PHP'        => 'upload_max_filesize ' . ini_get('upload_max_filesize') . ' · post_max_size ' . ini_get('post_max_size'),
        'Batas memori PHP'        => (string) ini_get('memory_limit'),
        'Timeout sesi tidak aktif' => (int) (app_config('session.idle_timeout', 1800) / 60) . ' menit',
        'Penguncian login'        => (int) app_config('security.max_login_attempts', 5) . ' gagal → kunci ' . (int) app_config('security.lockout_minutes', 15) . ' menit',
        'Dompdf / PhpSpreadsheet' => (class_exists('Dompdf\\Dompdf') ? 'terpasang' : 'belum (jalankan composer install)') . ' / ' . (class_exists('PhpOffice\\PhpSpreadsheet\\Spreadsheet') ? 'terpasang' : 'belum'),
        'Folder storage/cache'    => is_writable($cache) ? 'dapat ditulis' : 'TIDAK dapat ditulis',
        'Folder storage/imports'  => is_writable($imports) ? 'dapat ditulis' : 'TIDAK dapat ditulis',
    ];
}
