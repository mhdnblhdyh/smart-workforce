<?php
declare(strict_types=1);
require_once dirname(__DIR__, 2) . '/includes/bootstrap.php';
require_once __DIR__ . '/repo.php';

$user = require_permission('settings.manage');
if (!is_post()) {
    redirect('modules/settings/index.php');
}
csrf_require();

$current = settings_current();
[$clean, $errors] = settings_validate($_POST);
if ($errors) {
    form_state_set('settings', ['old' => post_old_input(array_keys(SETTING_DEFS)), 'errors' => $errors]);
    flash_set('warning', 'Periksa kembali isian pengaturan. Tidak ada yang disimpan.');
    redirect('modules/settings/index.php');
}

$changes = settings_save($clean, $current, (int) $user['id']);
if ($changes) {
    audit_log('settings_update', 'settings', null, 'Mengubah pengaturan — ' . implode('; ', $changes), (int) $user['id']);
    flash_set('success', 'Pengaturan disimpan (' . count($changes) . ' perubahan).');
} else {
    flash_set('info', 'Tidak ada perubahan untuk disimpan.');
}
redirect('modules/settings/index.php');
