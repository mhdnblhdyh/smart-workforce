<?php
declare(strict_types=1);
require_once dirname(__DIR__, 2) . '/includes/bootstrap.php';
require_once dirname(__DIR__) . '/employees/repo.php';
require_once __DIR__ . '/schema.php';
require_once __DIR__ . '/reader.php';
require_once __DIR__ . '/repo.php';

$user = require_permission('import.run');
if (!is_post()) {
    redirect('modules/imports/index.php');
}
csrf_require();

$id = (isset($_POST['id']) && ctype_digit((string) $_POST['id'])) ? (int) $_POST['id'] : 0;
$batch = $id > 0 ? imp_batch_find($id) : null;
if ($batch === null || !in_array($batch['status'], ['uploaded', 'validated'], true)) {
    flash_set('danger', 'Batch tidak dapat dibatalkan.');
    redirect('modules/imports/index.php');
}
imp_delete_file($batch);
db_run("UPDATE import_batches SET status = 'cancelled', error_message = 'Dibatalkan oleh pengguna.' WHERE id = ?", 'i', [$id]);
audit_log('import_cancel', 'import_batch', $id, 'Membatalkan impor ' . $batch['original_name'], (int) $user['id']);
flash_set('success', 'Impor dibatalkan dan file sementara dihapus.');
redirect('modules/imports/index.php');
