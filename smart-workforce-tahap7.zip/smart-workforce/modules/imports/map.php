<?php
/** Langkah 2: pratinjau data + pemetaan kolom + kebijakan duplikat. POST = simpan pemetaan lalu validasi. */
declare(strict_types=1);
require_once dirname(__DIR__, 2) . '/includes/bootstrap.php';
require_once dirname(__DIR__) . '/employees/repo.php';
require_once __DIR__ . '/schema.php';
require_once __DIR__ . '/reader.php';
require_once __DIR__ . '/repo.php';
require_once __DIR__ . '/validator.php';
require_once __DIR__ . '/runner.php';

$user = require_permission('import.run');
$id   = (isset($_REQUEST['id']) && ctype_digit((string) $_REQUEST['id'])) ? (int) $_REQUEST['id'] : 0;
$batch = $id > 0 ? imp_batch_find($id) : null;
if ($batch === null) {
    flash_set('danger', 'Batch impor tidak ditemukan.');
    redirect('modules/imports/index.php');
}
if (!in_array($batch['status'], ['uploaded', 'validated'], true)) {
    redirect('modules/imports/review.php?id=' . $id);
}
if (!imp_lib_available()) {
    flash_set('danger', 'PhpSpreadsheet belum terpasang. Jalankan "composer install".');
    redirect('modules/imports/index.php');
}

$type   = $batch['import_type'];
$fields = imp_fields($type);
$meta   = imp_meta($batch);
$self   = 'modules/imports/map.php?id=' . $id;

try {
    $path = imp_file_path($batch) ?? throw new ImportUserError('File sementara tidak ditemukan atau sudah dihapus. Unggah ulang file Anda.');
    $sheet = imp_read_sheet($path, $meta['ext']);
} catch (ImportUserError $e) {
    flash_set('danger', $e->getMessage());
    redirect('modules/imports/index.php');
} catch (Throwable $e) {
    error_log('[IMPORT] Gagal membaca file batch #' . $id . ': ' . $e->getMessage());
    imp_delete_file($batch);
    db_run("UPDATE import_batches SET status = 'failed', error_message = 'File tidak dapat dibaca.' WHERE id = ?", 'i', [$id]);
    flash_set('danger', 'File tidak dapat dibaca. Pastikan file Excel/CSV tidak rusak atau terkunci sandi, lalu unggah ulang.');
    redirect('modules/imports/index.php');
}

/* ---------------- POST: simpan pemetaan + validasi ---------------- */
if (is_post()) {
    csrf_require();
    $headerRow = (int) ($_POST['header_row'] ?? 1);
    $headerRow = max(1, min(IMP_MAX_HEADER_ROW, $headerRow));
    $policy    = (($_POST['duplicate_policy'] ?? 'skip') === 'update') ? 'update' : 'skip';

    $mapping = [];
    foreach ($fields as $f => $def) {
        $v = $_POST['map'][$f] ?? '';
        if (is_string($v) && ctype_digit($v)) {
            $mapping[$f] = (int) $v;
        }
    }
    $headers = imp_headers($sheet, $headerRow);
    $back = fn (string $msg) => (function () use ($msg, $id, $headerRow) {
        flash_set('danger', $msg);
        redirect('modules/imports/map.php?id=' . $id . '&header=' . $headerRow);
    })();

    if ($policy === 'update' && empty($_POST['confirm_update'])) {
        $back('Untuk kebijakan "perbarui", centang konfirmasi bahwa data lama akan ditimpa.');
    }
    if ($msg = imp_check_mapping($type, $mapping, $headers)) {
        $back($msg);
    }

    $meta['header_row'] = $headerRow;
    $meta['mapping']    = $mapping;
    db_run('UPDATE import_batches SET duplicate_policy = ?, column_mapping = ? WHERE id = ?', 'ssi', [$policy, json_encode($meta, JSON_UNESCAPED_UNICODE), $id]);
    $batch = imp_batch_find($id);

    try {
        $r = imp_validate_batch($batch);
    } catch (ImportUserError $e) {
        $back($e->getMessage());
    } catch (Throwable $e) {
        error_log('[IMPORT] Validasi batch #' . $id . ' gagal: ' . $e->getMessage() . ' @ ' . $e->getFile() . ':' . $e->getLine());
        $back('Validasi gagal karena kesalahan di server. Coba lagi atau unggah ulang file.');
    }
    audit_log('import_validate', 'import_batch', $id, sprintf('Validasi %s: %d baris (%d baru, %d duplikat, %d tidak valid)', $batch['original_name'], $r['total'], count($r['new']), $r['dup_db'] + $r['dup_file'], $r['invalid']), (int) $user['id']);
    redirect('modules/imports/review.php?id=' . $id);
}

/* ---------------- GET: tampilan ---------------- */
$headerRow = (isset($_GET['header']) && ctype_digit((string) $_GET['header'])) ? max(1, min(IMP_MAX_HEADER_ROW, (int) $_GET['header'])) : (int) $meta['header_row'];
$headers   = imp_headers($sheet, $headerRow);
$dataRows  = imp_data_rows($sheet, $headerRow);
$tooMany   = imp_exceeds_row_limit($sheet, $headerRow);
$headerChanged = $headerRow !== (int) $meta['header_row'];
$saved   = (!$headerChanged && $meta['mapping']) ? array_map('intval', (array) $meta['mapping']) : [];
$auto    = $saved ? [] : imp_auto_map($type, $headers);
$current = $saved ?: $auto;
$previewCols = $headers ? range(0, min(max(array_keys($headers)), IMP_MAX_COLUMNS - 1)) : [];
$previewCols = array_slice($previewCols, 0, 14);
$preview = array_slice($dataRows, 0, 6, true);
$policy  = $batch['duplicate_policy'];
$sameHash = db_fetch_one("SELECT id, completed_at FROM import_batches WHERE file_hash = ? AND status = 'completed' AND id <> ? ORDER BY id DESC LIMIT 1", 'si', [$batch['file_hash'], $id]);

$page = ['title' => 'Pemetaan Kolom', 'active' => 'import', 'breadcrumb' => ['Data Intelligence', 'Import Excel', 'Pemetaan kolom'], 'css' => ['crud.css', 'import.css'], 'js' => ['import.js']];
require BASE_PATH . '/includes/header.php';
$show = function ($v): string {
    if ($v === IMP_FORMULA) { return '(rumus tanpa nilai)'; }
    $s = imp_cell_str($v);
    return mb_strlen($s) > 38 ? mb_substr($s, 0, 36) . '…' : $s;
};
?>
<section class="crud-page">
    <div class="page-header">
        <div><h1>Pemetaan kolom</h1><p class="page-sub"><?= e(IMPORT_TYPES[$type]) ?> · <strong><?= e($batch['original_name']) ?></strong> · <?= e(format_number($batch['file_size'] / 1024, 0)) ?> KB</p></div>
        <div class="page-actions">
            <form method="post" action="<?= e(url('modules/imports/cancel.php')) ?>" data-confirm="Batalkan impor ini dan hapus file sementara?"><?= csrf_field() ?><input type="hidden" name="id" value="<?= $id ?>"><button class="btn btn-outline" type="submit"><?= icon('x') ?>Batalkan</button></form>
        </div>
    </div>
    <?= ui_stepper(['Unggah file', 'Pemetaan kolom', 'Validasi & tinjau', 'Hasil import'], 2) ?>

    <?php if ($sameHash): ?>
        <div class="notice notice-warning"><?= icon('triangle-alert') ?><div><strong>File yang sama</strong> pernah berhasil diimpor (batch #<?= (int) $sameHash['id'] ?>, <?= e(format_datetime($sameHash['completed_at'])) ?>). Pastikan ini bukan unggahan ganda.</div></div>
    <?php endif; ?>
    <?php if ($tooMany): ?>
        <div class="notice notice-warning" role="alert"><?= icon('triangle-alert') ?><div>File memiliki lebih dari <?= e(format_number(imp_max_rows(), 0)) ?> baris data. Pecah file menjadi beberapa bagian lalu unggah ulang.</div></div>
    <?php endif; ?>

    <article class="card section-card">
        <header class="card-head"><div><h2>Pratinjau data</h2><p>Sheet "<?= e($sheet['sheet']) ?>" · <?= e(format_number(count($dataRows), 0)) ?> baris data terbaca · 6 baris pertama ditampilkan</p></div>
            <form method="get" action="<?= e(url('modules/imports/map.php')) ?>" class="inline-form">
                <input type="hidden" name="id" value="<?= $id ?>">
                <label class="filter"><span>Baris judul kolom</span><input type="number" name="header" min="1" max="<?= IMP_MAX_HEADER_ROW ?>" value="<?= (int) $headerRow ?>" class="form-control" style="min-width:0;width:90px"></label>
                <button type="submit" class="btn btn-outline btn-sm">Terapkan</button>
            </form>
        </header>
        <?php if (!$headers): ?>
            <?= ui_empty_state('triangle-alert', 'Baris judul kosong', "Baris {$headerRow} tidak memiliki judul kolom. Ubah nomor baris judul di atas.") ?>
        <?php else: ?>
        <div class="table-scroll preview-scroll"><table class="table preview-table">
            <thead><tr><th class="rowno">#</th><?php foreach ($previewCols as $c): ?><th><span class="col-letter"><?= e(imp_col_letter($c)) ?></span><?= e($headers[$c] ?? '') ?></th><?php endforeach; ?></tr></thead>
            <tbody><?php foreach ($preview as $rn => $cells): ?><tr><td class="rowno"><?= (int) $rn ?></td><?php foreach ($previewCols as $c): ?><td><?= e($show($cells[$c] ?? null)) ?></td><?php endforeach; ?></tr><?php endforeach; ?></tbody>
        </table></div>
        <?php endif; ?>
    </article>

    <?php if ($headers): ?>
    <form method="post" action="<?= e(url('modules/imports/map.php?id=' . $id)) ?>" id="mapForm" class="card section-card">
        <?= csrf_field() ?><input type="hidden" name="id" value="<?= $id ?>"><input type="hidden" name="header_row" value="<?= (int) $headerRow ?>">
        <header class="card-head"><div><h2>Petakan kolom file ke field database</h2><p><?= $auto ? 'Pemetaan di bawah ditebak otomatis dari judul kolom; periksa sebelum melanjutkan.' : 'Pilih kolom file untuk setiap field. Field bertanda * wajib dipetakan.' ?></p></div></header>
        <div class="map-grid">
            <?php foreach ($fields as $f => $def): $sel = $current[$f] ?? null; ?>
            <div class="map-row">
                <label for="map_<?= e($f) ?>"><strong><?= e($def['label']) ?></strong><?= $def['required'] ? ' <b class="req">*</b>' : '' ?><small><?= e($def['hint']) ?></small></label>
                <div class="map-select">
                    <select name="map[<?= e($f) ?>]" id="map_<?= e($f) ?>" class="form-select" data-field="<?= e($f) ?>" <?= $def['required'] ? 'required' : '' ?>>
                        <option value=""><?= $def['required'] ? '— Pilih kolom —' : '— Tidak dipakai —' ?></option>
                        <?php foreach ($headers as $idx => $h): ?><option value="<?= (int) $idx ?>" <?= $sel === $idx ? 'selected' : '' ?>><?= e(imp_col_letter($idx) . ' — ' . $h) ?></option><?php endforeach; ?>
                    </select>
                    <?php if (isset($auto[$f])): ?><span class="pill pill-info">terdeteksi</span><?php endif; ?>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
        <p class="field-error" id="mapError" role="alert"></p>

        <fieldset class="policy">
            <legend>Jika data sudah ada di database (duplikat)</legend>
            <label class="radio"><input type="radio" name="duplicate_policy" value="skip" <?= $policy !== 'update' ? 'checked' : '' ?>><span><strong>Lewati (disarankan)</strong><small>Data lama tidak diubah. Hanya baris baru yang disimpan.</small></span></label>
            <label class="radio"><input type="radio" name="duplicate_policy" value="update" <?= $policy === 'update' ? 'checked' : '' ?>><span><strong>Perbarui data lama</strong><small>Menimpa field data lama dengan isi file. Tidak dapat dibatalkan setelah dikonfirmasi.</small></span></label>
            <label class="check" id="confirmUpdateWrap" hidden><input type="checkbox" name="confirm_update" value="1"> Saya memahami bahwa data lama yang duplikat akan ditimpa.</label>
        </fieldset>

        <div class="upload-foot">
            <p class="muted-note">Langkah berikutnya hanya memeriksa file. Belum ada data yang disimpan ke database.</p>
            <button type="submit" class="btn btn-primary" <?= $tooMany ? 'disabled' : '' ?>><?= icon('shield-check') ?>Validasi data</button>
        </div>
    </form>
    <?php endif; ?>
</section>
<?php require BASE_PATH . '/includes/footer.php'; ?>
