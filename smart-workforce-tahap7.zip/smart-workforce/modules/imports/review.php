<?php
/** Langkah 3-4: hasil validasi / hasil import. Juga dipakai sebagai halaman detail batch pada Riwayat Import. */
declare(strict_types=1);
require_once dirname(__DIR__, 2) . '/includes/bootstrap.php';
require_once dirname(__DIR__) . '/employees/repo.php';
require_once __DIR__ . '/schema.php';
require_once __DIR__ . '/reader.php';
require_once __DIR__ . '/repo.php';

$user = require_login();
if (!user_can('import.run', $user) && !user_can('import.history', $user)) {
    require_permission('import.history');
}
$canRun = user_can('import.run', $user);
$id    = (isset($_GET['id']) && ctype_digit((string) $_GET['id'])) ? (int) $_GET['id'] : 0;
$batch = $id > 0 ? imp_batch_find($id) : null;
if ($batch === null) {
    flash_set('danger', 'Batch impor tidak ditemukan.');
    redirect('modules/imports/history.php');
}
if ($batch['status'] === 'uploaded' && $canRun) {
    redirect('modules/imports/map.php?id=' . $id);
}

$meta   = imp_meta($batch);
$stats  = $meta['stats'];
$status = $batch['status'];
$type   = $batch['import_type'];
$path   = 'modules/imports/review.php';
$ef     = imp_errors_where($id, imp_error_filters());
$filters = imp_error_filters();
$perPage = 25;
$totalErr = (int) db_value("SELECT COUNT(*) FROM import_errors {$ef[0]}", $ef[1], $ef[2]);
$pageNo = list_clamp_page($totalErr, (isset($_GET['page']) && ctype_digit((string) $_GET['page'])) ? max(1, (int) $_GET['page']) : 1, $perPage);
$errors = db_fetch_all("SELECT * FROM import_errors {$ef[0]} ORDER BY `row_number` ASC, id ASC LIMIT ? OFFSET ?", $ef[1] . 'ii', array_merge($ef[2], [$perPage, ($pageNo - 1) * $perPage]));
$byType = db_fetch_all('SELECT error_type, severity, COUNT(*) AS n FROM import_errors WHERE batch_id = ? GROUP BY error_type, severity ORDER BY n DESC', 'i', [$id]);
$errAll = (int) db_value('SELECT COUNT(*) FROM import_errors WHERE batch_id = ?', 'i', [$id]);
$sameHash = $status === 'validated' ? db_fetch_one("SELECT id, completed_at FROM import_batches WHERE file_hash = ? AND status = 'completed' AND id <> ? ORDER BY id DESC LIMIT 1", 'si', [$batch['file_hash'], $id]) : null;
$step = $status === 'validated' ? 3 : 4;
$willImport = ($batch['valid_rows'] ?? 0) + (int) ($stats['update'] ?? 0);
$policyLabel = $batch['duplicate_policy'] === 'update' ? 'Perbarui data lama' : 'Lewati duplikat';
$viewUrl = $type === 'employees' ? 'modules/employees/index.php' : 'modules/mandays/index.php?period=all&source=import';

$page = ['title' => 'Hasil Validasi Import', 'active' => $canRun ? 'import' : 'imphistory', 'breadcrumb' => ['Data Intelligence', 'Import Excel', 'Batch #' . $id], 'css' => ['crud.css', 'import.css'], 'js' => ['import.js']];
require BASE_PATH . '/includes/header.php';
?>
<section class="crud-page">
    <div class="page-header">
        <div><h1>Batch impor #<?= $id ?></h1><p class="page-sub"><?= e(IMPORT_TYPES[$type] ?? $type) ?> · <strong><?= e($batch['original_name']) ?></strong> · oleh <?= e($batch['user_name'] ?? '-') ?> · <?= e(format_datetime($batch['created_at'])) ?> · <?= imp_status_badge($status) ?></p></div>
        <div class="page-actions">
            <?php if ($errAll > 0): ?><a class="btn btn-outline" href="<?= e(url('modules/imports/errors.php?id=' . $id)) ?>"><?= icon('download') ?>Unduh laporan kesalahan</a><?php endif; ?>
        </div>
    </div>

    <?php if ($status === 'validated' || $status === 'completed'): ?><?= ui_stepper(['Unggah file', 'Pemetaan kolom', 'Validasi & tinjau', 'Hasil import'], $status === 'completed' ? 5 : 3) ?><?php endif; ?>

    <?php if ($status === 'failed' || $status === 'cancelled'): ?>
        <div class="notice <?= $status === 'failed' ? 'notice-danger' : 'notice-info' ?>"><?= icon($status === 'failed' ? 'circle-alert' : 'info') ?><div><strong><?= e(IMPORT_STATUS_LABELS[$status]) ?>.</strong> <?= e($batch['error_message'] ?: ($status === 'cancelled' ? 'Impor dibatalkan; tidak ada data yang disimpan.' : '')) ?></div></div>
    <?php elseif ($status === 'completed'): ?>
        <div class="notice notice-success" role="status"><?= icon('circle-check') ?><div><strong>Import selesai.</strong>
            <?= e(format_number((int) ($stats['inserted'] ?? $batch['valid_rows']), 0)) ?> baris baru disimpan<?= ((int) ($stats['updated'] ?? 0)) > 0 ? ', ' . e(format_number((int) $stats['updated'], 0)) . ' baris diperbarui' : '' ?>;
            <?= e(format_number(max(0, $batch['duplicate_rows'] - (int) ($stats['updated'] ?? 0)), 0)) ?> duplikat dilewati; <?= e(format_number($batch['invalid_rows'], 0)) ?> baris tidak valid tidak diimpor.</div>
            <a href="<?= e(url($viewUrl)) ?>">Lihat data</a></div>
    <?php endif; ?>

    <div class="mini-stats">
        <?= ui_mini_stat('Total baris', format_number($batch['total_rows'], 0), 'terbaca dari file') ?>
        <?= ui_mini_stat($status === 'completed' ? 'Diimpor' : 'Baris valid (baru)', format_number($status === 'completed' ? $batch['imported_rows'] : $batch['valid_rows'], 0), $status === 'completed' ? 'baru + diperbarui' : 'siap disimpan') ?>
        <?= ui_mini_stat('Baris duplikat', format_number($batch['duplicate_rows'], 0), ((int) ($stats['dup_db'] ?? 0)) . ' di database · ' . ((int) ($stats['dup_file'] ?? 0)) . ' berulang di file') ?>
        <?= ui_mini_stat('Baris tidak valid', format_number($batch['invalid_rows'], 0), 'tidak akan diimpor') ?>
    </div>

    <?php if ($sameHash): ?>
        <div class="notice notice-warning"><?= icon('triangle-alert') ?><div><strong>File yang sama</strong> pernah berhasil diimpor (batch #<?= (int) $sameHash['id'] ?>, <?= e(format_datetime($sameHash['completed_at'])) ?>). Pastikan ini bukan unggahan ganda.</div></div>
    <?php endif; ?>
    <?php if (!empty($stats['errors_truncated'])): ?>
        <div class="notice notice-warning"><?= icon('info') ?><div>Daftar kesalahan dipotong pada <?= e(format_number(IMP_MAX_STORED_ERRORS, 0)) ?> entri pertama. Perbaiki sebagian lalu validasi ulang.</div></div>
    <?php endif; ?>

    <?php if ($status === 'validated' && $canRun): ?>
    <article class="card section-card confirm-card">
        <header class="card-head"><div><h2>Konfirmasi import</h2><p>Kebijakan duplikat: <strong><?= e($policyLabel) ?></strong>. Belum ada data yang disimpan sampai Anda mengonfirmasi.</p></div></header>
        <?php if ($willImport === 0): ?>
            <p class="muted-note">Tidak ada baris yang dapat diimpor. Perbaiki file lalu unggah ulang, atau ubah pemetaan.</p>
            <div class="upload-foot"><span></span><a class="btn btn-outline" href="<?= e(url('modules/imports/map.php?id=' . $id)) ?>">Ubah pemetaan</a></div>
        <?php else: ?>
        <form method="post" action="<?= e(url('modules/imports/confirm.php')) ?>" id="confirmForm">
            <?= csrf_field() ?><input type="hidden" name="id" value="<?= $id ?>">
            <p class="confirm-line">Akan disimpan: <strong><?= e(format_number($batch['valid_rows'], 0)) ?></strong> baris baru<?= ((int) ($stats['update'] ?? 0)) > 0 ? ' dan memperbarui <strong>' . e(format_number((int) $stats['update'], 0)) . '</strong> data lama' : '' ?>.
                <?= $batch['invalid_rows'] > 0 ? e(format_number($batch['invalid_rows'], 0)) . ' baris tidak valid akan dilewati.' : '' ?></p>
            <label class="check"><input type="checkbox" name="ack" value="1" required> Saya sudah meninjau hasil validasi dan ingin menyimpan data ke database.</label>
            <div class="upload-foot">
                <a class="btn btn-outline" href="<?= e(url('modules/imports/map.php?id=' . $id)) ?>">Ubah pemetaan</a>
                <button type="submit" class="btn btn-primary" id="confirmSubmit"><?= icon('circle-check') ?>Konfirmasi & import</button>
            </div>
        </form>
        <?php endif; ?>
        <form method="post" action="<?= e(url('modules/imports/cancel.php')) ?>" class="cancel-line" data-confirm="Batalkan impor ini dan hapus file sementara?"><?= csrf_field() ?><input type="hidden" name="id" value="<?= $id ?>"><button type="submit" class="link-btn">Batalkan impor ini</button></form>
    </article>
    <?php endif; ?>

    <?php if ($byType): ?>
    <article class="card section-card">
        <header class="card-head"><div><h2>Ringkasan kesalahan</h2><p>Klik untuk memfilter daftar di bawah</p></div></header>
        <div class="chips">
            <a class="chip<?= $filters['type'] === '' && $filters['severity'] === '' ? ' is-active' : '' ?>" href="<?= e(list_url($path, ['type' => null, 'severity' => null, 'page' => null])) ?>">Semua <b><?= e(format_number($errAll, 0)) ?></b></a>
            <?php foreach ($byType as $t): ?>
                <a class="chip chip-<?= e($t['severity']) ?><?= $filters['type'] === $t['error_type'] ? ' is-active' : '' ?>" href="<?= e(list_url($path, ['type' => $t['error_type'], 'severity' => null, 'page' => null])) ?>"><?= e(IMPORT_ERROR_LABELS[$t['error_type']] ?? $t['error_type']) ?> <b><?= e(format_number($t['n'], 0)) ?></b></a>
            <?php endforeach; ?>
        </div>
    </article>
    <?php endif; ?>

    <article class="card table-card">
        <header class="card-head" style="padding:18px 22px 0"><div><h2>Detail per baris</h2><p>Kesalahan (baris tidak diimpor) dan peringatan duplikat (baris dilewati/diperbarui)</p></div></header>
        <?php if ($totalErr === 0): ?>
            <?= ui_empty_state('circle-check', $errAll === 0 ? 'Tidak ada kesalahan' : 'Tidak ada yang cocok dengan filter', $errAll === 0 ? 'Seluruh baris lolos validasi.' : 'Ubah filter untuk melihat kesalahan lainnya.') ?>
        <?php else: ?>
        <div class="table-scroll"><table class="table table-hover">
            <thead><tr><th class="num">Baris</th><th>Kolom</th><th>Jenis</th><th>Pesan & saran</th><th>Data baris</th></tr></thead>
            <tbody><?php foreach ($errors as $er): ?>
                <tr><td class="num"><strong><?= (int) $er['row_number'] ?></strong></td><td><?= e($er['column_name']) ?></td>
                    <td><?= ui_badge(IMPORT_ERROR_LABELS[$er['error_type']] ?? $er['error_type'], $er['severity'] === 'error' ? 'danger' : 'warning') ?></td>
                    <td><?= e($er['message']) ?><?= $er['suggestion'] ? '<span class="cell-sub">Saran: ' . e($er['suggestion']) . '</span>' : '' ?></td>
                    <td class="raw-cell" title="<?= e($er['raw_data']) ?>"><?= e(mb_substr((string) $er['raw_data'], 0, 90)) ?></td></tr>
            <?php endforeach; ?></tbody>
        </table></div>
        <?= ui_pagination($totalErr, $pageNo, $perPage, $path) ?>
        <?php endif; ?>
    </article>
</section>
<?php require BASE_PATH . '/includes/footer.php'; ?>
