<?php
declare(strict_types=1);
require_once dirname(__DIR__, 2) . '/includes/bootstrap.php';
require_once __DIR__ . '/schema.php';
require_once __DIR__ . '/repo.php';

$user = require_permission('import.history');
$path = 'modules/imports/history.php';

$g = fn (string $k): string => (isset($_GET[$k]) && is_string($_GET[$k])) ? trim($_GET[$k]) : '';
$f = [
    'status' => array_key_exists($g('status'), IMPORT_STATUS_LABELS) ? $g('status') : '',
    'type'   => array_key_exists($g('type'), IMPORT_TYPES) ? $g('type') : '',
    'q'      => mb_substr($g('q'), 0, 100),
];
$req = list_request(['id' => 'b.id', 'file' => 'b.original_name', 'rows' => 'b.total_rows', 'status' => 'b.status'], 'id', 'desc');
$w = []; $t = ''; $p = [];
if ($f['status'] !== '') { $w[] = 'b.status = ?'; $t .= 's'; $p[] = $f['status']; }
if ($f['type'] !== '')   { $w[] = 'b.import_type = ?'; $t .= 's'; $p[] = $f['type']; }
if ($f['q'] !== '')      { $w[] = 'b.original_name LIKE ?'; $t .= 's'; $p[] = '%' . like_escape($f['q']) . '%'; }
$where = $w ? 'WHERE ' . implode(' AND ', $w) : '';
$total  = (int) db_value("SELECT COUNT(*) FROM import_batches b {$where}", $t, $p);
$pageNo = list_clamp_page($total, $req['page'], $req['per']);
$rows = db_fetch_all("SELECT b.*, u.name AS user_name FROM import_batches b LEFT JOIN users u ON u.id = b.imported_by {$where} ORDER BY {$req['order_sql']} LIMIT ? OFFSET ?", $t . 'ii', array_merge($p, [$req['per'], ($pageNo - 1) * $req['per']]));
$hasFilter = $f['status'] !== '' || $f['type'] !== '' || $f['q'] !== '';
$sumAll = db_fetch_one("SELECT COUNT(*) n, COALESCE(SUM(status='completed'),0) ok, COALESCE(SUM(status='failed'),0) bad, COALESCE(SUM(imported_rows),0) rows_in FROM import_batches");

$page = ['title' => 'Riwayat Import', 'active' => 'imphistory', 'breadcrumb' => ['Reporting', 'Riwayat Import'], 'css' => ['crud.css', 'import.css']];
require BASE_PATH . '/includes/header.php';
$opt = fn ($v, $cur, $label) => '<option value="' . e($v) . '"' . ((string) $v === (string) $cur ? ' selected' : '') . '>' . e($label) . '</option>';
?>
<section class="crud-page">
    <div class="page-header">
        <div><h1>Riwayat Import</h1><p class="page-sub">Seluruh proses import: siapa, kapan, file apa, dan hasilnya.</p></div>
        <div class="page-actions"><?php if (user_can('import.run', $user)): ?><a class="btn btn-primary" href="<?= e(url('modules/imports/index.php')) ?>"><?= icon('plus') ?>Import baru</a><?php endif; ?></div>
    </div>
    <div class="mini-stats">
        <?= ui_mini_stat('Total batch', format_number($sumAll['n'], 0)) ?>
        <?= ui_mini_stat('Selesai', format_number($sumAll['ok'], 0)) ?>
        <?= ui_mini_stat('Gagal', format_number($sumAll['bad'], 0), 'di-rollback, tidak ada data tersimpan') ?>
        <?= ui_mini_stat('Total baris diimpor', format_number($sumAll['rows_in'], 0)) ?>
    </div>

    <form class="card toolbar" method="get" action="<?= e(url($path)) ?>">
        <input type="hidden" name="sort" value="<?= e($req['sort']) ?>"><input type="hidden" name="dir" value="<?= e($req['dir']) ?>">
        <label class="search-box"><?= icon('search') ?><input type="search" name="q" value="<?= e($f['q']) ?>" placeholder="Cari nama file…" maxlength="100" aria-label="Cari"></label>
        <select name="status" class="form-select" data-autosubmit aria-label="Status"><option value="">Semua status</option><?php foreach (IMPORT_STATUS_LABELS as $k => $l) echo $opt($k, $f['status'], $l); ?></select>
        <select name="type" class="form-select" data-autosubmit aria-label="Jenis"><option value="">Semua jenis</option><?php foreach (IMPORT_TYPES as $k => $l) echo $opt($k, $f['type'], $l); ?></select>
        <select name="per" class="form-select form-select-sm" data-autosubmit aria-label="Baris per halaman"><?php foreach (PER_PAGE_OPTIONS as $n) echo $opt($n, $req['per'], $n . ' / halaman'); ?></select>
        <button type="submit" class="btn btn-outline btn-sm"><?= icon('search') ?>Cari</button>
        <?php if ($hasFilter): ?><a class="btn btn-outline btn-sm" href="<?= e(url($path)) ?>"><?= icon('rotate-ccw') ?>Reset</a><?php endif; ?>
    </form>

    <div class="card table-card">
        <?php if ($total === 0): ?>
            <?= $hasFilter ? ui_empty_state('search', 'Tidak ada batch yang cocok', 'Ubah filter atau kata kunci.', '<a class="btn btn-outline btn-sm" href="' . e(url($path)) . '">Reset filter</a>') : ui_empty_state('history', 'Belum ada riwayat import', 'Riwayat akan tampil setelah ada file yang diunggah.') ?>
        <?php else: ?>
        <div class="table-scroll"><table class="table table-hover">
            <thead><tr><?= ui_sort_th('#', 'id', $req, $path) ?><?= ui_sort_th('File', 'file', $req, $path) ?><th>Jenis</th><th>Pengguna</th><?= ui_sort_th('Baris', 'rows', $req, $path, 'num') ?><th class="num">Valid</th><th class="num">Duplikat</th><th class="num">Tidak valid</th><th class="num">Diimpor</th><?= ui_sort_th('Status', 'status', $req, $path) ?><th>Waktu</th><th class="col-actions"></th></tr></thead>
            <tbody><?php foreach ($rows as $b): ?>
                <tr><td><code>#<?= (int) $b['id'] ?></code></td>
                    <td><strong><?= e($b['original_name']) ?></strong><span class="cell-sub"><?= e(format_number($b['file_size'] / 1024, 0)) ?> KB<?= $b['duplicate_policy'] === 'update' ? ' · kebijakan perbarui' : '' ?></span></td>
                    <td><?= e(IMPORT_TYPES[$b['import_type']] ?? $b['import_type']) ?></td><td><?= e($b['user_name'] ?? '-') ?></td>
                    <td class="num"><?= e(format_number($b['total_rows'], 0)) ?></td><td class="num"><?= e(format_number($b['valid_rows'], 0)) ?></td><td class="num"><?= e(format_number($b['duplicate_rows'], 0)) ?></td>
                    <td class="num"><?= $b['invalid_rows'] > 0 ? '<strong class="text-danger">' . e(format_number($b['invalid_rows'], 0)) . '</strong>' : '0' ?></td><td class="num"><strong><?= e(format_number($b['imported_rows'], 0)) ?></strong></td>
                    <td><?= imp_status_badge($b['status']) ?></td><td><?= e(format_datetime($b['completed_at'] ?? $b['created_at'])) ?></td>
                    <td class="col-actions"><a class="row-btn" href="<?= e(url('modules/imports/review.php?id=' . (int) $b['id'])) ?>" title="Lihat detail" aria-label="Lihat detail"><?= icon('eye') ?></a></td></tr>
            <?php endforeach; ?></tbody>
        </table></div>
        <?= ui_pagination($total, $pageNo, $req['per'], $path) ?>
        <?php endif; ?>
    </div>
</section>
<?php require BASE_PATH . '/includes/footer.php'; ?>
