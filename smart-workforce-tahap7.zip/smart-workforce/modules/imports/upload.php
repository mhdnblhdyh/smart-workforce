<?php
declare(strict_types=1);
require_once dirname(__DIR__, 2) . '/includes/bootstrap.php';
require_once dirname(__DIR__) . '/employees/repo.php';
require_once __DIR__ . '/schema.php';
require_once __DIR__ . '/reader.php';
require_once __DIR__ . '/repo.php';

$user = require_permission('import.run');
if (!is_post()) {
    redirect('modules/imports/index.php');
}

// Unggahan melebihi post_max_size: PHP mengosongkan $_POST dan $_FILES.
if (empty($_POST) && empty($_FILES) && (int) ($_SERVER['CONTENT_LENGTH'] ?? 0) > 0) {
    flash_set('danger', 'Ukuran unggahan melebihi batas server (post_max_size di php.ini).');
    redirect('modules/imports/index.php');
}
csrf_require();

$fail = function (string $msg): void {
    flash_set('danger', $msg);
    redirect('modules/imports/index.php');
};

$type = post_str('import_type', 30);
if (!isset(IMPORT_TYPES[$type])) {
    $fail('Pilih jenis data yang akan diimpor.');
}
if (!imp_lib_available()) {
    $fail('PhpSpreadsheet belum terpasang. Jalankan "composer install" terlebih dahulu.');
}

[$info, $error] = imp_validate_upload($_FILES['file'] ?? null);
if ($info === null) {
    audit_log('import_rejected', 'import_batch', null, 'Unggahan ditolak: ' . $error, (int) $user['id']);
    $fail((string) $error);
}

$stored = imp_store_upload($_FILES['file']['tmp_name'], $info['ext']);
$hash   = hash_file('sha256', imp_storage_dir() . '/' . $stored);
$id     = imp_batch_create($type, $info, $stored, $hash, (int) $user['id']);

audit_log('import_upload', 'import_batch', $id, 'Mengunggah ' . IMPORT_TYPES[$type] . ': ' . $info['name'] . ' (' . format_number($info['size'] / 1024, 0) . ' KB)', (int) $user['id']);
redirect('modules/imports/map.php?id=' . $id);
