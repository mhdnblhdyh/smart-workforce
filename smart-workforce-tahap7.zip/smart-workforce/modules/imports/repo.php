<?php
/**
 * Akses data batch impor.
 * Status batch: uploaded -> validated -> completed | failed | cancelled.
 * Metadata (pemetaan, baris header, statistik) disimpan sebagai JSON di kolom column_mapping.
 */
declare(strict_types=1);

const IMP_STALE_HOURS = 24;
const IMP_MAX_STORED_ERRORS = 10000;

function imp_batch_create(string $type, array $upload, string $storedName, string $hash, int $userId): int
{
    db_run(
        "INSERT INTO import_batches (import_type, original_name, stored_name, file_size, file_hash, status, imported_by, column_mapping)
         VALUES (?, ?, ?, ?, ?, 'uploaded', ?, ?)",
        'sssisis',
        [$type, $upload['name'], $storedName, $upload['size'], $hash, $userId, json_encode(['ext' => $upload['ext'], 'header_row' => 1, 'mapping' => new stdClass()])]
    );
    return db_last_id();
}

function imp_batch_find(int $id): ?array
{
    return db_fetch_one(
        'SELECT b.*, u.name AS user_name FROM import_batches b LEFT JOIN users u ON u.id = b.imported_by WHERE b.id = ?',
        'i',
        [$id]
    );
}

/** Metadata batch (selalu mengembalikan struktur lengkap). */
function imp_meta(array $batch): array
{
    $m = json_decode((string) ($batch['column_mapping'] ?? ''), true);
    $m = is_array($m) ? $m : [];
    return $m + ['ext' => 'xlsx', 'header_row' => 1, 'mapping' => [], 'sheet' => '', 'stats' => []];
}

function imp_meta_save(int $id, array $meta): void
{
    db_run('UPDATE import_batches SET column_mapping = ? WHERE id = ?', 'si', [json_encode($meta, JSON_UNESCAPED_UNICODE), $id]);
}

/** Path file sementara; null bila nama tidak valid atau file sudah dihapus. Nama diverifikasi untuk mencegah path traversal. */
function imp_file_path(array $batch): ?string
{
    $name = (string) ($batch['stored_name'] ?? '');
    if (!preg_match('/^imp_[a-f0-9]{32}\.(xlsx|csv)$/', $name)) {
        return null;
    }
    $path = imp_storage_dir() . '/' . $name;
    return is_file($path) ? $path : null;
}

/** Hapus file sementara dan kosongkan stored_name. */
function imp_delete_file(array $batch): void
{
    $path = imp_file_path($batch);
    if ($path !== null) {
        @unlink($path);
    }
    db_run('UPDATE import_batches SET stored_name = NULL WHERE id = ?', 'i', [(int) $batch['id']]);
}

/** Batch yang belum selesai dan terlalu lama dibatalkan, file sementaranya dibersihkan. */
function imp_cleanup_stale(): int
{
    $rows = db_fetch_all(
        "SELECT * FROM import_batches WHERE status IN ('uploaded','validated') AND created_at < DATE_SUB(NOW(), INTERVAL ? HOUR)",
        'i',
        [IMP_STALE_HOURS]
    );
    foreach ($rows as $b) {
        imp_delete_file($b);
        db_run("UPDATE import_batches SET status = 'cancelled', error_message = 'Dibatalkan otomatis: tidak dikonfirmasi dalam " . IMP_STALE_HOURS . " jam.' WHERE id = ?", 'i', [(int) $b['id']]);
    }
    // File yatim (tidak punya batch aktif) lebih dari 2 hari
    foreach (glob(imp_storage_dir() . '/imp_*') ?: [] as $f) {
        if (filemtime($f) < time() - 2 * 86400) {
            @unlink($f);
        }
    }
    return count($rows);
}

/** Pelabelan status dengan varian badge. */
function imp_status_badge(string $status): string
{
    $v = ['uploaded' => 'warning', 'validated' => 'info', 'completed' => 'success', 'failed' => 'danger', 'cancelled' => 'neutral'][$status] ?? 'neutral';
    return ui_badge(IMPORT_STATUS_LABELS[$status] ?? $status, $v);
}

/** Filter daftar kesalahan dari query string. */
function imp_error_filters(): array
{
    $g = fn (string $k): string => (isset($_GET[$k]) && is_string($_GET[$k])) ? trim($_GET[$k]) : '';
    return [
        'type'     => array_key_exists($g('type'), IMPORT_ERROR_LABELS) ? $g('type') : '',
        'severity' => in_array($g('severity'), ['error', 'warning'], true) ? $g('severity') : '',
    ];
}

function imp_errors_where(int $batchId, array $f): array
{
    $w = ['batch_id = ?']; $t = 'i'; $p = [$batchId];
    if ($f['type'] !== '')     { $w[] = 'error_type = ?'; $t .= 's'; $p[] = $f['type']; }
    if ($f['severity'] !== '') { $w[] = 'severity = ?';   $t .= 's'; $p[] = $f['severity']; }
    return ['WHERE ' . implode(' AND ', $w), $t, $p];
}
