<?php
/**
 * Validasi baris impor (tanpa query per baris: referensi dimuat sekali ke memori).
 *
 * Aturan data SAMA dengan form manual:
 *  - Tenaga kerja: lihat modules/employees/repo.php (emp_validate) — vendor wajib hanya untuk TAD, magang wajib tanggal berakhir,
 *    status selain Aktif wajib tanggal berakhir, status Aktif tidak boleh berakhir di masa lalu.
 *  - Mandays: lihat modules/mandays/repo.php (md_validate) — periode tidak di masa depan, tenaga kerja aktif pada bulan tsb,
 *    mandays <= jumlah hari bulan itu, kehadiran berpasangan, hadir <= terjadwal.
 *
 * Klasifikasi baris: invalid (ada kesalahan) | duplikat (kunci sudah ada di database atau berulang di file) | baru.
 * Duplikat di database hanya DIPERBARUI bila batch memakai kebijakan "update" yang dipilih eksplisit; selain itu dilewati.
 */
declare(strict_types=1);

/** Konteks referensi untuk impor tenaga kerja. */
function imp_ctx_employees(): array
{
    $dept = ['code' => [], 'name' => []];
    foreach (db_fetch_all('SELECT id, code, name, status FROM departments') as $d) {
        $dept['code'][mb_strtolower($d['code'])] = $d;
        $dept['name'][mb_strtolower($d['name'])][] = $d;
    }
    $vend = ['code' => [], 'name' => []];
    foreach (db_fetch_all('SELECT id, code, name, status FROM vendors') as $v) {
        $vend['code'][mb_strtolower($v['code'])] = $v;
        $vend['name'][mb_strtolower($v['name'])][] = $v;
    }
    $existing = [];
    foreach (db_fetch_all('SELECT id, employee_code, department_id, vendor_id FROM employees') as $e) {
        $existing[strtoupper($e['employee_code'])] = $e;
    }
    return ['dept' => $dept, 'vend' => $vend, 'existing' => $existing];
}

/** Konteks referensi untuk impor mandays. */
function imp_ctx_records(): array
{
    $emps = [];
    foreach (db_fetch_all('SELECT id, employee_code, start_date, end_date FROM employees') as $e) {
        $emps[strtoupper($e['employee_code'])] = $e;
    }
    $existing = [];
    foreach (db_fetch_all('SELECT employee_id, DATE_FORMAT(period_month, \'%Y-%m\') AS ym FROM workforce_records') as $r) {
        $existing[$r['employee_id'] . '|' . $r['ym']] = true;
    }
    return ['emps' => $emps, 'existing' => $existing];
}

/** Cari baris referensi (departemen/vendor) berdasarkan kode lalu nama. @return array{0:?array,1:?string} [baris, pesan galat] */
function imp_lookup(array $index, string $value, string $what): array
{
    $k = mb_strtolower($value);
    if (isset($index['code'][$k])) {
        return [$index['code'][$k], null];
    }
    $byName = $index['name'][$k] ?? [];
    if (count($byName) === 1) {
        return [$byName[0], null];
    }
    if (count($byName) > 1) {
        return [null, "{$what} \"{$value}\" ambigu (nama sama dipakai lebih dari satu). Gunakan kode {$what}."];
    }
    return [null, "{$what} \"{$value}\" tidak ditemukan."];
}

/**
 * Validasi seluruh baris data.
 *
 * @param array<int,array<int,mixed>> $rows    [nomorBaris => [colIdx => nilai]]
 * @param array<string,int>           $mapping field => colIdx
 * @return array{new:array,update:array,dup_db:int,dup_file:int,invalid:int,total:int,errors:array,errors_truncated:bool}
 */
function imp_validate_rows(string $type, array $rows, array $mapping, string $policy): array
{
    $fields = imp_fields($type);
    $ctx    = $type === 'employees' ? imp_ctx_employees() : imp_ctx_records();
    $out    = ['new' => [], 'update' => [], 'dup_db' => 0, 'dup_file' => 0, 'invalid' => 0, 'total' => count($rows), 'errors' => [], 'errors_truncated' => false];
    $seen   = [];
    $thisYm = date('Y-m');
    $today  = date('Y-m-d');

    foreach ($rows as $rowNo => $cells) {
        // Ambil nilai per field (string bersih) — IMP_FORMULA dipertahankan sebagai penanda.
        $vals = [];
        $raw  = [];
        foreach ($fields as $f => $def) {
            if (!isset($mapping[$f])) {
                $vals[$f] = '';
                continue;
            }
            $c = $cells[$mapping[$f]] ?? null;
            $vals[$f] = $c === IMP_FORMULA ? IMP_FORMULA : imp_cell_str($c);
            $raw[$def['label']] = $c === IMP_FORMULA ? '(rumus tanpa nilai)' : mb_substr($vals[$f], 0, 60);
        }

        $errs = [];
        $err = function (string $field, string $errType, string $msg, string $hint = '') use (&$errs, $fields): void {
            $errs[] = ['column' => $fields[$field]['label'] ?? $field, 'type' => $errType, 'severity' => 'error', 'message' => $msg, 'suggestion' => $hint];
        };

        // Sel berisi rumus tanpa nilai tersimpan
        foreach ($vals as $f => $v) {
            if ($v === IMP_FORMULA) {
                $err($f, 'other', 'Sel berisi rumus/galat tanpa nilai tersimpan sehingga tidak dapat dibaca.', 'Salin sebagai nilai (Paste Special > Values) lalu simpan ulang file.');
                $vals[$f] = '';
            }
        }

        $data = $type === 'employees'
            ? imp_row_employee($vals, $ctx, $err, $today)
            : imp_row_record($vals, $ctx, $err, $thisYm);

        $rawJson = mb_substr(json_encode($raw, JSON_UNESCAPED_UNICODE) ?: '', 0, 1000);

        if ($errs) {
            $out['invalid']++;
            foreach ($errs as $e) {
                imp_push_error($out, $rowNo, $e, $rawJson);
            }
            continue;
        }

        // Duplikat
        $key = $data['_key'];
        if (isset($seen[$key])) {
            $out['dup_file']++;
            imp_push_error($out, $rowNo, ['column' => $type === 'employees' ? 'ID Internal' : 'ID Internal + Periode', 'type' => 'duplicate', 'severity' => 'warning',
                'message' => "Mengulang data pada baris {$seen[$key]} dalam file yang sama; baris ini dilewati.", 'suggestion' => 'Hapus baris ganda dari file.'], $rawJson);
            continue;
        }
        $seen[$key] = $rowNo;

        if ($data['_exists']) {
            $out['dup_db']++;
            $upd = $policy === 'update';
            imp_push_error($out, $rowNo, ['column' => $type === 'employees' ? 'ID Internal' : 'ID Internal + Periode', 'type' => 'duplicate', 'severity' => 'warning',
                'message' => $upd ? 'Sudah ada di database; akan DIPERBARUI sesuai kebijakan yang Anda pilih.' : 'Sudah ada di database; baris ini dilewati.',
                'suggestion' => $upd ? '' : 'Pilih kebijakan "perbarui" bila ingin menimpa data lama.'], $rawJson);
            if ($upd) {
                $out['update'][$rowNo] = $data;
            }
            continue;
        }
        $out['new'][$rowNo] = $data;
    }
    return $out;
}

function imp_push_error(array &$out, int $rowNo, array $e, string $rawJson): void
{
    if (count($out['errors']) >= IMP_MAX_STORED_ERRORS) {
        $out['errors_truncated'] = true;
        return;
    }
    $out['errors'][] = $e + ['row' => $rowNo, 'raw' => $rawJson];
}

/** Validasi satu baris tenaga kerja. Mengembalikan data ternormalisasi (dengan _key, _exists). */
function imp_row_employee(array $v, array $ctx, callable $err, string $today): array
{
    $code = strtoupper($v['employee_code']);
    if ($code === '') {
        $err('employee_code', 'missing_required', 'ID Internal wajib diisi.');
    } elseif (!preg_match('/^[A-Z0-9][A-Z0-9._-]{1,29}$/', $code)) {
        $err('employee_code', 'other', "ID Internal \"{$v['employee_code']}\" tidak valid.", 'Gunakan 2–30 karakter: huruf, angka, titik, strip, garis bawah.');
    }
    $existing = $ctx['existing'][$code] ?? null;

    $name = $v['full_name'];
    if ($name === '') {
        $err('full_name', 'missing_required', 'Nama lengkap wajib diisi.');
    } elseif (!val_len($name, 2, 150)) {
        $err('full_name', 'other', 'Nama lengkap harus 2–150 karakter.');
    }

    $category = null;
    if ($v['category'] === '') {
        $err('category', 'missing_required', 'Kategori wajib diisi.');
    } elseif (($category = imp_norm_category($v['category'])) === null) {
        $err('category', 'invalid_enum', "Kategori \"{$v['category']}\" tidak dikenali.", 'Gunakan: Karyawan, TAD, atau Peserta magang.');
    }

    $deptId = null;
    if ($v['department'] === '') {
        $err('department', 'missing_required', 'Departemen wajib diisi.');
    } else {
        [$d, $msg] = imp_lookup($ctx['dept'], $v['department'], 'Departemen');
        if ($d === null) {
            $err('department', 'department_not_found', $msg, 'Tambahkan departemen terlebih dahulu di menu Departemen, atau perbaiki penulisannya.');
        } elseif ($d['status'] !== 'active' && (!$existing || (int) $existing['department_id'] !== (int) $d['id'])) {
            $err('department', 'department_not_found', "Departemen \"{$v['department']}\" nonaktif.", 'Gunakan departemen aktif.');
        } else {
            $deptId = (int) $d['id'];
        }
    }

    $vendorId = null;
    if ($category === 'tad') {
        if ($v['vendor'] === '') {
            $err('vendor', 'missing_required', 'Vendor wajib diisi untuk TAD.');
        } else {
            [$vd, $msg] = imp_lookup($ctx['vend'], $v['vendor'], 'Vendor');
            if ($vd === null) {
                $err('vendor', 'vendor_not_found', $msg, 'Tambahkan vendor terlebih dahulu di menu Vendor, atau perbaiki penulisannya.');
            } elseif ($vd['status'] !== 'active' && (!$existing || (int) ($existing['vendor_id'] ?? 0) !== (int) $vd['id'])) {
                $err('vendor', 'vendor_not_found', "Vendor \"{$v['vendor']}\" nonaktif.", 'Gunakan vendor aktif.');
            } else {
                $vendorId = (int) $vd['id'];
            }
        }
    } elseif ($category !== null && $v['vendor'] !== '') {
        $err('vendor', 'other', 'Vendor hanya berlaku untuk kategori TAD.', 'Kosongkan kolom vendor untuk kategori ini.');
    }

    if ($v['position'] === '') {
        $err('position', 'missing_required', 'Jabatan wajib diisi.');
    } elseif (!val_len($v['position'], 2, 120)) {
        $err('position', 'other', 'Jabatan harus 2–120 karakter.');
    }

    $start = null;
    if ($v['start_date'] === '') {
        $err('start_date', 'missing_required', 'Tanggal mulai wajib diisi.');
    } elseif (($start = imp_parse_date($v['start_date'])) === null) {
        $err('start_date', 'invalid_date', "Tanggal mulai \"{$v['start_date']}\" tidak valid.", 'Gunakan format YYYY-MM-DD atau DD/MM/YYYY.');
    }
    $end = null;
    $endBad = false;
    if ($v['end_date'] !== '' && ($end = imp_parse_date($v['end_date'])) === null) {
        $err('end_date', 'invalid_date', "Tanggal berakhir \"{$v['end_date']}\" tidak valid.", 'Gunakan format YYYY-MM-DD atau DD/MM/YYYY.');
        $endBad = true;
    }

    $status = 'active';
    if ($v['status'] !== '' && ($status = imp_norm_status($v['status'])) === null) {
        $err('status', 'invalid_enum', "Status \"{$v['status']}\" tidak dikenali.", 'Gunakan: Aktif, Tidak aktif, atau Selesai.');
    }

    if (!$endBad) {
        if ($start !== null && $end !== null && $end < $start) {
            $err('end_date', 'invalid_date', 'Tanggal berakhir tidak boleh sebelum tanggal mulai.');
        } elseif ($category === 'intern' && $end === null) {
            $err('end_date', 'missing_required', 'Peserta magang wajib memiliki tanggal berakhir.');
        } elseif ($status !== null && $status !== 'active' && $end === null) {
            $err('end_date', 'missing_required', 'Status ' . mb_strtolower(EMP_STATUSES[$status] ?? $status) . ' memerlukan tanggal berakhir.');
        } elseif ($status === 'active' && $end !== null && $end < $today) {
            $err('end_date', 'other', 'Tanggal berakhir sudah lewat tetapi status Aktif.', 'Ubah status menjadi Tidak aktif/Selesai atau perbaiki tanggal.');
        }
    }

    if (mb_strlen($v['notes']) > 2000) {
        $err('notes', 'other', 'Catatan maksimal 2.000 karakter.');
    }

    return [
        '_key' => $code, '_exists' => $existing !== null, 'employee_code' => $code, 'full_name' => $name, 'category' => $category,
        'department_id' => $deptId, 'vendor_id' => $vendorId, 'position' => $v['position'], 'start_date' => $start, 'end_date' => $end,
        'status' => $status, 'notes' => $v['notes'] === '' ? null : $v['notes'],
    ];
}

/** Validasi satu baris mandays. */
function imp_row_record(array $v, array $ctx, callable $err, string $thisYm): array
{
    $code = strtoupper($v['employee_code']);
    $emp = null;
    if ($code === '') {
        $err('employee_code', 'missing_required', 'ID Internal tenaga kerja wajib diisi.');
    } elseif (($emp = $ctx['emps'][$code] ?? null) === null) {
        $err('employee_code', 'other', "Tenaga kerja dengan ID \"{$v['employee_code']}\" tidak ditemukan.", 'Impor atau tambahkan data tenaga kerja terlebih dahulu.');
    }

    $ym = null;
    $days = 31;
    if ($v['period'] === '') {
        $err('period', 'missing_required', 'Periode wajib diisi.');
    } elseif (($ym = imp_parse_month($v['period'])) === null) {
        $err('period', 'invalid_date', "Periode \"{$v['period']}\" tidak valid.", 'Gunakan YYYY-MM, tanggal pada bulan tsb, atau "September 2026".');
    } elseif ($ym > $thisYm) {
        $err('period', 'other', 'Periode tidak boleh di masa depan.');
        $ym = null;
    } else {
        $days = (int) date('t', strtotime($ym . '-01'));
        if ($emp !== null && ($emp['start_date'] > $ym . '-' . $days || ($emp['end_date'] !== null && $emp['end_date'] < $ym . '-01'))) {
            $err('period', 'other', 'Tenaga kerja tidak aktif pada periode ini (aktif ' . fmt_date($emp['start_date']) . ' s/d ' . ($emp['end_date'] ? fmt_date($emp['end_date']) : 'berjalan') . ').');
        }
    }

    $mandays = null;
    if ($v['mandays'] === '') {
        $err('mandays', 'missing_required', 'Mandays wajib diisi.');
    } elseif (($mandays = val_decimal($v['mandays'], (float) $days)) === null) {
        $err('mandays', 'invalid_number', "Mandays \"{$v['mandays']}\" tidak valid.", "Gunakan angka 0–{$days} dengan maksimal 2 desimal.");
    }

    $sched = $att = null;
    if ($v['scheduled_days'] !== '' || $v['attended_days'] !== '') {
        if ($v['scheduled_days'] === '' || $v['attended_days'] === '') {
            $err($v['scheduled_days'] === '' ? 'scheduled_days' : 'attended_days', 'missing_required', 'Hari terjadwal dan hari hadir harus diisi berpasangan atau dikosongkan keduanya.', 'Kosongkan keduanya bila data kehadiran tidak tersedia.');
        } else {
            $sched = val_decimal($v['scheduled_days'], (float) $days);
            $att   = val_decimal($v['attended_days'], (float) $days);
            if ($sched === null) { $err('scheduled_days', 'invalid_number', "Hari terjadwal \"{$v['scheduled_days']}\" tidak valid.", "Gunakan angka 0–{$days}."); }
            if ($att === null)   { $err('attended_days', 'invalid_number', "Hari hadir \"{$v['attended_days']}\" tidak valid.", "Gunakan angka 0–{$days}."); }
            if ($sched !== null && $att !== null && (float) $att > (float) $sched) {
                $err('attended_days', 'other', 'Hari hadir tidak boleh melebihi hari terjadwal.');
            }
        }
    }
    if (mb_strlen($v['notes']) > 255) {
        $err('notes', 'other', 'Keterangan maksimal 255 karakter.');
    }

    $key = ($emp['id'] ?? 0) . '|' . ($ym ?? '');
    return [
        '_key' => $key, '_exists' => isset($ctx['existing'][$key]), 'employee_id' => (int) ($emp['id'] ?? 0), 'period_month' => ($ym ?? '') . '-01',
        'mandays' => $mandays, 'scheduled_days' => $sched, 'attended_days' => $att, 'notes' => $v['notes'] === '' ? null : $v['notes'],
    ];
}
