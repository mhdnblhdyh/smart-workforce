<?php
/**
 * Alur impor: validasi (dry-run) -> simpan hasil validasi -> eksekusi dalam satu transaksi.
 *
 * - Validasi tidak mengubah data tenaga kerja/mandays; hanya menulis import_errors dan angka ringkasan batch.
 * - Saat konfirmasi, file DIBACA ULANG dan divalidasi ulang (data di database bisa berubah sejak validasi).
 *   Bila hasilnya berbeda dari yang dilihat pengguna, import dibatalkan dan hasil baru ditampilkan.
 * - Eksekusi memakai transaksi + insert massal berparameter (250 baris per query). Kegagalan apa pun => ROLLBACK penuh.
 * - Data lama tidak ditimpa kecuali kebijakan "update" dipilih eksplisit.
 */
declare(strict_types=1);

/** Pesan galat yang aman ditampilkan ke pengguna. */
final class ImportUserError extends RuntimeException
{
}

const IMP_CHUNK = 250;

/** Periksa kelengkapan pemetaan. @return ?string pesan galat atau null bila valid */
function imp_check_mapping(string $type, array $mapping, array $headers): ?string
{
    $used = [];
    foreach (imp_fields($type) as $field => $def) {
        if (!isset($mapping[$field])) {
            if ($def['required']) {
                return "Kolom wajib \"{$def['label']}\" belum dipetakan.";
            }
            continue;
        }
        $idx = $mapping[$field];
        if (!is_int($idx) || !isset($headers[$idx])) {
            return "Kolom untuk \"{$def['label']}\" tidak ditemukan pada file.";
        }
        if (isset($used[$idx])) {
            return 'Satu kolom file tidak boleh dipakai untuk dua field berbeda (kolom ' . imp_col_letter($idx) . ').';
        }
        $used[$idx] = true;
    }
    return null;
}

/** Baca file batch dan validasi seluruh baris. Tidak menulis ke database. */
function imp_run_validation(array $batch): array
{
    $path = imp_file_path($batch);
    if ($path === null) {
        throw new ImportUserError('File sementara tidak ditemukan atau sudah dihapus. Unggah ulang file Anda.');
    }
    $meta = imp_meta($batch);
    try {
        $sheet = imp_read_sheet($path, $meta['ext']);
    } catch (Throwable $e) {
        error_log('[IMPORT] Gagal membaca file batch #' . $batch['id'] . ': ' . $e->getMessage());
        throw new ImportUserError('File tidak dapat dibaca. Pastikan file Excel/CSV tidak rusak atau terkunci sandi.');
    }
    $headerRow = (int) $meta['header_row'];
    if (imp_exceeds_row_limit($sheet, $headerRow)) {
        throw new ImportUserError('File memiliki lebih dari ' . format_number(imp_max_rows(), 0) . ' baris data. Pecah file menjadi beberapa bagian.');
    }
    $headers = imp_headers($sheet, $headerRow);
    if (!$headers) {
        throw new ImportUserError("Baris judul kolom ke-{$headerRow} kosong. Periksa nomor baris judul.");
    }
    $mapping = array_map('intval', (array) $meta['mapping']);
    if ($msg = imp_check_mapping($batch['import_type'], $mapping, $headers)) {
        throw new ImportUserError($msg);
    }
    $rows = imp_data_rows($sheet, $headerRow);
    if (!$rows) {
        throw new ImportUserError('File tidak memiliki baris data setelah baris judul.');
    }
    $result = imp_validate_rows($batch['import_type'], $rows, $mapping, (string) $batch['duplicate_policy']);
    $result['sheet'] = $sheet['sheet'];
    return $result;
}

/** Simpan hasil validasi (kesalahan per baris + angka ringkasan) dan tandai batch 'validated'. */
function imp_store_validation(int $batchId, array $r, array $meta): void
{
    $conn = db();
    $conn->begin_transaction();
    try {
        db_run('DELETE FROM import_errors WHERE batch_id = ?', 'i', [$batchId]);
        foreach (array_chunk($r['errors'], 200) as $chunk) {
            $ph = implode(',', array_fill(0, count($chunk), '(?,?,?,?,?,?,?,?)'));
            $params = [];
            foreach ($chunk as $e) {
                array_push($params, $batchId, $e['row'], mb_substr($e['column'], 0, 100), $e['type'], $e['severity'], mb_substr($e['message'], 0, 500), $e['suggestion'] !== '' ? mb_substr($e['suggestion'], 0, 500) : null, $e['raw']);
            }
            db_run("INSERT INTO import_errors (batch_id, `row_number`, column_name, error_type, severity, message, suggestion, raw_data) VALUES {$ph}", str_repeat('iisssss' . 's', count($chunk)), $params);
        }
        $meta['sheet'] = $r['sheet'];
        $meta['stats'] = [
            'new' => count($r['new']), 'update' => count($r['update']), 'dup_db' => $r['dup_db'], 'dup_file' => $r['dup_file'],
            'invalid' => $r['invalid'], 'errors_truncated' => $r['errors_truncated'],
        ];
        db_run(
            "UPDATE import_batches SET total_rows = ?, valid_rows = ?, duplicate_rows = ?, invalid_rows = ?, status = 'validated', error_message = NULL, column_mapping = ? WHERE id = ?",
            'iiiisi',
            [$r['total'], count($r['new']), $r['dup_db'] + $r['dup_file'], $r['invalid'], json_encode($meta, JSON_UNESCAPED_UNICODE), $batchId]
        );
        $conn->commit();
    } catch (Throwable $e) {
        $conn->rollback();
        throw $e;
    }
}

/** Validasi batch lalu simpan hasilnya. */
function imp_validate_batch(array $batch): array
{
    $r = imp_run_validation($batch);
    imp_store_validation((int) $batch['id'], $r, imp_meta($batch));
    return $r;
}

/** INSERT massal berparameter; $types = tipe bind_param untuk SATU baris. Nama tabel/kolom hanya dari konstanta kode. */
function imp_bulk(string $table, array $cols, string $types, array $rowsParams, string $suffix = ''): void
{
    foreach (array_chunk($rowsParams, IMP_CHUNK) as $chunk) {
        $ph = '(' . implode(',', array_fill(0, count($cols), '?')) . ')';
        $sql = "INSERT INTO `{$table}` (`" . implode('`,`', $cols) . '`) VALUES ' . implode(',', array_fill(0, count($chunk), $ph)) . ' ' . $suffix;
        db_run($sql, str_repeat($types, count($chunk)), array_merge(...$chunk));
    }
}

/**
 * Eksekusi impor. @return array{inserted:int,updated:int,skipped:int,invalid:int}
 * @throws ImportUserError bila impor tidak dapat dilakukan (tidak ada data yang tersimpan).
 */
function imp_execute_batch(array $batch, int $userId): array
{
    $id = (int) $batch['id'];
    if ($batch['status'] !== 'validated') {
        throw new ImportUserError('Batch ini tidak berada pada tahap menunggu konfirmasi.');
    }

    $fresh = imp_run_validation($batch);
    $meta  = imp_meta($batch);
    $st    = $meta['stats'];
    if (count($fresh['new']) !== ($st['new'] ?? -1) || count($fresh['update']) !== ($st['update'] ?? -1)
        || $fresh['invalid'] !== ($st['invalid'] ?? -1) || $fresh['dup_db'] !== ($st['dup_db'] ?? -1)) {
        imp_store_validation($id, $fresh, $meta);
        throw new ImportUserError('Data di database berubah sejak validasi, sehingga hasilnya berbeda. Validasi diulang otomatis; tinjau ringkasan terbaru lalu konfirmasi lagi. Tidak ada data yang diimpor.');
    }

    $type = $batch['import_type'];
    $conn = db();
    $conn->begin_transaction();
    try {
        $locked = db_value('SELECT status FROM import_batches WHERE id = ? FOR UPDATE', 'i', [$id]);
        if ($locked !== 'validated') {
            throw new ImportUserError('Batch ini sudah diproses.');
        }

        if ($type === 'employees') {
            $toRow = fn (array $d): array => [$d['employee_code'], $d['full_name'], $d['category'], $d['department_id'], $d['vendor_id'], $d['position'], $d['start_date'], $d['end_date'], $d['status'], $d['notes'], $userId];
            $cols = ['employee_code', 'full_name', 'category', 'department_id', 'vendor_id', 'position', 'start_date', 'end_date', 'status', 'notes', 'created_by'];
            $tp = 'sssiisssssi';
            $upd = 'ON DUPLICATE KEY UPDATE full_name = VALUES(full_name), category = VALUES(category), department_id = VALUES(department_id), vendor_id = VALUES(vendor_id), position = VALUES(position), start_date = VALUES(start_date), end_date = VALUES(end_date), status = VALUES(status), notes = VALUES(notes)';
            imp_bulk('employees', $cols, $tp, array_map($toRow, array_values($fresh['new'])));
            imp_bulk('employees', $cols, $tp, array_map($toRow, array_values($fresh['update'])), $upd);
        } else {
            $toRow = fn (array $d): array => [$d['employee_id'], $d['period_month'], $d['mandays'], $d['scheduled_days'], $d['attended_days'], $d['notes'], 'import', $id, $userId];
            $cols = ['employee_id', 'period_month', 'mandays', 'scheduled_days', 'attended_days', 'notes', 'source', 'import_batch_id', 'created_by'];
            $tp = 'issssssii';
            $upd = "ON DUPLICATE KEY UPDATE mandays = VALUES(mandays), scheduled_days = VALUES(scheduled_days), attended_days = VALUES(attended_days), notes = VALUES(notes), source = 'import', import_batch_id = VALUES(import_batch_id)";
            imp_bulk('workforce_records', $cols, $tp, array_map($toRow, array_values($fresh['new'])));
            imp_bulk('workforce_records', $cols, $tp, array_map($toRow, array_values($fresh['update'])), $upd);
        }

        $inserted = count($fresh['new']);
        $updated  = count($fresh['update']);
        $meta['stats'] += ['inserted' => $inserted, 'updated' => $updated];
        $meta['stats']['inserted'] = $inserted;
        $meta['stats']['updated']  = $updated;
        db_run(
            "UPDATE import_batches SET status = 'completed', imported_rows = ?, completed_at = NOW(), error_message = NULL, column_mapping = ? WHERE id = ?",
            'isi',
            [$inserted + $updated, json_encode($meta, JSON_UNESCAPED_UNICODE), $id]
        );
        $conn->commit();
    } catch (Throwable $e) {
        $conn->rollback();
        if ($e instanceof ImportUserError) {
            throw $e;
        }
        error_log('[IMPORT] Batch #' . $id . ' gagal dan di-rollback: ' . $e->getMessage());
        db_run("UPDATE import_batches SET status = 'failed', imported_rows = 0, error_message = ? WHERE id = ? AND status = 'validated'", 'si',
            ['Import dibatalkan karena terjadi kesalahan saat menyimpan. Tidak ada data yang tersimpan (rollback).', $id]);
        audit_log('import_failed', 'import_batch', $id, 'Import gagal dan di-rollback: ' . $batch['original_name'], $userId);
        imp_delete_file($batch);
        throw new ImportUserError('Import gagal karena kesalahan saat menyimpan data. Seluruh perubahan dibatalkan (rollback); tidak ada data yang tersimpan.');
    }

    imp_delete_file($batch);
    audit_log('import', 'import_batch', $id, sprintf('Import %s selesai: %d baru, %d diperbarui, %d dilewati, %d tidak valid (%s)',
        IMPORT_TYPES[$type], $inserted, $updated, $fresh['dup_db'] + $fresh['dup_file'] - $updated, $fresh['invalid'], $batch['original_name']), $userId);

    return ['inserted' => $inserted, 'updated' => $updated, 'skipped' => $fresh['dup_db'] + $fresh['dup_file'] - $updated, 'invalid' => $fresh['invalid']];
}
