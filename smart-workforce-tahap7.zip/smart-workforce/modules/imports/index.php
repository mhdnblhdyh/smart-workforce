<?php
declare(strict_types=1);
require_once dirname(__DIR__, 2) . '/includes/bootstrap.php';
require_once dirname(__DIR__) . '/employees/repo.php';
require_once __DIR__ . '/schema.php';
require_once __DIR__ . '/reader.php';
require_once __DIR__ . '/repo.php';

$user = require_permission('import.run');
imp_cleanup_stale();

$libOk   = imp_lib_available();
$pending = db_fetch_all("SELECT b.*, u.name AS user_name FROM import_batches b LEFT JOIN users u ON u.id = b.imported_by WHERE b.status IN ('uploaded','validated') ORDER BY b.id DESC LIMIT 5");
$recent  = db_fetch_all("SELECT b.*, u.name AS user_name FROM import_batches b LEFT JOIN users u ON u.id = b.imported_by WHERE b.status IN ('completed','failed') ORDER BY b.id DESC LIMIT 5");
$maxMb   = (int) round(imp_max_file_bytes() / 1048576);

$page = ['title' => 'Import Excel', 'active' => 'import', 'breadcrumb' => ['Data Intelligence', 'Import Excel'], 'css' => ['crud.css', 'import.css'], 'js' => ['import.js']];
require BASE_PATH . '/includes/header.php';
?>
<section class="crud-page">
    <div class="page-header">
        <div><h1>Import Excel</h1><p class="page-sub">Unggah file Excel (.xlsx) atau CSV, petakan kolom, periksa hasil validasi, lalu konfirmasi sebelum data disimpan.</p></div>
    </div>

    <?= ui_stepper(['Unggah file', 'Pemetaan kolom', 'Validasi & tinjau', 'Hasil import'], 1) ?>

    <?php if (!$libOk): ?>
        <div class="notice notice-warning" role="alert"><?= icon('triangle-alert') ?>
            <div><strong>PhpSpreadsheet belum terpasang.</strong> Buka terminal di folder proyek lalu jalankan <code>composer install</code> (butuh PHP 8.2+ dengan ekstensi zip, gd, xml). Setelah itu muat ulang halaman ini.</div></div>
    <?php endif; ?>

    <form class="card upload-card" method="post" action="<?= e(url('modules/imports/upload.php')) ?>" enctype="multipart/form-data" id="uploadForm">
        <?= csrf_field() ?>
        <h2>1. Pilih jenis data</h2>
        <div class="type-cards" role="radiogroup" aria-label="Jenis data">
            <?php foreach ([
                'employees' => ['users', 'Data Tenaga Kerja', 'Tambah atau perbarui karyawan, TAD, dan peserta magang. Kunci: ID Internal.'],
                'workforce_records' => ['calendar-check', 'Mandays & Kehadiran', 'Record bulanan per tenaga kerja. Kunci: ID Internal + Periode. Tenaga kerja harus sudah terdaftar.'],
            ] as $key => [$ic, $title, $desc]): ?>
                <label class="type-card">
                    <input type="radio" name="import_type" value="<?= e($key) ?>" <?= $key === 'employees' ? 'checked' : '' ?> required>
                    <span class="type-body"><span class="type-icon"><?= icon($ic) ?></span><strong><?= e($title) ?></strong><small><?= e($desc) ?></small>
                        <a class="type-tpl" href="<?= e(url('modules/imports/template.php?type=' . $key)) ?>"><?= icon('download') ?>Unduh templat .xlsx</a></span>
                </label>
            <?php endforeach; ?>
        </div>

        <h2>2. Pilih file</h2>
        <label class="dropzone" id="dropzone">
            <?= icon('file-spreadsheet') ?>
            <strong id="fileLabel">Klik untuk memilih file (.xlsx / .csv)</strong>
            <small>Maksimal <?= $maxMb ?> MB dan <?= e(format_number(imp_max_rows(), 0)) ?> baris data. Hanya sheet pertama yang dibaca; judul kolom ada di baris pertama (dapat diubah di langkah berikutnya).</small>
            <input type="file" name="file" id="fileInput" accept=".xlsx,.csv" required data-max-bytes="<?= (int) imp_max_file_bytes() ?>" <?= $libOk ? '' : 'disabled' ?>>
        </label>
        <p class="field-error" id="fileError" role="alert"></p>

        <div class="upload-foot">
            <p class="muted-note">File disimpan sementara di server, dihapus setelah diproses, dan isinya tidak pernah dieksekusi. Rumus tidak dihitung; hanya nilai tersimpan yang dibaca.</p>
            <button type="submit" class="btn btn-primary" id="uploadSubmit" <?= $libOk ? '' : 'disabled' ?>><?= icon('chevron-right') ?>Unggah & lanjut</button>
        </div>
    </form>

    <?php if ($pending): ?>
    <article class="card table-card section-card">
        <header class="card-head" style="padding:18px 22px 0"><div><h2>Import yang belum selesai</h2><p>Lanjutkan atau batalkan. Batch yang tidak dikonfirmasi dibatalkan otomatis setelah <?= IMP_STALE_HOURS ?> jam.</p></div></header>
        <div class="table-scroll"><table class="table"><thead><tr><th>File</th><th>Jenis</th><th>Diunggah</th><th>Status</th><th class="col-actions"></th></tr></thead><tbody>
        <?php foreach ($pending as $b): ?>
            <tr><td><strong><?= e($b['original_name']) ?></strong><span class="cell-sub"><?= e(format_number($b['file_size'] / 1024, 0)) ?> KB · <?= e($b['user_name'] ?? '-') ?></span></td>
                <td><?= e(IMPORT_TYPES[$b['import_type']] ?? $b['import_type']) ?></td><td><?= e(format_datetime($b['created_at'])) ?></td><td><?= imp_status_badge($b['status']) ?></td>
                <td class="col-actions"><a class="btn btn-outline btn-sm" href="<?= e(url('modules/imports/' . ($b['status'] === 'validated' ? 'review' : 'map') . '.php?id=' . (int) $b['id'])) ?>">Lanjutkan</a></td></tr>
        <?php endforeach; ?></tbody></table></div>
    </article>
    <?php endif; ?>

    <?php if ($recent): ?>
    <article class="card table-card section-card">
        <header class="card-head" style="padding:18px 22px 0"><div><h2>Import terakhir</h2><p><a href="<?= e(url('modules/imports/history.php')) ?>">Lihat seluruh riwayat</a></p></div></header>
        <div class="table-scroll"><table class="table"><thead><tr><th>File</th><th>Jenis</th><th class="num">Diimpor</th><th>Status</th><th>Waktu</th></tr></thead><tbody>
        <?php foreach ($recent as $b): ?>
            <tr><td><a href="<?= e(url('modules/imports/review.php?id=' . (int) $b['id'])) ?>"><strong><?= e($b['original_name']) ?></strong></a></td><td><?= e(IMPORT_TYPES[$b['import_type']] ?? '') ?></td>
                <td class="num"><?= e(format_number($b['imported_rows'], 0)) ?> / <?= e(format_number($b['total_rows'], 0)) ?></td><td><?= imp_status_badge($b['status']) ?></td><td><?= e(format_datetime($b['completed_at'] ?? $b['created_at'])) ?></td></tr>
        <?php endforeach; ?></tbody></table></div>
    </article>
    <?php endif; ?>
</section>
<?php require BASE_PATH . '/includes/footer.php'; ?>
