<?php
/**
 * Validasi unggahan dan pembacaan file Excel/CSV memakai PhpSpreadsheet.
 *
 * KEAMANAN:
 *  - Hanya .xlsx dan .csv. Ekstensi, MIME (finfo), dan struktur isi diperiksa; ekstensi saja tidak dipercaya.
 *  - Isi file TIDAK pernah dieksekusi. Rumus tidak dihitung: hanya nilai tersimpan (cache) yang dibaca;
 *    rumus tanpa nilai tersimpan ditandai IMP_FORMULA dan baris tsb ditolak.
 *  - File disimpan di storage/imports dengan nama acak (tidak bisa diakses lewat browser) dan dihapus setelah diproses.
 *  - Batas ukuran file, jumlah entri ZIP, ukuran tidak terkompres, dan jumlah baris/kolom yang dibaca.
 */
declare(strict_types=1);

use PhpOffice\PhpSpreadsheet\Cell\Coordinate;
use PhpOffice\PhpSpreadsheet\IOFactory;
use PhpOffice\PhpSpreadsheet\Reader\Csv as CsvReader;
use PhpOffice\PhpSpreadsheet\Reader\Xlsx as XlsxReader;
use PhpOffice\PhpSpreadsheet\RichText\RichText;
use PhpOffice\PhpSpreadsheet\Shared\Date as XlDate;

const IMP_MAX_COLUMNS = 60;
const IMP_MAX_HEADER_ROW = 20;

/** Muat PhpSpreadsheet (Composer). Mengembalikan false jika belum terpasang. */
function imp_lib_available(): bool
{
    static $ok = null;
    if ($ok === null) {
        $autoload = BASE_PATH . '/vendor/autoload.php';
        if (is_file($autoload)) {
            require_once $autoload;
        }
        $ok = class_exists(IOFactory::class);
        if ($ok) {
            // Kelas ini mengimplementasikan interface PhpSpreadsheet sehingga baru boleh dimuat setelah autoloader aktif.
            require_once __DIR__ . '/readfilter.php';
        }
    }
    return $ok;
}

function imp_max_file_bytes(): int
{
    return max(1, (int) setting_get('import_max_file_mb', '10')) * 1024 * 1024;
}

function imp_max_rows(): int
{
    return max(1, (int) setting_get('import_max_rows', '5000'));
}

function imp_storage_dir(): string
{
    $dir = BASE_PATH . '/storage/imports';
    if (!is_dir($dir)) {
        mkdir($dir, 0750, true);
    }
    return $dir;
}

/** Naikkan batas memori/waktu secukupnya untuk membaca file besar. */
function imp_prepare_resources(): void
{
    $limit = ini_get('memory_limit');
    if ($limit !== '-1') {
        $bytes = (int) $limit * (stripos($limit, 'g') !== false ? 1073741824 : (stripos($limit, 'm') !== false ? 1048576 : (stripos($limit, 'k') !== false ? 1024 : 1)));
        if ($bytes < 256 * 1048576) {
            ini_set('memory_limit', '256M');
        }
    }
    @set_time_limit(120);
}

/**
 * Validasi file unggahan ($_FILES['x']). @return array{0:?array,1:?string} [info, pesan kesalahan]
 * info = ['ext','mime','name','size']
 */
function imp_validate_upload(?array $file): array
{
    if ($file === null || !isset($file['error'])) {
        return [null, 'Pilih file yang akan diunggah.'];
    }
    $uploadErrors = [
        UPLOAD_ERR_INI_SIZE => 'Ukuran file melebihi batas server (upload_max_filesize di php.ini).', UPLOAD_ERR_FORM_SIZE => 'Ukuran file terlalu besar.',
        UPLOAD_ERR_PARTIAL => 'File hanya terunggah sebagian. Coba lagi.', UPLOAD_ERR_NO_FILE => 'Pilih file yang akan diunggah.',
        UPLOAD_ERR_NO_TMP_DIR => 'Folder sementara server tidak tersedia.', UPLOAD_ERR_CANT_WRITE => 'Server gagal menyimpan file.', UPLOAD_ERR_EXTENSION => 'Unggahan dihentikan oleh ekstensi PHP.',
    ];
    if ($file['error'] !== UPLOAD_ERR_OK) {
        return [null, $uploadErrors[$file['error']] ?? 'Unggahan gagal.'];
    }
    if (!is_uploaded_file($file['tmp_name'])) {
        return [null, 'Unggahan tidak valid.'];
    }

    $size = (int) $file['size'];
    if ($size <= 0) {
        return [null, 'File kosong.'];
    }
    if ($size > imp_max_file_bytes()) {
        return [null, 'Ukuran file melebihi batas ' . format_number(imp_max_file_bytes() / 1048576, 0) . ' MB.'];
    }

    $name = preg_replace('/[\x00-\x1F\x7F]/', '', basename((string) $file['name'])) ?? '';
    $ext  = strtolower(pathinfo($name, PATHINFO_EXTENSION));
    if (!in_array($ext, ['xlsx', 'csv'], true)) {
        return [null, 'Format file harus .xlsx atau .csv. Simpan file Excel lama (.xls) sebagai .xlsx terlebih dahulu.'];
    }

    $finfo = new finfo(FILEINFO_MIME_TYPE);
    $mime  = (string) $finfo->file($file['tmp_name']);
    $okMime = $ext === 'xlsx'
        ? ['application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', 'application/zip', 'application/x-zip-compressed', 'application/octet-stream']
        : ['text/plain', 'text/csv', 'application/csv', 'application/vnd.ms-excel', 'text/x-csv'];
    if (!in_array($mime, $okMime, true)) {
        return [null, "Isi file tidak sesuai dengan ekstensi .{$ext} (terdeteksi: {$mime})."];
    }

    if ($ext === 'xlsx') {
        if (!class_exists('ZipArchive')) {
            return [null, 'Ekstensi PHP zip belum aktif di server.'];
        }
        $zip = new ZipArchive();
        if ($zip->open($file['tmp_name'], ZipArchive::RDONLY) !== true) {
            return [null, 'File .xlsx rusak atau bukan file Excel yang valid.'];
        }
        $entries = $zip->numFiles;
        $total = 0;
        $names = [];
        for ($i = 0; $i < $entries && $i < 2000; $i++) {
            $st = $zip->statIndex($i);
            $total += (int) ($st['size'] ?? 0);
            $names[] = (string) ($st['name'] ?? '');
        }
        $zip->close();
        if ($entries > 500 || $total > 200 * 1048576) {
            return [null, 'Struktur file tidak wajar (terlalu banyak entri atau terlalu besar saat diekstrak).'];
        }
        if (!in_array('[Content_Types].xml', $names, true) || !in_array('xl/workbook.xml', $names, true)) {
            return [null, 'File bukan workbook Excel (.xlsx) yang valid.'];
        }
        foreach ($names as $n) {
            if (stripos($n, 'vbaProject') !== false) {
                return [null, 'File berisi makro. Simpan sebagai .xlsx tanpa makro.'];
            }
        }
    } else {
        $head = (string) file_get_contents($file['tmp_name'], false, null, 0, 8192);
        if (str_contains($head, "\0")) {
            return [null, 'File bukan teks CSV yang valid (mengandung data biner).'];
        }
    }

    return [['ext' => $ext, 'mime' => $mime, 'name' => mb_substr($name, 0, 250), 'size' => $size], null];
}

/** Simpan file unggahan ke storage dengan nama acak. Mengembalikan nama tersimpan. */
function imp_store_upload(string $tmpPath, string $ext): string
{
    $stored = 'imp_' . bin2hex(random_bytes(16)) . '.' . $ext;
    $dest = imp_storage_dir() . '/' . $stored;
    if (!move_uploaded_file($tmpPath, $dest)) {
        throw new RuntimeException('Gagal memindahkan file unggahan.');
    }
    @chmod($dest, 0640);
    return $stored;
}

/**
 * Baca sheet pertama. Baris kosong dilewati. Nilai sel: string|float|null, atau IMP_FORMULA.
 * Sel berformat tanggal dikonversi ke 'Y-m-d'.
 *
 * @return array{sheet:string,rows:array<int,array<int,mixed>>,highest_row:int,read_limit:int}
 *         rows[nomorBarisExcel][indeksKolom0] = nilai
 */
function imp_read_sheet(string $path, string $ext): array
{
    if (!imp_lib_available()) {
        throw new RuntimeException('PhpSpreadsheet belum terpasang (jalankan "composer install").');
    }
    imp_prepare_resources();

    $limit = IMP_MAX_HEADER_ROW + imp_max_rows() + 5;

    if ($ext === 'csv') {
        $sample = (string) file_get_contents($path, false, null, 0, 16384);
        $reader = new CsvReader();
        $reader->setDelimiter(imp_detect_delimiter($sample));
        $reader->setInputEncoding(mb_check_encoding($sample, 'UTF-8') ? 'UTF-8' : 'Windows-1252');
        $sheetName = 'CSV';
    } else {
        $reader = new XlsxReader();
        $names = $reader->listWorksheetNames($path);
        if (!$names) {
            throw new RuntimeException('Workbook tidak memiliki sheet.');
        }
        $reader->setLoadSheetsOnly([$names[0]]);
        $sheetName = (string) $names[0];
    }
    $reader->setReadDataOnly(false);   // butuh format angka untuk mengenali sel tanggal
    $reader->setReadEmptyCells(false);
    $reader->setReadFilter(new ImportReadFilter($limit));

    $spreadsheet = $reader->load($path);
    $ws = $spreadsheet->getSheet(0);
    $highest = $ws->getHighestDataRow();

    $rows = [];
    foreach ($ws->getRowIterator(1, max(1, $highest)) as $row) {
        $cells = [];
        $it = $row->getCellIterator();
        $it->setIterateOnlyExistingCells(true);
        foreach ($it as $cell) {
            $idx = Coordinate::columnIndexFromString($cell->getColumn()) - 1;
            if ($cell->isFormula()) {
                $v = $cell->getOldCalculatedValue();            // nilai tersimpan di file; rumus TIDAK dihitung
                $v = ($v === null || $v === '') ? IMP_FORMULA : $v;
            } else {
                $v = $cell->getValue();
            }
            if ($v instanceof RichText) {
                $v = $v->getPlainText();
            }
            if ($v !== IMP_FORMULA && (is_int($v) || is_float($v)) && !$cell->isFormula() && XlDate::isDateTime($cell)) {
                $v = XlDate::excelToDateTimeObject((float) $v)->format('Y-m-d');
            }
            if (is_string($v) && str_starts_with($v, '#') && preg_match('/^#(N\/A|REF!|VALUE!|DIV\/0!|NAME\?|NUM!|NULL!)$/', $v)) {
                $v = IMP_FORMULA;                                // nilai galat Excel dianggap tidak dapat dipakai
            }
            $cells[$idx] = $v;
        }
        if (array_filter($cells, fn ($c) => $c !== null && $c !== '')) {
            $rows[$row->getRowIndex()] = $cells;
        }
    }
    $spreadsheet->disconnectWorksheets();
    unset($spreadsheet);

    return ['sheet' => $sheetName, 'rows' => $rows, 'highest_row' => $highest, 'read_limit' => $limit];
}

/** Deteksi pemisah CSV dari contoh teks. */
function imp_detect_delimiter(string $sample): string
{
    $best = ',';
    $max = -1;
    foreach ([',', ';', "\t", '|'] as $d) {
        $n = substr_count($sample, $d);
        if ($n > $max) {
            $max = $n;
            $best = $d;
        }
    }
    return $best;
}

/** Baris header: colIdx => teks (hanya kolom non-kosong). */
function imp_headers(array $sheet, int $headerRow): array
{
    $out = [];
    foreach (($sheet['rows'][$headerRow] ?? []) as $idx => $v) {
        $s = $v === IMP_FORMULA ? '' : imp_cell_str($v);
        if ($s !== '') {
            $out[$idx] = mb_substr($s, 0, 80);
        }
    }
    ksort($out);
    return $out;
}

/** Baris data (setelah header) sebagai [nomorBaris => [colIdx => nilai]]. */
function imp_data_rows(array $sheet, int $headerRow): array
{
    return array_filter($sheet['rows'], fn ($k) => $k > $headerRow, ARRAY_FILTER_USE_KEY);
}

/** True bila file memiliki baris data lebih banyak dari batas. */
function imp_exceeds_row_limit(array $sheet, int $headerRow): bool
{
    return count(imp_data_rows($sheet, $headerRow)) > imp_max_rows() || $sheet['highest_row'] >= $sheet['read_limit'];
}

/** Huruf kolom Excel dari indeks 0 (0 => A). */
function imp_col_letter(int $idx): string
{
    return Coordinate::stringFromColumnIndex($idx + 1);
}
