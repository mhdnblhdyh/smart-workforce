<?php
declare(strict_types=1);
require_once dirname(__DIR__, 2) . '/includes/bootstrap.php';
require_once dirname(__DIR__) . '/employees/repo.php';
require_once __DIR__ . '/schema.php';
require_once __DIR__ . '/reader.php';
require_once __DIR__ . '/repo.php';
require_once __DIR__ . '/validator.php';
require_once __DIR__ . '/runner.php';

$user = require_permission('import.run');
if (!is_post()) {
    redirect('modules/imports/index.php');
}
csrf_require();

$id = (isset($_POST['id']) && ctype_digit((string) $_POST['id'])) ? (int) $_POST['id'] : 0;
$batch = $id > 0 ? imp_batch_find($id) : null;
if ($batch === null) {
    flash_set('danger', 'Batch impor tidak ditemukan.');
    redirect('modules/imports/index.php');
}
$back = 'modules/imports/review.php?id=' . $id;
if (empty($_POST['ack'])) {
    flash_set('warning', 'Centang konfirmasi terlebih dahulu.');
    redirect($back);
}

try {
    $res = imp_execute_batch($batch, (int) $user['id']);
    flash_set('success', sprintf('Import selesai: %s baris baru%s.', format_number($res['inserted'], 0), $res['updated'] > 0 ? ', ' . format_number($res['updated'], 0) . ' diperbarui' : ''));
} catch (ImportUserError $e) {
    flash_set('danger', $e->getMessage());
} catch (Throwable $e) {
    error_log('[IMPORT] Konfirmasi batch #' . $id . ' error: ' . $e->getMessage() . ' @ ' . $e->getFile() . ':' . $e->getLine());
    flash_set('danger', 'Import gagal karena kesalahan di server. Tidak ada data yang diubah.');
}
redirect($back);
