<?php
/** Filter baca PhpSpreadsheet: batasi baris dan kolom agar memori terkendali. Dimuat oleh imp_lib_available(). */
declare(strict_types=1);

use PhpOffice\PhpSpreadsheet\Cell\Coordinate;
use PhpOffice\PhpSpreadsheet\Reader\IReadFilter;

final class ImportReadFilter implements IReadFilter
{
    public function __construct(private int $maxRow)
    {
    }

    public function readCell(string $columnAddress, int $row, string $worksheetName = ''): bool
    {
        return $row <= $this->maxRow && Coordinate::columnIndexFromString($columnAddress) <= IMP_MAX_COLUMNS;
    }
}
