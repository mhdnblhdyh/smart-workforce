<?php
/** Unduh templat .xlsx (dibuat langsung, tidak disimpan di server). */
declare(strict_types=1);
require_once dirname(__DIR__, 2) . '/includes/bootstrap.php';
require_once dirname(__DIR__) . '/employees/repo.php';
require_once __DIR__ . '/schema.php';
require_once __DIR__ . '/reader.php';

require_permission('import.run');
$type = (isset($_GET['type']) && is_string($_GET['type'])) ? $_GET['type'] : '';
if (!isset(IMPORT_TYPES[$type])) {
    render_error_page(404);
}
if (!imp_lib_available()) {
    flash_set('danger', 'PhpSpreadsheet belum terpasang. Jalankan "composer install".');
    redirect('modules/imports/index.php');
}

use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Style\Fill;
use PhpOffice\PhpSpreadsheet\Cell\DataValidation;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;

$fields = imp_fields($type);
$ss = new Spreadsheet();
$ss->getProperties()->setTitle('Template ' . IMPORT_TYPES[$type])->setCreator('Smart Workforce Analytics');

// --- Sheet 1: Data (yang dibaca saat impor) ---
$ws = $ss->getActiveSheet();
$ws->setTitle('Data');
$col = 1;
foreach ($fields as $f => $def) {
    $cell = $ws->getCell([$col, 1]);
    $cell->setValue($def['label'] . ($def['required'] ? ' *' : ''));
    $ws->getColumnDimensionByColumn($col)->setWidth(max(16, mb_strlen($def['label']) + 6));
    $col++;
}
$last = $col - 1;
$ws->getStyle([1, 1, $last, 1])->getFont()->setBold(true)->getColor()->setRGB('FFFFFF');
$ws->getStyle([1, 1, $last, 1])->getFill()->setFillType(Fill::FILL_SOLID)->getStartColor()->setRGB('0B132B');
$ws->freezePane('A2');

// Format kolom + daftar pilihan
$keys = array_keys($fields);
$setList = function (string $field, array $items) use ($ws, $keys): void {
    $i = array_search($field, $keys, true);
    if ($i === false) { return; }
    $letter = \PhpOffice\PhpSpreadsheet\Cell\Coordinate::stringFromColumnIndex($i + 1);
    for ($r = 2; $r <= 1000; $r++) {
        $v = $ws->getCell("{$letter}{$r}")->getDataValidation();
        $v->setType(DataValidation::TYPE_LIST)->setAllowBlank(true)->setShowDropDown(true)->setFormula1('"' . implode(',', $items) . '"');
    }
};
$textCols = ['employee_code', 'department', 'vendor', 'position', 'notes', 'full_name', 'period'];
foreach ($keys as $i => $f) {
    $letter = \PhpOffice\PhpSpreadsheet\Cell\Coordinate::stringFromColumnIndex($i + 1);
    if (in_array($f, ['start_date', 'end_date'], true)) {
        $ws->getStyle("{$letter}2:{$letter}1000")->getNumberFormat()->setFormatCode('yyyy-mm-dd');
    } elseif (in_array($f, $textCols, true)) {
        $ws->getStyle("{$letter}2:{$letter}1000")->getNumberFormat()->setFormatCode('@');
    }
}
if ($type === 'employees') {
    $setList('category', ['Karyawan', 'TAD', 'Peserta magang']);
    $setList('status', ['Aktif', 'Tidak aktif', 'Selesai']);
}

// --- Sheet 2: Petunjuk ---
$info = $ss->createSheet();
$info->setTitle('Petunjuk');
$info->setCellValue('A1', 'Petunjuk pengisian: ' . IMPORT_TYPES[$type]);
$info->getStyle('A1')->getFont()->setBold(true)->setSize(14);
$info->fromArray([['Kolom', 'Wajib', 'Keterangan']], null, 'A3');
$info->getStyle('A3:C3')->getFont()->setBold(true);
$row = 4;
foreach ($fields as $def) {
    $info->fromArray([[$def['label'], $def['required'] ? 'Ya' : 'Tidak', $def['hint']]], null, "A{$row}");
    $row++;
}
$row++;
$notes = [
    'Hanya sheet pertama ("Data") yang dibaca. Judul kolom ada di baris 1 (nomor baris dapat diubah saat pemetaan).',
    'Jangan memakai rumus; salin sebagai nilai. Rumus tanpa nilai tersimpan akan ditolak.',
    'Data lama tidak ditimpa kecuali Anda memilih kebijakan "perbarui" saat pemetaan.',
    'Semua contoh data pada aplikasi ini fiktif. Jangan mengunggah data pribadi yang tidak diperlukan.',
];
foreach ($notes as $n) {
    $info->setCellValue("A{$row}", '• ' . $n);
    $row++;
}
$info->getColumnDimension('A')->setWidth(34);
$info->getColumnDimension('B')->setWidth(10);
$info->getColumnDimension('C')->setWidth(80);
$ss->setActiveSheetIndex(0);

audit_log('export', 'import_template', null, 'Mengunduh templat impor ' . IMPORT_TYPES[$type]);

header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
header('Content-Disposition: attachment; filename="template-' . ($type === 'employees' ? 'tenaga-kerja' : 'mandays') . '.xlsx"');
header('Cache-Control: no-store');
(new Xlsx($ss))->save('php://output');
exit;
