<?php
/** Unduh laporan kesalahan batch (CSV). */
declare(strict_types=1);
require_once dirname(__DIR__, 2) . '/includes/bootstrap.php';
require_once __DIR__ . '/schema.php';
require_once __DIR__ . '/repo.php';

$user = require_login();
if (!user_can('import.history', $user) && !user_can('import.run', $user)) {
    require_permission('import.history');
}
$id = (isset($_GET['id']) && ctype_digit((string) $_GET['id'])) ? (int) $_GET['id'] : 0;
$batch = $id > 0 ? imp_batch_find($id) : null;
if ($batch === null) {
    render_error_page(404);
}

$gen = (function () use ($id): Generator {
    $last = 0;
    while (true) {
        $rows = db_fetch_all('SELECT * FROM import_errors WHERE batch_id = ? AND id > ? ORDER BY id ASC LIMIT 1000', 'ii', [$id, $last]);
        if (!$rows) { return; }
        foreach ($rows as $r) {
            $last = (int) $r['id'];
            yield [$r['row_number'], $r['column_name'], IMPORT_ERROR_LABELS[$r['error_type']] ?? $r['error_type'], $r['severity'] === 'error' ? 'Kesalahan' : 'Peringatan', $r['message'], $r['suggestion'] ?? '', $r['raw_data'] ?? ''];
        }
    }
})();

audit_log('export', 'import_batch', $id, 'Mengunduh laporan kesalahan batch #' . $id, (int) $user['id']);
csv_download("laporan-kesalahan-import_batch{$id}_" . date('Ymd-His') . '.csv', ['Baris Excel', 'Kolom', 'Jenis', 'Tingkat', 'Pesan', 'Saran', 'Data Baris'], $gen);
