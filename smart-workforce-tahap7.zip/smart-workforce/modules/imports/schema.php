<?php
/**
 * Definisi field impor, pemetaan otomatis kolom, dan normalisasi nilai sel.
 */
declare(strict_types=1);

const IMPORT_TYPES = ['employees' => 'Data Tenaga Kerja', 'workforce_records' => 'Mandays & Kehadiran'];

const IMPORT_STATUS_LABELS = [
    'uploaded' => 'Menunggu pemetaan', 'validated' => 'Menunggu konfirmasi', 'completed' => 'Selesai', 'failed' => 'Gagal', 'cancelled' => 'Dibatalkan',
];
const IMPORT_ERROR_LABELS = [
    'missing_required' => 'Kolom wajib kosong', 'invalid_date' => 'Format tanggal tidak valid', 'invalid_number' => 'Angka tidak valid',
    'department_not_found' => 'Departemen tidak ditemukan', 'vendor_not_found' => 'Vendor tidak ditemukan', 'invalid_enum' => 'Nilai tidak dikenali',
    'duplicate' => 'Duplikat', 'other' => 'Pelanggaran aturan data',
];

/** Penanda sel berisi rumus tanpa nilai tersimpan (diberikan oleh pembaca file). */
const IMP_FORMULA = "\x00FORMULA\x00";

/**
 * Field per jenis impor. 'syn' = sinonim nama kolom (sudah dinormalisasi: huruf kecil tanpa spasi/simbol).
 * @return array<string,array{label:string,required:bool,syn:array,hint:string}>
 */
function imp_fields(string $type): array
{
    if ($type === 'employees') {
        return [
            'employee_code' => ['label' => 'ID Internal', 'required' => true,  'hint' => 'Kunci unik tenaga kerja, mis. EMP-0071', 'syn' => ['idinternal', 'kode', 'kodepegawai', 'employeecode', 'idtenagakerja', 'kodetenagakerja', 'id']],
            'full_name'     => ['label' => 'Nama Lengkap', 'required' => true, 'hint' => '2–150 karakter', 'syn' => ['namalengkap', 'nama', 'fullname', 'namatenagakerja', 'namakaryawan']],
            'category'      => ['label' => 'Kategori', 'required' => true, 'hint' => 'Karyawan, TAD, atau Peserta magang', 'syn' => ['kategori', 'jenis', 'kategoritenagakerja', 'category', 'tipe']],
            'department'    => ['label' => 'Departemen', 'required' => true, 'hint' => 'Kode atau nama departemen yang sudah terdaftar', 'syn' => ['departemen', 'dept', 'department', 'kodedepartemen', 'namadepartemen']],
            'vendor'        => ['label' => 'Vendor', 'required' => false, 'hint' => 'Wajib untuk TAD (kode atau nama vendor); kosong untuk kategori lain', 'syn' => ['vendor', 'kodevendor', 'namavendor', 'penyedia']],
            'position'      => ['label' => 'Jabatan', 'required' => true, 'hint' => '2–120 karakter', 'syn' => ['jabatan', 'posisi', 'position', 'title']],
            'start_date'    => ['label' => 'Tanggal Mulai', 'required' => true, 'hint' => 'YYYY-MM-DD atau DD/MM/YYYY', 'syn' => ['tanggalmulai', 'tglmulai', 'mulai', 'startdate', 'tanggalmasuk', 'tglmasuk']],
            'end_date'      => ['label' => 'Tanggal Berakhir', 'required' => false, 'hint' => 'Wajib untuk magang dan status selain Aktif', 'syn' => ['tanggalberakhir', 'tglberakhir', 'berakhir', 'enddate', 'tanggalselesai']],
            'status'        => ['label' => 'Status', 'required' => false, 'hint' => 'Aktif, Tidak aktif, atau Selesai (kosong = Aktif)', 'syn' => ['status', 'statuspekerjaan']],
            'notes'         => ['label' => 'Catatan', 'required' => false, 'hint' => 'Opsional', 'syn' => ['catatan', 'keterangan', 'notes', 'note']],
        ];
    }
    if ($type === 'workforce_records') {
        return [
            'employee_code'  => ['label' => 'ID Internal Tenaga Kerja', 'required' => true, 'hint' => 'Harus sudah terdaftar di Data Tenaga Kerja', 'syn' => ['idinternal', 'kode', 'kodepegawai', 'employeecode', 'idtenagakerja', 'id']],
            'period'         => ['label' => 'Periode (bulan)', 'required' => true, 'hint' => 'YYYY-MM, tanggal apa pun pada bulan itu, atau "September 2026"', 'syn' => ['periode', 'bulan', 'period', 'periodebulan', 'bulanperiode']],
            'mandays'        => ['label' => 'Mandays (hari)', 'required' => true, 'hint' => '0 s.d. jumlah hari pada bulan tsb (maks. 2 desimal)', 'syn' => ['mandays', 'manday', 'jumlahmandays']],
            'scheduled_days' => ['label' => 'Hari Kerja Terjadwal', 'required' => false, 'hint' => 'Opsional; isi berpasangan dengan Hari Hadir', 'syn' => ['harikerjaterjadwal', 'hariterjadwal', 'terjadwal', 'scheduleddays', 'harikerja']],
            'attended_days'  => ['label' => 'Hari Hadir', 'required' => false, 'hint' => 'Opsional; jangan diisi dengan perkiraan', 'syn' => ['harihadir', 'hadir', 'attendeddays', 'kehadiran']],
            'notes'          => ['label' => 'Keterangan', 'required' => false, 'hint' => 'Opsional, maks. 255 karakter', 'syn' => ['keterangan', 'catatan', 'notes', 'note']],
        ];
    }
    throw new InvalidArgumentException('Jenis impor tidak dikenal.');
}

/** Nama kolom -> kunci pembanding (huruf kecil, hanya a-z0-9). */
function imp_norm_key(string $s): string
{
    $s = mb_strtolower($s);
    $s = strtr($s, ['é' => 'e', 'è' => 'e', 'ê' => 'e', 'á' => 'a', 'à' => 'a', 'í' => 'i', 'ó' => 'o', 'ú' => 'u']);
    return preg_replace('/[^a-z0-9]/', '', $s) ?? '';
}

/**
 * Tebak pemetaan field -> indeks kolom dari baris header. Cocok persis dulu, lalu awalan (sinonim >= 5 huruf).
 * Satu kolom hanya dipakai satu field.
 * @param array<int,string> $headers colIdx => teks header
 * @return array<string,int>
 */
function imp_auto_map(string $type, array $headers): array
{
    $norm = array_map('imp_norm_key', $headers);
    $map = [];
    $used = [];
    foreach ([false, true] as $prefixPass) {
        foreach (imp_fields($type) as $field => $def) {
            if (isset($map[$field])) {
                continue;
            }
            foreach ($norm as $idx => $h) {
                if (isset($used[$idx]) || $h === '') {
                    continue;
                }
                foreach ($def['syn'] as $syn) {
                    if ($h === $syn || ($prefixPass && strlen($syn) >= 5 && str_starts_with($h, $syn))) {
                        $map[$field] = $idx;
                        $used[$idx] = true;
                        continue 3;
                    }
                }
            }
        }
    }
    return $map;
}

/* ---------------- Normalisasi nilai sel ---------------- */

/** Nilai sel (string/float/bool/null) -> string bersih. Angka bulat tidak diberi ".0". */
function imp_cell_str($v): string
{
    if ($v === null) {
        return '';
    }
    if (is_bool($v)) {
        return $v ? 'TRUE' : 'FALSE';
    }
    if (is_int($v)) {
        return (string) $v;
    }
    if (is_float($v)) {
        $r = round($v, 6);
        if (abs($r - round($r)) < 1e-9 && abs($r) < 1e15) {
            return (string) (int) round($r);
        }
        return rtrim(rtrim(number_format($r, 6, '.', ''), '0'), '.');
    }
    $s = (string) $v;
    $s = preg_replace('/[\x00-\x08\x0B\x0C\x0E-\x1F\x7F]/', '', $s) ?? '';
    return trim(preg_replace('/\s+/u', ' ', $s) ?? $s);
}

const IMP_MONTHS = [
    'januari' => 1, 'january' => 1, 'jan' => 1, 'februari' => 2, 'february' => 2, 'feb' => 2, 'maret' => 3, 'march' => 3, 'mar' => 3,
    'april' => 4, 'apr' => 4, 'mei' => 5, 'may' => 5, 'juni' => 6, 'june' => 6, 'jun' => 6, 'juli' => 7, 'july' => 7, 'jul' => 7,
    'agustus' => 8, 'august' => 8, 'agu' => 8, 'agt' => 8, 'aug' => 8, 'september' => 9, 'sep' => 9, 'sept' => 9,
    'oktober' => 10, 'october' => 10, 'okt' => 10, 'oct' => 10, 'november' => 11, 'nopember' => 11, 'nov' => 11,
    'desember' => 12, 'december' => 12, 'des' => 12, 'dec' => 12,
];

/** Serial tanggal Excel (angka) -> 'Y-m-d', hanya untuk rentang wajar (1954–2100). */
function imp_excel_serial_to_date(string $s): ?string
{
    if (!preg_match('/^\d{5}(\.\d+)?$/', $s) || (float) $s < 20000 || (float) $s > 73000) {
        return null;
    }
    return \PhpOffice\PhpSpreadsheet\Shared\Date::excelToDateTimeObject((float) $s)->format('Y-m-d');
}

/** Teks tanggal -> 'YYYY-MM-DD' valid atau null. Format: Y-m-d, d/m/Y (hari dulu), d M Y, serial Excel. */
function imp_parse_date(string $s): ?string
{
    $s = trim($s);
    if ($s === '') {
        return null;
    }
    if (preg_match('/^(\d{4}-\d{2}-\d{2})([ T]\d{1,2}:\d{2}(:\d{2})?)?$/', $s, $m)) {
        return val_date($m[1]);
    }
    if (preg_match('#^(\d{1,2})[/\-.](\d{1,2})[/\-.](\d{4})$#', $s, $m)) {
        return val_date(sprintf('%04d-%02d-%02d', (int) $m[3], (int) $m[2], (int) $m[1]));
    }
    if (preg_match('/^(\d{1,2})\s+([A-Za-z]+)\.?\s+(\d{4})$/', $s, $m) && isset(IMP_MONTHS[mb_strtolower($m[2])])) {
        return val_date(sprintf('%04d-%02d-%02d', (int) $m[3], IMP_MONTHS[mb_strtolower($m[2])], (int) $m[1]));
    }
    $serial = imp_excel_serial_to_date($s);
    return $serial !== null ? val_date($serial) : null;
}

/** Teks periode -> 'YYYY-MM' atau null. Menerima Y-m, tanggal apa pun dalam bulan, m/Y, "September 2026", serial Excel. */
function imp_parse_month(string $s): ?string
{
    $s = trim($s);
    if (preg_match('/^(\d{4})-(\d{2})$/', $s, $m)) {
        return stats_parse_month($s);
    }
    if (preg_match('#^(\d{1,2})[/\-](\d{4})$#', $s, $m)) {
        return stats_parse_month(sprintf('%04d-%02d', (int) $m[2], (int) $m[1]));
    }
    if (preg_match('/^([A-Za-z]+)\.?\s+(\d{4})$/', $s, $m) && isset(IMP_MONTHS[mb_strtolower($m[1])])) {
        return stats_parse_month(sprintf('%04d-%02d', (int) $m[2], IMP_MONTHS[mb_strtolower($m[1])]));
    }
    $d = imp_parse_date($s);
    return $d !== null ? stats_parse_month(substr($d, 0, 7)) : null;
}

/** Kategori bebas -> kode enum atau null. */
function imp_norm_category(string $s): ?string
{
    $k = imp_norm_key($s);
    return ['karyawan' => 'employee', 'employee' => 'employee', 'pegawai' => 'employee', 'tad' => 'tad', 'tenagaalihdaya' => 'tad', 'alihdaya' => 'tad',
        'outsourcing' => 'tad', 'pesertamagang' => 'intern', 'magang' => 'intern', 'intern' => 'intern', 'internship' => 'intern'][$k] ?? null;
}

/** Status bebas -> kode enum atau null. */
function imp_norm_status(string $s): ?string
{
    $k = imp_norm_key($s);
    return ['aktif' => 'active', 'active' => 'active', 'tidakaktif' => 'inactive', 'nonaktif' => 'inactive', 'inactive' => 'inactive',
        'selesai' => 'completed', 'completed' => 'completed', 'complete' => 'completed'][$k] ?? null;
}
