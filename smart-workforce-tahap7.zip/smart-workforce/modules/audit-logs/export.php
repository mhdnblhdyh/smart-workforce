<?php
/** Ekspor CSV Activity Logs sesuai filter (hanya Admin). Ekspor ini sendiri dicatat. */
declare(strict_types=1);
require_once dirname(__DIR__, 2) . '/includes/bootstrap.php';
require_once __DIR__ . '/queries.php';

$user = require_permission('audit.view');
$f = audit_filters();
$n = audit_count($f);
audit_log('export', 'audit_log', null, "Ekspor CSV activity logs ({$n} baris)", (int) $user['id']);

$gen = (function () use ($f): Generator {
    for ($off = 0; $off < 200000; $off += 1000) {
        $rows = audit_list($f, 1000, $off);
        if (!$rows) { return; }
        foreach ($rows as $r) {
            yield [$r['id'], $r['created_at'], $r['user_name'] ?? '', $r['user_email'] ?? '', AUDIT_ACTIONS[$r['action']][0] ?? $r['action'], $r['action'], $r['entity_type'] ?? '', $r['entity_id'] ?? '', $r['description'] ?? '', $r['ip_address'] ?? ''];
        }
    }
})();
csv_download('activity-logs_' . date('Ymd-His') . '.csv', ['ID', 'Waktu', 'Pengguna', 'Email', 'Aksi', 'Kode Aksi', 'Entitas', 'ID Entitas', 'Deskripsi', 'IP'], $gen);
