<?php
declare(strict_types=1);
require_once dirname(__DIR__, 2) . '/includes/bootstrap.php';
require_once __DIR__ . '/queries.php';

$user = require_permission('audit.view');
$path = 'modules/audit-logs/index.php';

$f = audit_filters();
$req = ['per' => (isset($_GET['per']) && ctype_digit((string) $_GET['per']) && in_array((int) $_GET['per'], PER_PAGE_OPTIONS, true)) ? (int) $_GET['per'] : 25];
$total  = audit_count($f);
$pageNo = list_clamp_page($total, (isset($_GET['page']) && ctype_digit((string) $_GET['page'])) ? max(1, (int) $_GET['page']) : 1, $req['per']);
$rows   = audit_list($f, $req['per'], ($pageNo - 1) * $req['per']);
$users    = db_fetch_all('SELECT id, name FROM users ORDER BY name');
$actions  = array_column(db_fetch_all('SELECT DISTINCT action FROM audit_logs ORDER BY action'), 'action');
$entities = array_column(db_fetch_all('SELECT DISTINCT entity_type FROM audit_logs WHERE entity_type IS NOT NULL ORDER BY entity_type'), 'entity_type');
$hasFilter = array_filter($f) !== [];
$today = (int) db_value('SELECT COUNT(*) FROM audit_logs WHERE created_at >= CURDATE()');
$failed24 = (int) db_value("SELECT COUNT(*) FROM audit_logs WHERE action IN ('login_failed','access_denied','csrf_failed','account_locked') AND created_at >= DATE_SUB(NOW(), INTERVAL 24 HOUR)");

$page = ['title' => 'Activity Logs', 'active' => 'auditlogs', 'breadcrumb' => ['Administration', 'Activity Logs'], 'css' => ['crud.css'], 'js' => []];
require BASE_PATH . '/includes/header.php';
$opt = fn ($v, $cur, $label) => '<option value="' . e($v) . '"' . ((string) $v === (string) $cur ? ' selected' : '') . '>' . e($label) . '</option>';
?>
<section class="crud-page">
    <div class="page-header">
        <div><h1>Activity Logs</h1><p class="page-sub">Jejak aktivitas penting. Log bersifat hanya-baca: tidak dapat diubah atau dihapus dari aplikasi.</p></div>
        <div class="page-actions"><a class="btn btn-outline" href="<?= e(url('modules/audit-logs/export.php' . (($q = http_build_query(array_filter($f))) !== '' ? '?' . $q : ''))) ?>"><?= icon('download') ?>Ekspor CSV</a></div>
    </div>

    <div class="mini-stats">
        <?= ui_mini_stat('Total entri', format_number((int) db_value('SELECT COUNT(*) FROM audit_logs'), 0)) ?>
        <?= ui_mini_stat('Hari ini', format_number($today, 0)) ?>
        <?= ui_mini_stat('Peristiwa keamanan 24 jam', format_number($failed24, 0), 'login gagal, akses ditolak, CSRF, penguncian') ?>
        <?= ui_mini_stat('Sesuai filter', format_number($total, 0)) ?>
    </div>

    <form class="card" method="get" action="<?= e(url($path)) ?>" style="padding:16px;margin-bottom:16px">
        <div class="filter-row">
            <label class="filter"><span>Pengguna</span><select name="user" class="form-select" data-autosubmit><option value="">Semua</option><?php foreach ($users as $u) echo $opt($u['id'], $f['user'], $u['name']); ?></select></label>
            <label class="filter"><span>Aksi</span><select name="action" class="form-select" data-autosubmit><option value="">Semua</option><?php foreach ($actions as $a) echo $opt($a, $f['action'], AUDIT_ACTIONS[$a][0] ?? $a); ?></select></label>
            <label class="filter"><span>Entitas</span><select name="entity" class="form-select" data-autosubmit><option value="">Semua</option><?php foreach ($entities as $en) echo $opt($en, $f['entity'], $en); ?></select></label>
            <label class="filter"><span>Dari tanggal</span><input type="date" name="from" value="<?= e($f['from']) ?>" class="date-input" data-autosubmit></label>
            <label class="filter"><span>Sampai tanggal</span><input type="date" name="to" value="<?= e($f['to']) ?>" class="date-input" data-autosubmit></label>
            <label class="filter" style="flex:1 1 200px"><span>Cari deskripsi / IP</span><input type="search" name="q" value="<?= e($f['q']) ?>" maxlength="100" class="date-input" style="width:100%" placeholder="mis. login gagal"></label>
            <select name="per" class="form-select form-select-sm" data-autosubmit aria-label="Baris per halaman"><?php foreach (PER_PAGE_OPTIONS as $n) echo $opt($n, $req['per'], $n . ' / halaman'); ?></select>
            <button type="submit" class="btn btn-outline btn-sm"><?= icon('search') ?>Terapkan</button>
            <?php if ($hasFilter): ?><a class="btn btn-outline btn-sm" href="<?= e(url($path)) ?>"><?= icon('rotate-ccw') ?>Reset</a><?php endif; ?>
        </div>
    </form>

    <div class="card table-card">
        <?php if ($total === 0): ?>
            <?= ui_empty_state($hasFilter ? 'search' : 'scroll-text', $hasFilter ? 'Tidak ada log yang cocok' : 'Belum ada log aktivitas', $hasFilter ? 'Ubah filter atau rentang tanggal.' : 'Aktivitas akan tercatat otomatis.', $hasFilter ? '<a class="btn btn-outline btn-sm" href="' . e(url($path)) . '">Reset filter</a>' : '') ?>
        <?php else: ?>
        <div class="table-scroll"><table class="table table-hover">
            <thead><tr><th>Waktu</th><th>Pengguna</th><th>Aksi</th><th>Entitas</th><th>Deskripsi</th><th>IP</th></tr></thead>
            <tbody>
            <?php foreach ($rows as $r): ?>
                <tr><td class="log-time"><?= e(format_datetime($r['created_at'])) ?></td>
                    <td><?= $r['user_name'] ? '<strong>' . e($r['user_name']) . '</strong><span class="cell-sub">' . e($r['user_email']) . '</span>' : '<span class="muted-dash">— (tidak terautentikasi / dihapus)</span>' ?></td>
                    <td><?= audit_action_badge($r['action']) ?></td>
                    <td><?= $r['entity_type'] ? e($r['entity_type']) . ($r['entity_id'] ? '<span class="cell-sub">#' . (int) $r['entity_id'] . '</span>' : '') : '<span class="muted-dash">—</span>' ?></td>
                    <td class="log-desc"><?= e($r['description'] ?? '') ?></td>
                    <td><code><?= e($r['ip_address'] ?? '') ?></code></td></tr>
            <?php endforeach; ?>
            </tbody>
        </table></div>
        <?= ui_pagination($total, $pageNo, $req['per'], $path) ?>
        <?php endif; ?>
    </div>
</section>
<?php require BASE_PATH . '/includes/footer.php'; ?>
