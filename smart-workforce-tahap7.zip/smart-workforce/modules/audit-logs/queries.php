<?php
/**
 * Activity Logs (audit_logs). Hanya BACA: aplikasi tidak menyediakan fitur ubah/hapus log.
 * Akses hanya untuk Admin (izin audit.view); HC Staff dan Viewer tidak dapat melihat maupun mengubah.
 */
declare(strict_types=1);

/** Label & varian badge per aksi. Aksi yang tidak dikenal tetap ditampilkan apa adanya. */
const AUDIT_ACTIONS = [
    'login_success' => ['Login berhasil', 'success'], 'login_failed' => ['Login gagal', 'warning'], 'logout' => ['Logout', 'neutral'],
    'account_locked' => ['Akun terkunci', 'danger'], 'access_denied' => ['Akses ditolak', 'danger'], 'csrf_failed' => ['CSRF gagal', 'danger'],
    'create' => ['Tambah data', 'info'], 'update' => ['Ubah data', 'info'], 'delete' => ['Hapus data', 'danger'], 'delete_blocked' => ['Hapus ditolak', 'warning'],
    'export' => ['Ekspor', 'neutral'], 'import_upload' => ['Import: unggah', 'neutral'], 'import_validate' => ['Import: validasi', 'neutral'],
    'import' => ['Import selesai', 'success'], 'import_failed' => ['Import gagal', 'danger'], 'import_cancel' => ['Import dibatalkan', 'neutral'], 'import_rejected' => ['Unggahan ditolak', 'warning'],
    'user_create' => ['Buat akun', 'info'], 'user_update' => ['Ubah akun', 'info'], 'role_change' => ['Ubah role', 'warning'], 'user_deactivate' => ['Nonaktifkan akun', 'warning'],
    'user_activate' => ['Aktifkan akun', 'success'], 'user_unlock' => ['Buka kunci akun', 'neutral'], 'password_reset' => ['Reset password', 'warning'],
    'password_change' => ['Ganti password', 'info'], 'password_change_failed' => ['Ganti password gagal', 'warning'], 'user_action_denied' => ['Aksi akun ditolak', 'danger'], 'settings_update' => ['Ubah pengaturan', 'info'],
    'report_view' => ['Lihat laporan', 'neutral'],
];

function audit_action_badge(string $action): string
{
    [$label, $variant] = AUDIT_ACTIONS[$action] ?? [$action, 'neutral'];
    return ui_badge($label, $variant);
}

function audit_filters(): array
{
    $g = fn (string $k): string => (isset($_GET[$k]) && is_string($_GET[$k])) ? trim($_GET[$k]) : '';
    $date = fn (string $k): string => val_date($g($k)) ?? '';
    return [
        'action' => preg_match('/^[a-z_]{1,50}$/', $g('action')) ? $g('action') : '',
        'user'   => ctype_digit($g('user')) ? (int) $g('user') : 0,
        'entity' => preg_match('/^[a-z_]{1,50}$/', $g('entity')) ? $g('entity') : '',
        'from'   => $date('from'),
        'to'     => $date('to'),
        'q'      => mb_substr($g('q'), 0, 100),
    ];
}

function audit_where(array $f): array
{
    $w = []; $t = ''; $p = [];
    if ($f['action'] !== '') { $w[] = 'a.action = ?'; $t .= 's'; $p[] = $f['action']; }
    if ($f['user'] > 0)      { $w[] = 'a.user_id = ?'; $t .= 'i'; $p[] = $f['user']; }
    if ($f['entity'] !== '') { $w[] = 'a.entity_type = ?'; $t .= 's'; $p[] = $f['entity']; }
    if ($f['from'] !== '')   { $w[] = 'a.created_at >= ?'; $t .= 's'; $p[] = $f['from'] . ' 00:00:00'; }
    if ($f['to'] !== '')     { $w[] = 'a.created_at <= ?'; $t .= 's'; $p[] = $f['to'] . ' 23:59:59'; }
    if ($f['q'] !== '')      { $w[] = '(a.description LIKE ? OR a.ip_address LIKE ?)'; $t .= 'ss'; $like = '%' . like_escape($f['q']) . '%'; array_push($p, $like, $like); }
    return [$w ? 'WHERE ' . implode(' AND ', $w) : '', $t, $p];
}

function audit_count(array $f): int
{
    [$where, $t, $p] = audit_where($f);
    return (int) db_value("SELECT COUNT(*) FROM audit_logs a {$where}", $t, $p);
}

function audit_list(array $f, int $limit, int $offset): array
{
    [$where, $t, $p] = audit_where($f);
    return db_fetch_all(
        "SELECT a.*, u.name AS user_name, u.email AS user_email FROM audit_logs a LEFT JOIN users u ON u.id = a.user_id {$where} ORDER BY a.id DESC LIMIT ? OFFSET ?",
        $t . 'ii',
        array_merge($p, [$limit, $offset])
    );
}
