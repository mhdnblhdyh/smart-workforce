<?php
/**
 * Loader konfigurasi. Mengembalikan array konfigurasi (di-cache per request).
 * Prioritas: config.local.php (rahasia, tidak di Git) -> config.example.php (default XAMPP).
 */
declare(strict_types=1);

function app_config(?string $key = null, $default = null)
{
    static $config = null;

    if ($config === null) {
        $local   = __DIR__ . '/config.local.php';
        $example = __DIR__ . '/config.example.php';
        $config  = require (is_file($local) ? $local : $example);
    }

    if ($key === null) {
        return $config;
    }

    // Dukung notasi titik, mis. app_config('db.host')
    $value = $config;
    foreach (explode('.', $key) as $segment) {
        if (!is_array($value) || !array_key_exists($segment, $value)) {
            return $default;
        }
        $value = $value[$segment];
    }
    return $value;
}
