<?php
/**
 * Koneksi database (MySQLi + prepared statements) dan helper query.
 * Semua query berparameter WAJIB memakai helper ini atau prepared statement manual.
 */
declare(strict_types=1);

// Hash bcrypt acak sebagai pembanding saat email tidak ditemukan (mencegah user enumeration via waktu respons).
const DUMMY_PASSWORD_HASH = '$2y$10$hvF0XfOOHxAt.Nzj.pIpJuaTLs1NGyrTTXLy9X1SOjbab5ZjPk3KW';

function db(): mysqli
{
    static $conn = null;

    if ($conn instanceof mysqli) {
        return $conn;
    }

    // Lempar exception pada error MySQLi agar bisa ditangani terpusat.
    mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);

    $cfg = app_config('db');
    try {
        $conn = new mysqli($cfg['host'], $cfg['user'], $cfg['pass'], $cfg['name'], (int) $cfg['port']);
        $conn->set_charset($cfg['charset']);
        $conn->query("SET time_zone = '" . date('P') . "'");
    } catch (mysqli_sql_exception $e) {
        error_log('[DB] Koneksi gagal: ' . $e->getMessage());
        throw new RuntimeException('Koneksi database gagal.', 0, $e);
    }
    return $conn;
}

/**
 * Jalankan prepared statement dan kembalikan mysqli_stmt yang sudah dieksekusi.
 * $types: string tipe bind_param ('s','i','d'), kosongkan jika tanpa parameter.
 */
function db_execute(string $sql, string $types = '', array $params = []): mysqli_stmt
{
    $stmt = db()->prepare($sql);
    if ($types !== '') {
        $stmt->bind_param($types, ...$params);
    }
    $stmt->execute();
    return $stmt;
}

/** Ambil semua baris sebagai array asosiatif. */
function db_fetch_all(string $sql, string $types = '', array $params = []): array
{
    $stmt   = db_execute($sql, $types, $params);
    $result = $stmt->get_result();
    $rows   = $result ? $result->fetch_all(MYSQLI_ASSOC) : [];
    $stmt->close();
    return $rows;
}

/** Ambil satu baris (atau null). */
function db_fetch_one(string $sql, string $types = '', array $params = []): ?array
{
    $rows = db_fetch_all($sql, $types, $params);
    return $rows[0] ?? null;
}

/** Ambil satu nilai skalar (atau null). */
function db_value(string $sql, string $types = '', array $params = [])
{
    $row = db_fetch_one($sql, $types, $params);
    return $row === null ? null : reset($row);
}

/** INSERT/UPDATE/DELETE: kembalikan jumlah baris terpengaruh. */
function db_run(string $sql, string $types = '', array $params = []): int
{
    $stmt     = db_execute($sql, $types, $params);
    $affected = $stmt->affected_rows;
    $stmt->close();
    return $affected;
}

/** ID auto-increment terakhir pada koneksi ini. */
function db_last_id(): int
{
    return (int) db()->insert_id;
}
