<?php
/**
 * Contoh konfigurasi Smart Workforce Analytics.
 *
 * Cara pakai:
 *   1. Salin file ini menjadi config/config.local.php
 *   2. Sesuaikan nilainya (terutama kredensial database dan base_url)
 *   3. config.local.php SUDAH masuk .gitignore — jangan di-commit.
 *
 * Jika config.local.php tidak ada, aplikasi memakai nilai di file ini
 * (cocok untuk XAMPP default: user root tanpa password).
 */
return [
    'app_name'  => 'Smart Workforce Analytics',
    'app_env'   => 'development',          // 'development' | 'production'
    'base_url'  => '/smart-workforce',     // folder aplikasi di htdocs, tanpa slash di akhir. Kosongkan ('') jika di root domain.
    'timezone'  => 'Asia/Jakarta',

    'db' => [
        'host'    => '127.0.0.1',
        'port'    => 3306,
        'name'    => 'smart_workforce',
        'user'    => 'root',
        'pass'    => '',
        'charset' => 'utf8mb4',
    ],

    'session' => [
        'name'         => 'SWA_SESSION',
        'idle_timeout' => 1800,            // detik tanpa aktivitas sebelum logout otomatis (30 menit)
    ],

    'security' => [
        'max_login_attempts' => 5,         // gagal berturut-turut sebelum akun dikunci sementara
        'lockout_minutes'    => 15,
    ],

    // Tampilkan kotak akun demo di halaman login. WAJIB false di produksi.
    'show_demo_hint' => true,
];
