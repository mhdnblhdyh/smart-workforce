(function () {
    'use strict';

    var pwd = document.getElementById('password');
    var toggle = document.getElementById('togglePassword');
    if (pwd && toggle) {
        toggle.addEventListener('click', function () {
            var show = pwd.type === 'password';
            pwd.type = show ? 'text' : 'password';
            toggle.textContent = show ? 'Sembunyikan' : 'Tampilkan';
            toggle.setAttribute('aria-pressed', show ? 'true' : 'false');
            toggle.setAttribute('aria-label', show ? 'Sembunyikan password' : 'Tampilkan password');
        });
    }

    // Cegah klik ganda saat form dikirim
    var form = document.getElementById('loginForm');
    var submit = document.getElementById('loginSubmit');
    if (form && submit) {
        form.addEventListener('submit', function () {
            if (!form.checkValidity || form.checkValidity()) {
                submit.disabled = true;
                submit.textContent = 'Memproses…';
            }
        });
    }
})();
