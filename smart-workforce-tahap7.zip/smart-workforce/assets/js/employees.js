/* Aturan tampilan form tenaga kerja: vendor hanya untuk TAD; penanda wajib pada tanggal berakhir. */
(function () {
    'use strict';
    var form = document.getElementById('entityForm');
    if (!form) return;
    var cat = form.elements.category, vendor = form.elements.vendor_id, status = form.elements.status;
    var vendorReq = document.getElementById('vendorReq'), endReq = document.getElementById('endReq');

    function sync() {
        var isTad = cat.value === 'tad';
        vendor.disabled = !isTad;
        if (!isTad) vendor.value = '';
        vendor.required = isTad;
        vendorReq.hidden = !isTad;
        endReq.hidden = !(cat.value === 'intern' || (status.value && status.value !== 'active'));
    }
    cat.addEventListener('change', sync);
    status.addEventListener('change', sync);
    form.addEventListener('crud:formopen', sync);
    sync();
})();
