/* ============================================================
   Dashboard — mengambil data dari modules/dashboard/data.php dan merender KPI, grafik, tabel.
   Seluruh teks dari server dirender via textContent (bukan innerHTML).
   ============================================================ */
(function () {
    'use strict';

    var section = document.getElementById('dashboard');
    if (!section) return;

    var endpoint = section.dataset.endpoint;
    var defaultPeriod = section.dataset.defaultPeriod;
    var selPeriod = document.getElementById('filterPeriod');
    var selDept = document.getElementById('filterDept');
    var btnReset = document.getElementById('filterReset');
    var errBox = document.getElementById('dashError');
    var errMsg = document.getElementById('dashErrorMsg');
    var emptyBox = document.getElementById('dashEmpty');
    var spriteUrl = (document.querySelector('use').getAttribute('href') || '').split('#')[0];
    var nf = new Intl.NumberFormat('id-ID', { maximumFractionDigits: 1 });
    var nf0 = new Intl.NumberFormat('id-ID', { maximumFractionDigits: 0 });

    var COLORS = { total: '#0B132B', employee: '#3A86FF', tad: '#14A3A8', intern: '#94A3B8', bar: '#3A86FF', bar2: '#1C2541' };
    var charts = {};
    var controller = null;

    /* ---------- util DOM ---------- */
    function el(tag, cls, text) {
        var n = document.createElement(tag);
        if (cls) n.className = cls;
        if (text !== undefined && text !== null) n.textContent = text;
        return n;
    }
    function icon(name, cls) {
        var ns = 'http://www.w3.org/2000/svg';
        var svg = document.createElementNS(ns, 'svg');
        svg.setAttribute('class', 'icon' + (cls ? ' ' + cls : ''));
        svg.setAttribute('aria-hidden', 'true');
        var use = document.createElementNS(ns, 'use');
        use.setAttribute('href', spriteUrl + '#' + name);
        svg.appendChild(use);
        return svg;
    }
    function clear(node) { while (node.firstChild) node.removeChild(node.firstChild); }
    function pill(text, variant) { return el('span', 'pill pill-' + variant, text); }

    /* ---------- KPI ---------- */
    function kpiNodes(key) {
        var card = document.querySelector('[data-kpi="' + key + '"]');
        return card ? { value: card.querySelector('.kpi-value'), foot: card.querySelector('.kpi-foot') } : null;
    }
    function setKpi(key, valueText, unit, footNode) {
        var n = kpiNodes(key);
        if (!n) return;
        clear(n.value);
        n.value.appendChild(document.createTextNode(valueText));
        if (unit) n.value.appendChild(el('small', '', unit));
        clear(n.foot);
        if (footNode) n.foot.appendChild(typeof footNode === 'string' ? document.createTextNode(footNode) : footNode);
    }
    function delta(cur, prev, prevLabel, unitSuffix) {
        var d = cur - prev;
        var wrap = el('span', 'delta ' + (d > 0 ? 'delta-up' : d < 0 ? 'delta-down' : ''));
        if (d === 0) {
            wrap.appendChild(icon('minus'));
            wrap.appendChild(document.createTextNode('Sama dengan ' + prevLabel));
            return wrap;
        }
        var sign = d > 0 ? '+' : '\u2212';
        var text = sign + nf.format(Math.abs(d)) + (unitSuffix || '');
        if (prev > 0) text += ' (' + sign + nf.format(Math.abs(d) / prev * 100) + '%)';
        wrap.appendChild(icon(d > 0 ? 'trending-up' : 'trending-down'));
        wrap.appendChild(document.createTextNode(text));
        var rest = el('span', '', ' vs ' + prevLabel);
        rest.style.fontWeight = '400';
        rest.style.color = 'var(--text-2)';
        var frag = el('span');
        frag.appendChild(wrap);
        frag.appendChild(rest);
        return frag;
    }

    function renderKpis(data) {
        var k = data.kpis, m = data.meta;
        setKpi('headcount', nf0.format(k.headcount.value), '', delta(k.headcount.value, k.headcount.prev, m.prev_label));
        setKpi('tad', nf0.format(k.tad.value), '', delta(k.tad.value, k.tad.prev, m.prev_label));
        setKpi('intern', nf0.format(k.intern.value), '', delta(k.intern.value, k.intern.prev, m.prev_label));
        setKpi('departments', nf0.format(k.departments.value), '', m.department ? m.department_name : 'Departemen berstatus aktif');
        setKpi('vendors', nf0.format(k.vendors.value), '', m.department ? 'Dengan tenaga kerja aktif di departemen ini' : 'Vendor berstatus aktif');

        var md = k.mandays;
        var mdFoot;
        if (md.records === 0) mdFoot = 'Belum ada record mandays pada periode ini';
        else if (!md.prev_available) mdFoot = nf0.format(md.records) + ' record \u00B7 tidak ada data ' + m.prev_label;
        else mdFoot = delta(md.value, md.prev, m.prev_label);
        setKpi('mandays', nf.format(md.value), ' hari', mdFoot);

        var c = k.completeness;
        if (c.value === null) setKpi('completeness', '\u2014', '', 'Belum ada tenaga kerja aktif pada periode ini');
        else setKpi('completeness', nf.format(c.value), '%', nf0.format(c.complete) + ' dari ' + nf0.format(c.total) + ' tenaga kerja lengkap');
    }

    /* ---------- Grafik ---------- */
    function allZero(arr) { return arr.every(function (v) { return !v; }); }
    function toggleEmpty(canvasId, isEmpty) {
        var box = document.getElementById(canvasId).parentNode;
        box.querySelector('.chart-empty').hidden = !isEmpty;
        document.getElementById(canvasId).style.visibility = isEmpty ? 'hidden' : 'visible';
    }
    function upsertChart(id, config) {
        if (charts[id]) {
            charts[id].data = config.data;
            charts[id].options = config.options;
            charts[id].update();
        } else {
            charts[id] = new Chart(document.getElementById(id), config);
        }
    }
    function baseOptions(extra) {
        var o = {
            responsive: true,
            maintainAspectRatio: false,
            interaction: { mode: 'index', intersect: false },
            plugins: { legend: { display: false }, tooltip: { backgroundColor: '#0B132B', padding: 10, cornerRadius: 8, titleFont: { weight: '600' } } }
        };
        return Object.assign(o, extra || {});
    }
    var yInt = { beginAtZero: true, ticks: { precision: 0 }, grid: { color: '#EEF2F8' }, border: { display: false } };

    function renderCharts(data) {
        if (typeof Chart === 'undefined') {
            document.querySelectorAll('.chart-empty').forEach(function (b) { b.hidden = false; b.querySelector('span').textContent = 'Pustaka grafik gagal dimuat.'; });
            return;
        }
        Chart.defaults.font.family = "'Inter', system-ui, sans-serif";
        Chart.defaults.color = '#64748B';

        // 1. Tren
        var t = data.trend;
        var trendEmpty = allZero(t.total);
        toggleEmpty('chartTrend', trendEmpty);
        if (!trendEmpty) {
            upsertChart('chartTrend', {
                type: 'line',
                data: {
                    labels: t.labels,
                    datasets: [
                        { label: 'Total', data: t.total, borderColor: COLORS.total, backgroundColor: COLORS.total, borderWidth: 3, tension: .3, pointRadius: 3, pointHoverRadius: 5 },
                        { label: 'Karyawan', data: t.employee, borderColor: COLORS.employee, backgroundColor: COLORS.employee, borderWidth: 2, tension: .3, pointRadius: 2 },
                        { label: 'TAD', data: t.tad, borderColor: COLORS.tad, backgroundColor: COLORS.tad, borderWidth: 2, tension: .3, pointRadius: 2 },
                        { label: 'Peserta magang', data: t.intern, borderColor: COLORS.intern, backgroundColor: COLORS.intern, borderWidth: 2, tension: .3, pointRadius: 2 }
                    ]
                },
                options: baseOptions({
                    plugins: { legend: { display: true, position: 'bottom', labels: { usePointStyle: true, boxWidth: 8, padding: 16 } }, tooltip: { backgroundColor: '#0B132B', padding: 10, cornerRadius: 8 } },
                    scales: { x: { grid: { display: false }, border: { display: false } }, y: yInt }
                })
            });
        }

        // 2. Kategori
        var c = data.categories;
        var catEmpty = allZero(c.values);
        toggleEmpty('chartCategory', catEmpty);
        if (!catEmpty) {
            upsertChart('chartCategory', {
                type: 'doughnut',
                data: { labels: c.labels, datasets: [{ data: c.values, backgroundColor: [COLORS.employee, COLORS.tad, COLORS.intern], borderColor: '#fff', borderWidth: 3, hoverOffset: 6 }] },
                options: {
                    responsive: true, maintainAspectRatio: false, cutout: '64%',
                    plugins: {
                        legend: { position: 'bottom', labels: { usePointStyle: true, boxWidth: 8, padding: 16 } },
                        tooltip: {
                            backgroundColor: '#0B132B', padding: 10, cornerRadius: 8,
                            callbacks: {
                                label: function (ctx) {
                                    var total = ctx.dataset.data.reduce(function (a, b) { return a + b; }, 0);
                                    return ' ' + ctx.label + ': ' + nf0.format(ctx.parsed) + ' (' + nf.format(ctx.parsed / total * 100) + '%)';
                                }
                            }
                        }
                    }
                }
            });
        }

        // 3. Per departemen
        var d = data.departments;
        var deptEmpty = allZero(d.values);
        toggleEmpty('chartDept', deptEmpty);
        if (!deptEmpty) {
            upsertChart('chartDept', {
                type: 'bar',
                data: { labels: d.labels, datasets: [{ label: 'Tenaga kerja aktif', data: d.values, backgroundColor: COLORS.bar, borderRadius: 6, maxBarThickness: 44 }] },
                options: baseOptions({
                    plugins: { legend: { display: false }, tooltip: { backgroundColor: '#0B132B', padding: 10, cornerRadius: 8, callbacks: { title: function (items) { return d.names[items[0].dataIndex]; } } } },
                    scales: { x: { grid: { display: false }, border: { display: false } }, y: yInt }
                })
            });
        }

        // 4. Mandays per departemen
        var m = data.mandays_dept;
        var mdEmpty = allZero(m.values);
        toggleEmpty('chartMandays', mdEmpty);
        if (!mdEmpty) {
            upsertChart('chartMandays', {
                type: 'bar',
                data: { labels: m.labels, datasets: [{ label: 'Mandays', data: m.values, backgroundColor: COLORS.bar2, borderRadius: 6, maxBarThickness: 44 }] },
                options: baseOptions({
                    plugins: {
                        legend: { display: false },
                        tooltip: { backgroundColor: '#0B132B', padding: 10, cornerRadius: 8, callbacks: { title: function (items) { return m.names[items[0].dataIndex]; }, label: function (ctx) { return ' ' + nf.format(ctx.parsed.y) + ' hari'; } } }
                    },
                    scales: { x: { grid: { display: false }, border: { display: false } }, y: { beginAtZero: true, grid: { color: '#EEF2F8' }, border: { display: false }, ticks: { callback: function (v) { return nf0.format(v); } } } }
                })
            });
        }
    }

    /* ---------- Data quality ---------- */
    var LEVEL = {
        error: { ok: ['Aman', 'success'], bad: ['Perlu diperbaiki', 'danger'] },
        review: { ok: ['Aman', 'success'], bad: ['Perlu ditinjau', 'warning'] },
        info: { ok: ['Lengkap', 'success'], bad: ['Informasi', 'info'] }
    };
    function renderQuality(q) {
        var body = document.getElementById('qualityBody');
        clear(body);
        if (q.score === null) {
            var empty = el('div', 'empty-state');
            empty.appendChild(el('span', 'empty-icon')).appendChild(icon('shield-check'));
            empty.appendChild(el('h3', '', 'Belum ada data untuk dinilai'));
            empty.appendChild(el('p', '', 'Tidak ada tenaga kerja aktif pada periode ini.'));
            body.appendChild(empty);
            return;
        }
        var score = el('div', 'q-score');
        score.appendChild(el('strong', '', nf.format(q.score) + '%'));
        score.appendChild(el('span', '', 'kelengkapan \u00B7 ' + nf0.format(q.complete) + ' dari ' + nf0.format(q.total)));
        body.appendChild(score);

        var bar = el('div', 'progress ' + (q.score >= 95 ? '' : q.score >= 80 ? 'is-warning' : 'is-danger'));
        bar.setAttribute('role', 'progressbar');
        bar.setAttribute('aria-valuenow', String(q.score));
        bar.setAttribute('aria-valuemin', '0');
        bar.setAttribute('aria-valuemax', '100');
        var fill = el('i');
        fill.style.width = Math.max(0, Math.min(100, q.score)) + '%';
        bar.appendChild(fill);
        body.appendChild(bar);

        var ul = el('ul', 'q-list');
        q.checks.forEach(function (c) {
            var li = el('li');
            var left = el('div');
            left.appendChild(el('strong', '', c.label));
            if (c.count > 0) left.appendChild(el('small', '', c.hint));
            var right = el('div', 'q-count');
            right.appendChild(el('b', '', nf0.format(c.count)));
            var spec = LEVEL[c.level][c.count > 0 ? 'bad' : 'ok'];
            right.appendChild(pill(spec[0], spec[1]));
            li.appendChild(left);
            li.appendChild(right);
            ul.appendChild(li);
        });
        body.appendChild(ul);
    }

    /* ---------- Tabel vendor ---------- */
    function renderVendors(rows) {
        var body = document.getElementById('vendorBody');
        clear(body);
        if (!rows.length) {
            var empty = el('div', 'empty-state');
            empty.appendChild(el('span', 'empty-icon')).appendChild(icon('handshake'));
            empty.appendChild(el('h3', '', 'Belum ada data vendor'));
            empty.appendChild(el('p', '', 'Tidak ada vendor dengan tenaga kerja pada filter ini.'));
            body.appendChild(empty);
            return;
        }
        var table = el('table', 'table');
        var thead = el('thead');
        var hr = el('tr');
        [['Vendor', ''], ['TAD aktif', 'num'], ['Mandays', 'num'], ['Kontrak berakhir', ''], ['Status', '']].forEach(function (h) { hr.appendChild(el('th', h[1], h[0])); });
        thead.appendChild(hr);
        table.appendChild(thead);

        var tbody = el('tbody');
        var totW = 0, totM = 0;
        rows.forEach(function (r) {
            totW += r.workers; totM += r.mandays;
            var tr = el('tr');
            var c1 = el('td');
            c1.appendChild(el('strong', '', r.name));
            c1.appendChild(el('span', 'cell-sub', r.code));
            tr.appendChild(c1);
            tr.appendChild(el('td', 'num', nf0.format(r.workers)));
            tr.appendChild(el('td', 'num', nf.format(r.mandays)));

            var c4 = el('td');
            if (r.contract_end) {
                c4.appendChild(document.createTextNode(r.contract_end));
                var cs = el('span', 'cell-sub');
                if (r.contract === 'expired') cs.appendChild(pill('Sudah berakhir', 'danger'));
                else if (r.contract === 'warning') cs.appendChild(pill(r.days_left + ' hari lagi', 'warning'));
                c4.appendChild(cs);
            } else c4.textContent = '-';
            tr.appendChild(c4);

            var c5 = el('td');
            c5.appendChild(r.status === 'active' ? pill('Aktif', 'success') : pill('Nonaktif', 'neutral'));
            tr.appendChild(c5);
            tbody.appendChild(tr);
        });
        table.appendChild(tbody);

        var tfoot = el('tfoot');
        var fr = el('tr');
        var f1 = el('td'); f1.appendChild(el('strong', '', 'Total'));
        fr.appendChild(f1);
        var f2 = el('td', 'num'); f2.appendChild(el('strong', '', nf0.format(totW))); fr.appendChild(f2);
        var f3 = el('td', 'num'); f3.appendChild(el('strong', '', nf.format(totM))); fr.appendChild(f3);
        fr.appendChild(el('td')); fr.appendChild(el('td'));
        tfoot.appendChild(fr);
        table.appendChild(tfoot);
        body.appendChild(table);
    }

    /* ---------- Muat data ---------- */
    function currentParams() {
        var p = new URLSearchParams();
        p.set('period', selPeriod.value);
        if (selDept.value) p.set('dept', selDept.value);
        return p;
    }

    function showError(message) {
        errMsg.textContent = ' ' + message;
        errBox.hidden = false;
    }

    function render(data) {
        errBox.hidden = true;
        emptyBox.hidden = !data.meta.database_empty;
        document.getElementById('dashContext').textContent =
            data.meta.period_label + ' \u00B7 ' + data.meta.department_name + ' \u00B7 diperbarui ' + data.meta.generated_at;
        document.querySelectorAll('[data-bind="periodLabel"]').forEach(function (n) { n.textContent = data.meta.period_label; });
        renderKpis(data);
        renderCharts(data);
        renderQuality(data.quality);
        renderVendors(data.vendors);
    }

    function load() {
        if (controller) controller.abort();
        controller = new AbortController();
        var params = currentParams();
        section.classList.add('is-refreshing');

        fetch(endpoint + '?' + params.toString(), { headers: { 'Accept': 'application/json' }, credentials: 'same-origin', signal: controller.signal })
            .then(function (res) {
                if (res.status === 401) { window.location.reload(); throw new Error('Sesi berakhir'); }
                return res.json().then(function (json) { return { ok: res.ok, json: json }; });
            })
            .then(function (r) {
                if (!r.ok || !r.json.success) throw new Error((r.json && r.json.message) || 'Terjadi kesalahan.');
                render(r.json);
                section.classList.remove('is-loading');
                // Sinkronkan URL agar halaman bisa di-refresh/dibagikan dengan filter yang sama
                var qs = params.toString();
                history.replaceState(null, '', window.location.pathname + (qs ? '?' + qs : ''));
            })
            .catch(function (err) {
                if (err.name === 'AbortError') return;
                showError(err.message || 'Periksa koneksi Anda lalu coba lagi.');
                if (window.SWA) window.SWA.toast('danger', 'Data dashboard gagal dimuat.');
            })
            .then(function () { section.classList.remove('is-refreshing'); });
    }

    selPeriod.addEventListener('change', load);
    selDept.addEventListener('change', load);
    btnReset.addEventListener('click', function () {
        selPeriod.value = defaultPeriod;
        if (selPeriod.value !== defaultPeriod) selPeriod.selectedIndex = 0;
        selDept.value = '';
        load();
    });
    document.getElementById('dashRetry').addEventListener('click', load);
    document.getElementById('filterForm').addEventListener('submit', function (e) { e.preventDefault(); load(); });

    load();
})();
