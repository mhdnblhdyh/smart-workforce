/* User Management: aturan form (email terkunci saat edit, role sendiri terkunci), konfirmasi aksi, dialog kredensial sekali-tampil. */
(function () {
    'use strict';
    var form = document.getElementById('entityForm');
    if (form) {
        var email = form.elements.email, role = form.elements.role;
        var emailHint = document.getElementById('emailHint'), roleHint = document.getElementById('roleHint'), note = document.getElementById('createNote');
        var selfRows = {};
        document.querySelectorAll('tr[data-record]').forEach(function (tr) {
            try { var r = JSON.parse(tr.getAttribute('data-record')); selfRows[r.raw.id] = r.raw.is_self === '1'; } catch (e) { /* abaikan */ }
        });
        form.addEventListener('crud:formopen', function (ev) {
            var edit = ev.detail && ev.detail.mode === 'edit';
            var self = edit && selfRows[form.elements.id.value] === true;
            email.disabled = edit;
            role.disabled = self;
            if (emailHint) emailHint.hidden = false;
            if (note) note.hidden = edit;
            if (roleHint) roleHint.textContent = self ? 'Anda tidak dapat mengubah role akun Anda sendiri.' : '';
        });
        // Saat role dikunci (disabled) nilainya tidak dikirim; server tetap memakai role lama.
    }

    document.querySelectorAll('form[data-confirm]').forEach(function (f) {
        f.addEventListener('submit', function (e) { if (!window.confirm(f.getAttribute('data-confirm'))) e.preventDefault(); });
    });

    var secret = document.getElementById('secretDialog');
    if (secret) {
        if (typeof secret.showModal === 'function') secret.showModal(); else secret.setAttribute('open', '');
        var btn = document.getElementById('copySecret'), val = document.getElementById('secretValue');
        if (btn && val) {
            btn.addEventListener('click', function () {
                var done = function () { btn.lastChild.textContent = 'Tersalin'; };
                if (navigator.clipboard && navigator.clipboard.writeText) navigator.clipboard.writeText(val.textContent).then(done, function () { selectText(val); });
                else selectText(val);
            });
        }
        // Bersihkan dari DOM saat ditutup agar tidak tersisa di halaman
        secret.addEventListener('close', function () { if (val) val.textContent = '••••••••••'; });
    }
    function selectText(el) { var r = document.createRange(); r.selectNodeContents(el); var s = window.getSelection(); s.removeAllRanges(); s.addRange(r); }
})();
