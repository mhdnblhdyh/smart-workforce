/* ============================================================
   CRUD generik: dialog tambah/edit/detail/hapus, error validasi dari server, filter otomatis.
   Data baris dibaca dari atribut data-record (JSON) pada <tr>. Teks dirender lewat textContent.
   ============================================================ */
(function () {
    'use strict';

    var formDlg = document.getElementById('formDialog');
    var detailDlg = document.getElementById('detailDialog');
    var confirmDlg = document.getElementById('confirmDialog');

    function openDialog(d) {
        if (!d) return;
        if (typeof d.showModal === 'function') { if (!d.open) d.showModal(); }
        else d.setAttribute('open', '');
        document.documentElement.classList.add('modal-open');
    }
    function closeDialog(d) {
        if (!d) return;
        if (typeof d.close === 'function') d.close();
        else d.removeAttribute('open');
        if (!document.querySelector('dialog[open]')) document.documentElement.classList.remove('modal-open');
    }

    function recordOf(btn) {
        var tr = btn.closest('[data-record]');
        if (!tr) return null;
        try { return JSON.parse(tr.getAttribute('data-record')); } catch (e) { return null; }
    }

    /* ---------- Form ---------- */
    function clearErrors(form) {
        form.querySelectorAll('[data-error-for]').forEach(function (p) { p.textContent = ''; });
        form.querySelectorAll('.is-invalid').forEach(function (i) { i.classList.remove('is-invalid'); i.removeAttribute('aria-invalid'); });
    }
    function showErrors(form, errors) {
        var first = null;
        Object.keys(errors || {}).forEach(function (name) {
            var p = form.querySelector('[data-error-for="' + name + '"]');
            var input = form.elements[name];
            if (p) p.textContent = errors[name];
            if (input && input.classList) { input.classList.add('is-invalid'); input.setAttribute('aria-invalid', 'true'); if (!first) first = input; }
        });
        if (first && first.focus) first.focus();
    }
    function fillForm(form, values) {
        Array.prototype.forEach.call(form.elements, function (el) {
            if (!el.name || el.name === 'csrf_token' || el.name === 'return_qs') return;
            el.value = (values && values[el.name] !== undefined) ? values[el.name] : '';
        });
    }
    function openForm(mode, values, errors) {
        if (!formDlg) return;
        var form = formDlg.querySelector('form');
        clearErrors(form);
        fillForm(form, values || {});
        form.elements.id.value = (mode === 'edit' && values) ? (values.id || '') : '';
        formDlg.querySelector('#formTitle').textContent = formDlg.getAttribute(mode === 'edit' ? 'data-title-edit' : 'data-title-create');
        var submit = form.querySelector('[type="submit"]');
        if (submit) submit.disabled = false;
        openDialog(formDlg);
        form.dispatchEvent(new CustomEvent('crud:formopen', { bubbles: true, detail: { mode: mode } }));
        if (errors) showErrors(form, errors);
        else { var firstInput = form.querySelector('input:not([type=hidden]), select, textarea'); if (firstInput && firstInput.focus) firstInput.focus(); }
    }

    /* ---------- Detail ---------- */
    function openDetail(rec) {
        if (!detailDlg || !rec) return;
        detailDlg.querySelector('#detailTitle').textContent = rec.title || 'Detail';
        var dl = detailDlg.querySelector('#detailBody');
        while (dl.firstChild) dl.removeChild(dl.firstChild);
        (rec.details || []).forEach(function (pair) {
            var row = document.createElement('div');
            var dt = document.createElement('dt'); dt.textContent = pair[0];
            var dd = document.createElement('dd'); dd.textContent = pair[1];
            row.appendChild(dt); row.appendChild(dd); dl.appendChild(row);
        });
        openDialog(detailDlg);
    }

    /* ---------- Hapus ---------- */
    function openDelete(rec) {
        if (!confirmDlg || !rec) return;
        confirmDlg.querySelector('input[name="id"]').value = rec.raw.id;
        confirmDlg.querySelector('#confirmText').textContent = '\u201C' + rec.name + '\u201D akan dihapus permanen. Tindakan ini tidak dapat dibatalkan.';
        openDialog(confirmDlg);
    }

    /* ---------- Event delegasi ---------- */
    document.addEventListener('click', function (ev) {
        var closeBtn = ev.target.closest('[data-close]');
        if (closeBtn) { closeDialog(closeBtn.closest('dialog')); return; }

        // klik pada backdrop (area di luar kotak dialog)
        if (ev.target.tagName === 'DIALOG') { closeDialog(ev.target); return; }

        var btn = ev.target.closest('[data-action]');
        if (!btn) return;
        var action = btn.getAttribute('data-action');
        if (action === 'create') { openForm('create', {}, null); return; }
        var rec = recordOf(btn);
        if (!rec) return;
        if (action === 'edit') openForm('edit', rec.raw, null);
        else if (action === 'detail') openDetail(rec);
        else if (action === 'delete') openDelete(rec);
    });

    document.querySelectorAll('dialog').forEach(function (d) {
        d.addEventListener('close', function () { if (!document.querySelector('dialog[open]')) document.documentElement.classList.remove('modal-open'); });
    });

    // Cegah kirim ganda
    document.querySelectorAll('dialog form').forEach(function (form) {
        form.addEventListener('submit', function () {
            var s = form.querySelector('[type="submit"]');
            if (s && form.checkValidity()) setTimeout(function () { s.disabled = true; }, 0);
        });
    });

    // Buka kembali form dengan data & pesan error dari server (setelah validasi gagal)
    var stateEl = document.getElementById('formState');
    if (stateEl) {
        var state = null;
        try { state = JSON.parse(stateEl.textContent); } catch (e) { state = null; }
        if (state && state.errors) openForm(state.mode === 'edit' ? 'edit' : 'create', Object.assign({ id: state.id ? String(state.id) : '' }, state.old), state.errors);
    }
})();
