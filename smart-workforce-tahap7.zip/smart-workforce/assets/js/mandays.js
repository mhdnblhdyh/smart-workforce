/* Form mandays: saat edit, tenaga kerja & periode dikunci (server juga mengabaikan perubahan keduanya). */
(function () {
    'use strict';
    var form = document.getElementById('entityForm');
    if (!form) return;
    var hint = document.getElementById('lockHint');
    form.addEventListener('crud:formopen', function (ev) {
        var edit = ev.detail && ev.detail.mode === 'edit';
        form.elements.employee_id.disabled = edit;
        form.elements.period.disabled = edit;
        if (hint) hint.hidden = !edit;
    });
})();
