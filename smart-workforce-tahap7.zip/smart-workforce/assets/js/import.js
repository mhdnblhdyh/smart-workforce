/* Import Excel: pemeriksaan awal di browser (UX saja; validasi sebenarnya di server). */
(function () {
    'use strict';

    /* ---- Form unggah ---- */
    var up = document.getElementById('uploadForm');
    if (up) {
        var input = document.getElementById('fileInput');
        var label = document.getElementById('fileLabel');
        var err = document.getElementById('fileError');
        var submit = document.getElementById('uploadSubmit');
        var drop = document.getElementById('dropzone');

        function fmt(n) { return n >= 1048576 ? (n / 1048576).toFixed(1).replace('.', ',') + ' MB' : Math.max(1, Math.round(n / 1024)) + ' KB'; }
        function check() {
            err.textContent = '';
            var f = input.files && input.files[0];
            if (!f) { label.textContent = 'Klik untuk memilih file (.xlsx / .csv)'; return true; }
            label.textContent = f.name + ' (' + fmt(f.size) + ')';
            var ext = (f.name.split('.').pop() || '').toLowerCase();
            if (ext !== 'xlsx' && ext !== 'csv') { err.textContent = 'Format file harus .xlsx atau .csv.'; return false; }
            var max = parseInt(input.getAttribute('data-max-bytes'), 10);
            if (max && f.size > max) { err.textContent = 'Ukuran file ' + fmt(f.size) + ' melebihi batas ' + fmt(max) + '.'; return false; }
            if (f.size === 0) { err.textContent = 'File kosong.'; return false; }
            return true;
        }
        input.addEventListener('change', check);
        ['dragenter', 'dragover'].forEach(function (ev) { drop.addEventListener(ev, function (e) { e.preventDefault(); drop.classList.add('is-over'); }); });
        ['dragleave', 'drop'].forEach(function (ev) { drop.addEventListener(ev, function () { drop.classList.remove('is-over'); }); });
        up.addEventListener('submit', function (e) {
            if (!check()) { e.preventDefault(); return; }
            submit.disabled = true;
            submit.lastChild.textContent = 'Mengunggah…';
        });
    }

    /* ---- Form pemetaan ---- */
    var map = document.getElementById('mapForm');
    if (map) {
        var selects = Array.prototype.slice.call(map.querySelectorAll('select[data-field]'));
        var mapErr = document.getElementById('mapError');
        function dupCheck() {
            var seen = {}, dup = false;
            selects.forEach(function (s) { s.classList.remove('is-invalid'); });
            selects.forEach(function (s) {
                if (!s.value) return;
                if (seen[s.value]) { dup = true; s.classList.add('is-invalid'); seen[s.value].classList.add('is-invalid'); }
                else seen[s.value] = s;
            });
            mapErr.textContent = dup ? 'Satu kolom file tidak boleh dipakai untuk dua field berbeda.' : '';
            return !dup;
        }
        selects.forEach(function (s) { s.addEventListener('change', dupCheck); });
        dupCheck();

        var radios = map.querySelectorAll('input[name="duplicate_policy"]');
        var wrap = document.getElementById('confirmUpdateWrap');
        var box = wrap ? wrap.querySelector('input') : null;
        function policy() {
            var upd = map.querySelector('input[name="duplicate_policy"]:checked').value === 'update';
            wrap.hidden = !upd;
            box.required = upd;
        }
        Array.prototype.forEach.call(radios, function (r) { r.addEventListener('change', policy); });
        policy();

        map.addEventListener('submit', function (e) {
            if (!dupCheck()) { e.preventDefault(); return; }
            var b = map.querySelector('button[type="submit"]');
            if (map.checkValidity()) { setTimeout(function () { b.disabled = true; b.lastChild.textContent = 'Memvalidasi…'; }, 0); }
        });
    }

    /* ---- Konfirmasi import: cegah klik ganda ---- */
    var cf = document.getElementById('confirmForm');
    if (cf) {
        cf.addEventListener('submit', function () {
            var b = document.getElementById('confirmSubmit');
            if (cf.checkValidity()) setTimeout(function () { b.disabled = true; b.lastChild.textContent = 'Menyimpan…'; }, 0);
        });
    }

    /* ---- Form dengan data-confirm (mis. batalkan) ---- */
    document.querySelectorAll('form[data-confirm]').forEach(function (f) {
        f.addEventListener('submit', function (e) { if (!window.confirm(f.getAttribute('data-confirm'))) e.preventDefault(); });
    });
})();
