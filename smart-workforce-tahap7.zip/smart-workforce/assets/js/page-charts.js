/* ============================================================
   Grafik generik untuk halaman server-rendered (Rekap Mandays, Analytics).
   Konfigurasi dibaca dari <script type="application/json" id="chartData">{"charts":[...]}</script>
   Setiap chart: {id,type,labels,datasets:[{label,data,color,kind,axis,fill}],yTitle,y1Title,percent,names,emptyText}
   ============================================================ */
(function () {
    'use strict';
    var el = document.getElementById('chartData');
    if (!el) return;
    var cfg;
    try { cfg = JSON.parse(el.textContent); } catch (e) { return; }
    var nf = new Intl.NumberFormat('id-ID', { maximumFractionDigits: 1 });
    var PALETTE = ['#3A86FF', '#0B132B', '#14A3A8', '#94A3B8', '#F59E0B'];

    // Grafik persentase: 0% adalah data yang valid; hanya null (tidak ada tenaga kerja) yang berarti "tidak ada data".
    function allEmpty(c) {
        return c.datasets.every(function (d) { return d.data.every(function (v) { return v === null || (!c.percent && !v); }); });
    }
    function showEmpty(canvas, text) {
        var box = canvas.parentNode.querySelector('.chart-empty');
        if (box) { if (text) box.querySelector('span').textContent = text; box.hidden = false; }
        canvas.style.visibility = 'hidden';
    }

    function build(c) {
        var canvas = document.getElementById(c.id);
        if (!canvas) return;
        if (typeof Chart === 'undefined') { showEmpty(canvas, 'Pustaka grafik gagal dimuat.'); return; }
        if (allEmpty(c)) { showEmpty(canvas, c.emptyText); return; }

        Chart.defaults.font.family = "'Inter', system-ui, sans-serif";
        Chart.defaults.color = '#64748B';
        var isDonut = c.type === 'doughnut';
        var tooltip = { backgroundColor: '#0B132B', padding: 10, cornerRadius: 8, callbacks: {} };
        if (c.names) tooltip.callbacks.title = function (items) { return c.names[items[0].dataIndex] || items[0].label; };
        tooltip.callbacks.label = function (ctx) {
            var v = isDonut ? ctx.parsed : (ctx.parsed.y !== undefined ? ctx.parsed.y : ctx.parsed.x);
            if (v === null || v === undefined) return ' ' + ctx.dataset.label + ': tidak ada data';
            var out = ' ' + ctx.dataset.label + ': ' + nf.format(v) + (c.percent && ctx.dataset.axis !== 'y1' ? '%' : (ctx.dataset.unit || ''));
            if (isDonut) {
                var total = ctx.dataset.data.reduce(function (a, b) { return a + b; }, 0);
                out = ' ' + ctx.label + ': ' + nf.format(v) + ' (' + nf.format(v / total * 100) + '%)';
            }
            return out;
        };

        var datasets = c.datasets.map(function (d, i) {
            var color = d.color || PALETTE[i % PALETTE.length];
            if (isDonut) return { data: d.data, backgroundColor: c.labels.map(function (_, k) { return (d.colors || PALETTE)[k % PALETTE.length]; }), borderColor: '#fff', borderWidth: 3, hoverOffset: 6 };
            var isLine = (d.kind || c.type) === 'line';
            var ds = { label: d.label, data: d.data, type: d.kind || undefined, yAxisID: d.axis || 'y', unit: d.unit || '', axis: d.axis || 'y' };
            if (isLine) { Object.assign(ds, { borderColor: color, backgroundColor: color, borderWidth: d.width || 2, tension: .3, pointRadius: 3, spanGaps: false, fill: false }); }
            else { Object.assign(ds, { backgroundColor: color, borderRadius: 6, maxBarThickness: 44 }); }
            return ds;
        });

        var scales;
        if (!isDonut) {
            scales = { x: { grid: { display: false }, border: { display: false } },
                y: { beginAtZero: true, grid: { color: '#EEF2F8' }, border: { display: false }, title: c.yTitle ? { display: true, text: c.yTitle } : undefined,
                     max: c.percent ? 100 : undefined, ticks: { precision: c.percent ? 0 : undefined, callback: function (v) { return nf.format(v) + (c.percent ? '%' : ''); } } } };
            if (c.horizontal) { scales.x = { beginAtZero: true, grid: { color: '#EEF2F8' }, border: { display: false } }; scales.y = { grid: { display: false }, border: { display: false } }; }
            if (c.y1Title) scales.y1 = { position: 'right', beginAtZero: true, grid: { drawOnChartArea: false }, border: { display: false }, title: { display: true, text: c.y1Title } };
        }

        new Chart(canvas, {
            type: c.type,
            data: { labels: c.labels, datasets: datasets },
            options: {
                responsive: true, maintainAspectRatio: false, indexAxis: c.horizontal ? 'y' : 'x',
                interaction: { mode: isDonut ? 'nearest' : 'index', intersect: false },
                cutout: isDonut ? '64%' : undefined,
                plugins: { legend: { display: isDonut || c.datasets.length > 1, position: 'bottom', labels: { usePointStyle: true, boxWidth: 8, padding: 16 } }, tooltip: tooltip },
                scales: scales
            }
        });
    }

    (cfg.charts || []).forEach(build);
})();
