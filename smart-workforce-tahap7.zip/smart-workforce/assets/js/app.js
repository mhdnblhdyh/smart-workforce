/* ============================================================
   Smart Workforce Analytics — perilaku UI global
   (sidebar, drawer, dropdown, toast). Tanpa dependensi.
   ============================================================ */
(function () {
    'use strict';

    var root = document.documentElement;
    var body = document.body;
    var mobileQuery = window.matchMedia('(max-width: 1024px)');
    var STORAGE_KEY = 'swa.sidebar';

    function storageGet(k) { try { return localStorage.getItem(k); } catch (e) { return null; } }
    function storageSet(k, v) { try { localStorage.setItem(k, v); } catch (e) { /* abaikan */ } }

    /* ---------- Sidebar ---------- */
    var overlay = document.getElementById('sidebarOverlay');
    var toggleBtn = document.getElementById('sidebarToggle');
    var collapseBtn = document.getElementById('sidebarCollapse');
    var closeBtn = document.getElementById('sidebarClose');

    function setDrawer(open) {
        body.classList.toggle('drawer-open', open);
        if (overlay) overlay.hidden = !open;
        if (toggleBtn) toggleBtn.setAttribute('aria-expanded', open ? 'true' : 'false');
    }

    function setCollapsed(collapsed) {
        root.classList.toggle('sidebar-collapsed', collapsed);
        storageSet(STORAGE_KEY, collapsed ? 'collapsed' : 'expanded');
        if (collapseBtn) {
            var label = collapsed ? 'Perluas sidebar' : 'Ciutkan sidebar';
            collapseBtn.setAttribute('aria-label', label);
            collapseBtn.title = label;
        }
    }

    if (toggleBtn) {
        toggleBtn.addEventListener('click', function () {
            if (mobileQuery.matches) setDrawer(!body.classList.contains('drawer-open'));
            else setCollapsed(!root.classList.contains('sidebar-collapsed'));
        });
    }
    if (collapseBtn) collapseBtn.addEventListener('click', function () { setCollapsed(!root.classList.contains('sidebar-collapsed')); });
    if (closeBtn) closeBtn.addEventListener('click', function () { setDrawer(false); });
    if (overlay) overlay.addEventListener('click', function () { setDrawer(false); });
    document.querySelectorAll('.sidebar a.nav-link').forEach(function (a) {
        a.addEventListener('click', function () { setDrawer(false); });
    });
    var onViewportChange = function () { if (!mobileQuery.matches) setDrawer(false); };
    if (mobileQuery.addEventListener) mobileQuery.addEventListener('change', onViewportChange);
    else if (mobileQuery.addListener) mobileQuery.addListener(onViewportChange);

    /* ---------- Dropdown ---------- */
    function closeDropdowns(except) {
        document.querySelectorAll('[data-dropdown][aria-expanded="true"]').forEach(function (btn) {
            if (btn === except) return;
            btn.setAttribute('aria-expanded', 'false');
            var menu = btn.parentElement.querySelector('.dropdown-menu');
            if (menu) menu.hidden = true;
        });
    }
    document.querySelectorAll('[data-dropdown]').forEach(function (btn) {
        btn.addEventListener('click', function (ev) {
            ev.stopPropagation();
            var menu = btn.parentElement.querySelector('.dropdown-menu');
            if (!menu) return;
            var open = btn.getAttribute('aria-expanded') === 'true';
            closeDropdowns(open ? null : btn);
            btn.setAttribute('aria-expanded', open ? 'false' : 'true');
            menu.hidden = open;
        });
    });
    document.addEventListener('click', function (ev) {
        if (!ev.target.closest('.dropdown')) closeDropdowns(null);
    });
    document.addEventListener('keydown', function (ev) {
        if (ev.key !== 'Escape') return;
        var openBtn = document.querySelector('[data-dropdown][aria-expanded="true"]');
        closeDropdowns(null);
        if (openBtn) openBtn.focus();
        if (body.classList.contains('drawer-open')) setDrawer(false);
    });

    /* ---------- Toast ---------- */
    var region = document.getElementById('toastRegion');
    var spriteEl = document.querySelector('use');
    var spriteUrl = spriteEl ? (spriteEl.getAttribute('href') || '').split('#')[0] : '';
    var TOAST_ICON = { success: 'circle-check', danger: 'circle-alert', warning: 'triangle-alert', info: 'info' };

    function svgIcon(name) {
        var ns = 'http://www.w3.org/2000/svg';
        var svg = document.createElementNS(ns, 'svg');
        svg.setAttribute('class', 'icon');
        svg.setAttribute('aria-hidden', 'true');
        var use = document.createElementNS(ns, 'use');
        use.setAttribute('href', spriteUrl + '#' + name);
        svg.appendChild(use);
        return svg;
    }

    function toast(type, message, duration) {
        if (!region) return;
        type = TOAST_ICON[type] ? type : 'info';
        var el = document.createElement('div');
        el.className = 'toast toast-' + type;
        el.setAttribute('role', type === 'danger' ? 'alert' : 'status');

        var msg = document.createElement('div');
        msg.className = 'toast-msg';
        msg.textContent = message;                       // textContent: aman dari XSS

        var close = document.createElement('button');
        close.type = 'button';
        close.className = 'toast-close';
        close.setAttribute('aria-label', 'Tutup notifikasi');
        close.appendChild(svgIcon('x'));

        el.appendChild(svgIcon(TOAST_ICON[type]));
        el.appendChild(msg);
        el.appendChild(close);
        region.appendChild(el);

        var timer;
        function remove() {
            clearTimeout(timer);
            el.classList.add('is-leaving');
            setTimeout(function () { if (el.parentNode) el.parentNode.removeChild(el); }, 220);
        }
        close.addEventListener('click', remove);
        timer = setTimeout(remove, duration || (type === 'danger' ? 8000 : 5000));
    }

    // Flash message dari server -> toast
    var flashEl = document.getElementById('flashData');
    if (flashEl) {
        try {
            JSON.parse(flashEl.textContent || '[]').forEach(function (f) {
                toast(f.type === 'error' ? 'danger' : f.type, f.message);
            });
        } catch (e) { /* abaikan */ }
    }

    /* ---------- Filter otomatis: select[data-autosubmit] mengirim form saat berubah ---------- */
    document.querySelectorAll('[data-autosubmit]').forEach(function (sel) {
        sel.addEventListener('change', function () {
            var form = sel.closest('form');
            if (!form) return;
            var page = form.querySelector('[name="page"]');
            if (page) page.remove();
            form.submit();
        });
    });

    window.SWA = { toast: toast, csrf: window.SWA_CSRF || '' };
})();
