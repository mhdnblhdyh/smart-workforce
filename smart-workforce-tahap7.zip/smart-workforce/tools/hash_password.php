<?php
/**
 * Utilitas CLI: membuat hash bcrypt untuk password (mis. untuk membuat/reset akun lewat phpMyAdmin).
 * Pemakaian: php tools/hash_password.php "PasswordBaru#123"
 * Folder tools/ diblokir dari akses browser oleh .htaccess dan skrip ini menolak dijalankan via web.
 */
if (PHP_SAPI !== 'cli') {
    http_response_code(403);
    exit('Hanya untuk CLI.');
}
$password = $argv[1] ?? '';
if (strlen($password) < 8) {
    fwrite(STDERR, "Pemakaian: php tools/hash_password.php \"password-min-8-karakter\"\n");
    exit(1);
}
echo password_hash($password, PASSWORD_DEFAULT), PHP_EOL;
