<?php
/**
 * Ganti password sendiri. Juga halaman wajib bagi akun yang password-nya baru dibuat/direset Admin.
 */
declare(strict_types=1);
require_once __DIR__ . '/includes/bootstrap.php';

$user   = require_login(false, true);
$forced = !empty($user['must_change_password']);
$errors = [];

if (is_post()) {
    csrf_require();
    $current = (string) ($_POST['current_password'] ?? '');
    $new     = (string) ($_POST['new_password'] ?? '');
    $confirm = (string) ($_POST['confirm_password'] ?? '');

    $row = db_fetch_one('SELECT password_hash, failed_login_attempts FROM users WHERE id = ?', 'i', [(int) $user['id']]);
    $max = (int) app_config('security.max_login_attempts', 5);

    if (!$row || $current === '' || !password_verify($current, $row['password_hash'])) {
        // Batasi tebakan password lama dari sesi yang mungkin dicuri: hitung seperti kegagalan login.
        $attempts = (int) ($row['failed_login_attempts'] ?? 0) + 1;
        if ($attempts >= $max) {
            db_run('UPDATE users SET failed_login_attempts = 0, locked_until = DATE_ADD(NOW(), INTERVAL ? MINUTE) WHERE id = ?', 'ii', [(int) app_config('security.lockout_minutes', 15), (int) $user['id']]);
            audit_log('account_locked', 'user', (int) $user['id'], 'Akun dikunci: terlalu banyak kegagalan verifikasi password lama');
            auth_clear_session();
            session_start();
            flash_set('danger', 'Terlalu banyak percobaan. Akun dikunci sementara.');
            redirect('login.php');
        }
        db_run('UPDATE users SET failed_login_attempts = ? WHERE id = ?', 'ii', [$attempts, (int) $user['id']]);
        audit_log('password_change_failed', 'user', (int) $user['id'], 'Verifikasi password lama gagal');
        $errors['current_password'] = 'Password saat ini tidak sesuai.';
    }
    foreach (password_policy_errors($new, (string) $user['email'], (string) $user['name']) as $msg) {
        $errors['new_password'] = ($errors['new_password'] ?? '') . $msg . ' ';
    }
    if ($new !== '' && hash_equals($current, $new)) {
        $errors['new_password'] = trim(($errors['new_password'] ?? '') . ' Password baru harus berbeda dari password saat ini.');
    }
    if ($new !== $confirm) {
        $errors['confirm_password'] = 'Konfirmasi password tidak sama.';
    }

    if (!$errors) {
        $hash = password_hash($new, PASSWORD_DEFAULT);
        if (users_has_security_columns()) {
            db_run('UPDATE users SET password_hash = ?, must_change_password = 0, password_changed_at = NOW(), failed_login_attempts = 0, locked_until = NULL WHERE id = ?', 'si', [$hash, (int) $user['id']]);
        } else {
            db_run('UPDATE users SET password_hash = ?, failed_login_attempts = 0, locked_until = NULL WHERE id = ?', 'si', [$hash, (int) $user['id']]);
        }
        session_regenerate_id(true);
        $_SESSION['login_at'] = time() + 2;          // sesi ini tetap sah; sesi lain (lama) akan dicabut
        audit_log('password_change', 'user', (int) $user['id'], $forced ? 'Mengganti password sementara' : 'Mengganti password sendiri');
        flash_set('success', 'Password berhasil diubah.');
        redirect('index.php');
    }
}

$appName = (string) app_config('app_name');
$flashes = flash_get();
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="robots" content="noindex, nofollow">
    <title>Ganti Password — <?= e($appName) ?></title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="<?= e(url('assets/css/style.css')) ?>">
    <link rel="stylesheet" href="<?= e(url('assets/css/auth.css')) ?>">
</head>
<body class="auth-body">
<main class="auth-panel" style="min-height:100vh">
    <div class="auth-card" style="max-width:460px">
        <div class="auth-card-head">
            <h2>Ganti password</h2>
            <p><?= $forced ? 'Demi keamanan, Anda harus mengganti password sementara sebelum melanjutkan.' : 'Masuk sebagai ' . e($user['email']) . '.' ?></p>
        </div>

        <?php foreach ($flashes as $f): ?><div class="alert alert-<?= e($f['type']) ?>" role="status"><?= e($f['message']) ?></div><?php endforeach; ?>
        <?php if ($errors): ?><div class="alert alert-danger" role="alert">Periksa kembali isian Anda.</div><?php endif; ?>

        <form method="post" action="<?= e(url('change-password.php')) ?>" novalidate id="pwForm">
            <?= csrf_field() ?>
            <?php foreach ([
                ['current_password', $forced ? 'Password sementara' : 'Password saat ini', 'current-password'],
                ['new_password', 'Password baru', 'new-password'],
                ['confirm_password', 'Ulangi password baru', 'new-password'],
            ] as [$name, $label, $ac]): ?>
                <div class="field">
                    <label for="<?= e($name) ?>"><?= e($label) ?></label>
                    <input type="password" id="<?= e($name) ?>" name="<?= e($name) ?>" autocomplete="<?= e($ac) ?>" required maxlength="200"<?= isset($errors[$name]) ? ' aria-invalid="true" style="border-color:var(--danger)"' : '' ?>>
                    <?php if (isset($errors[$name])): ?><p class="field-error" style="margin:4px 0 0;color:var(--danger);font-size:12.5px"><?= e($errors[$name]) ?></p><?php endif; ?>
                    <?php if ($name === 'new_password'): ?><small style="display:block;margin-top:4px;color:var(--text-2);font-size:12px">Minimal <?= PASSWORD_MIN_LENGTH ?> karakter, mengandung huruf dan angka, tidak memuat nama email Anda.</small><?php endif; ?>
                </div>
            <?php endforeach; ?>
            <button type="submit" class="btn btn-primary btn-block">Simpan password baru</button>
        </form>

        <div style="display:flex;justify-content:space-between;margin-top:18px;font-size:13px">
            <?php if (!$forced): ?><a href="<?= e(url('index.php')) ?>">← Kembali</a><?php else: ?><span></span><?php endif; ?>
            <form method="post" action="<?= e(url('logout.php')) ?>"><?= csrf_field() ?><button type="submit" class="link-btn" style="background:none;border:0;color:var(--text-2);text-decoration:underline;cursor:pointer;font:inherit">Keluar</button></form>
        </div>
    </div>
</main>
</body>
</html>
