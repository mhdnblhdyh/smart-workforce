<?php
declare(strict_types=1);
require_once __DIR__ . '/includes/bootstrap.php';

// Logout hanya lewat POST + CSRF agar tidak bisa dipicu dari situs lain (logout CSRF).
if (!is_post()) {
    redirect('index.php');
}

csrf_require();

$user = current_user();
if ($user !== null) {
    audit_log('logout', 'user', (int) $user['id'], 'Logout', (int) $user['id']);
}

auth_clear_session();
session_start();
session_regenerate_id(true);
flash_set('success', 'Anda telah keluar dengan aman.');
redirect('login.php');
